"""Exhaust the 90 assignments of six loss amounts to three labelled marginals."""
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import csv, warnings
import numpy as np
from scipy.optimize import linprog, OptimizeWarning
warnings.filterwarnings("ignore",category=OptimizeWarning,message="Unrecognized options detected.*threads.*")
from prior_verification import PROBS, solve_square, compressed

ALPHA = F(1,20)
AMOUNTS = (5,7,8,9,10,14)
OUT = Path(__file__).resolve().parent


def evaluate_at_vertices():
    # BLLW breakplanes depend only on tail probabilities, identical for all assignments.
    planes, clips = [], []
    for i, ps in enumerate(PROBS):
        unit = tuple(F(i == j) for j in range(3))
        planes.append((unit,F(0)))
        for rank in (1,2):
            c = sum(ps[rank:])/ALPHA
            coeff = tuple(c-x for x in unit)
            clips.append((coeff,c))
            planes.extend((coeff,edge-c) for edge in (0,1))
    vertices = set()
    for group in combinations(planes,3):
        point = solve_square([r for r,b in group],[b for r,b in group])
        if point is not None and min(point) >= 0:
            vertices.add(tuple(point))
    return {tuple(max(0,min(1,c+sum(b*t for b,t in zip(coeff,y))))
                  for coeff,c in clips) for y in vertices}


def sharp_checker(values,probs=PROBS):
    states = list(product(*values))
    totals = np.array([sum(s) for s in states])
    indicators = np.array([[int(s[i] == a) for s in states]
                           for i, v in enumerate(values) for a in v], dtype=int)
    masses = sum(probs, [])
    def exact_tail(d):
        event = (totals>=d).astype(int)
        opt = linprog(-event, A_eq=indicators, b_eq=np.array(masses,float), method='highs', options={'threads':1})
        if not opt.success:
            raise RuntimeError(opt.message)
        plan = [F(float(x)).limit_denominator(10**8) for x in opt.x]
        dual = [F(float(-x)).limit_denominator(10**6) for x in opt.eqlin.marginals]
        # Solver only discovers candidates. Verify both values and all constraints over Q.
        assert min(plan)>=0
        assert all(sum(p for x,p in zip(row,plan) if x)==b
                   for row,b in zip(indicators,masses))
        assert all(sum(y for x,y in zip(col,dual) if x)>=int(t)
                   for col,t in zip(indicators.T,event))
        upper = sum(y*b for y,b in zip(dual,masses))
        assert upper == sum(p for x,p in zip(event,plan) if x)
        return upper
    return sorted(set(map(int,totals))),exact_tail


def main():
    coeffs=evaluate_at_vertices()
    rows=[]
    for a in combinations(AMOUNTS,2):
        rem=sorted(set(AMOUNTS)-set(a))
        for b in combinations(rem,2):
            c=tuple(sorted(set(rem)-set(b)))
            v=[[0,*pair] for pair in (a,b,c)]
            diffs=[inc for _,x,y in v for inc in (x,y-x)]
            bound=min(sum(w*t for w,t in zip(diffs,g)) for g in coeffs)
            lattice,tail=sharp_checker(v)
            # Left 95% VaR: an attainable level s iff max Pr(loss >=s)>alpha.
            lo,hi=0,len(lattice)
            while hi-lo>1:
                mid=(lo+hi)//2
                if tail(lattice[mid])>ALPHA:
                    lo=mid
                else:
                    hi=mid
            var=lattice[lo]
            above=var+1
            p0,p1=tail(var),tail(above)
            assert p0>ALPHA>p1      # Both conventions agree throughout this family.
            support_bound=max(t for t in lattice if t<=bound)
            assert support_bound>=var
            applicable = sum(min(x for x in values if x) for values in v)>=above
            if applicable:
                assert abs(compressed(v,PROBS,var)-float(p0))<1e-8
                assert abs(compressed(v,PROBS,above)-float(p1))<1e-8
            rows.append([*a,*b,*c,var,str(bound),support_bound,str(p0),str(p1),int(applicable)])
    assert len(rows)==90
    with (OUT/'accuracy.csv').open('w',newline='') as f:
        writer=csv.writer(f)
        writer.writerow(['A_low','A_high','B_low','B_high','C_low','C_high','sharp_var',
                         'BLLW_fraction','support_rounded_BLLW','tail_at_var','tail_at_var_plus_1','k3_covers_both'])
        writer.writerows(rows)
    from statistics import median
    for label, ix in [('raw',7),('support_rounded',8)]:
        subset=[r for r in rows if r[-1]]
        for ss in (rows,subset):
            gaps=[(F(r[ix])-r[6])/F(r[ix]) for r in ss]
            print(label,len(gaps),'strict',sum(x>0 for x in gaps),'mean',float(sum(gaps)/len(gaps)),
                  'median',float(median(gaps)),'max',float(max(gaps)))
    print('original and swap', [r for r in rows if r[:6] in ([5,14,7,10,8,9],[5,9,7,10,8,14])])
if __name__=='__main__':
    main()
