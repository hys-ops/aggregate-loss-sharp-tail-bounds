"""Reproduce the sharp tail bounds and the convolution comparison. Python 3.10+, SciPy."""
from collections import Counter
from fractions import Fraction as F
from itertools import combinations, product
import random

import numpy as np
from scipy.optimize import linprog

UNIT = F(49, 10000)
BASE = [[0, 5, 14], [0, 7, 10], [0, 8, 9]]
SWAP = [[0, 5, 9], [0, 7, 10], [0, 8, 14]]
PROBS = [[1-(a+b)*UNIT, a*UNIT, b*UNIT] for a, b in [(4,5), (3,3), (3,5)]]


def max_lp(obj, eq, eqb, ub=(), ubb=()):
    def mat(rows):
        return np.asarray(rows, dtype=float) if len(rows) else None
    res = linprog(-np.asarray(obj, dtype=float), A_eq=mat(eq), b_eq=mat(eqb),
                  A_ub=mat(ub), b_ub=mat(ubb), bounds=(0,None), method="highs")
    if not res.success:
        raise RuntimeError(res.message)
    return -res.fun


def full(values, probs, cutoff):
    states = list(product(*values))
    rows, rhs = [], []
    for i, support in enumerate(values):
        for a, p in zip(support, probs[i]):
            rows.append([s[i] == a for s in states])
            rhs.append(p)
    return max_lp([sum(s) >= cutoff for s in states], rows, rhs)


def compressed(values, probs, cutoff):
    """Exact LP formulation, evaluated by a floating-point LP solver."""
    n = len(values)
    if cutoff <= 0 or min(min(row) for row in values) < 0:
        raise ValueError("positive threshold and nonnegative losses required")
    low = [[(a,p) for a,p in zip(v,m) if 0 < a < cutoff and p>0]
           for v,m in zip(values, probs)]
    minima = sorted(min(a for a,_ in row) for row in low if row)
    if len(minima) >= 3 and sum(minima[:3]) < cutoff:
        raise ValueError("some triple of subthreshold positive losses can fail")
    high = sum(p for v,m in zip(values,probs) for a,p in zip(v,m) if a >= cutoff)
    # g[i,j,a] is the mass of value a at i used to form a successful pair with j.
    keys = [(i,j,a) for i in range(n) for j in range(n) if j!=i for a,p in low[i]]
    ix = {key:k for k,key in enumerate(keys)}
    count = len(keys)
    triple = count+n
    def zeros(): return np.zeros(triple+1)
    ub,ubv,eq,eqv = [],[],[],[]
    for i in range(n):
        total = zeros()
        for a,p in low[i]:
            row = zeros()
            for j in range(n):
                if j!=i: row[ix[i,j,a]] = 1
            ub.append(row); ubv.append(p)
            total += row
        total[count+i] = 1
        ub.append(total); ubv.append(sum(p for _,p in low[i]))
        row = zeros(); row[count+i]=1; row[triple]=-1
        ub.append(row); ubv.append(0)
    for i,j in combinations(range(n),2):
        row = zeros()
        for a,p in low[i]: row[ix[i,j,a]]=1
        for b,p in low[j]: row[ix[j,i,b]]=-1
        eq.append(row); eqv.append(0)
        for a,_ in low[i]:
            row=zeros()
            for v,p in low[i]:
                if v<=a: row[ix[i,j,v]]=1
            for v,p in low[j]:
                if a+v>=cutoff: row[ix[j,i,v]]=-1
            ub.append(row); ubv.append(0)
    row=zeros(); row[count:triple]=1; row[triple]=-3
    eq.append(row); eqv.append(0)
    obj=zeros(); obj[:count]=.5; obj[triple]=1
    return min(1.,float(high)+max_lp(obj,eq,eqv,ub,ubv))


def check_certificate(values, cutoff, weights, winners):
    # All numbers in weights and winners are exact fractions. Winning masses in units of UNIT.
    for s in product(*values):
        w=sum(weights[i][values[i].index(x)] for i,x in enumerate(s))
        assert w >= int(sum(s)>=cutoff), (s,w)
    upper=sum(w*p for ws,ps in zip(weights,PROBS) for w,p in zip(ws,ps))
    uses=[Counter() for _ in values]
    for s,mass in winners:
        assert sum(s)>=cutoff and mass>=0
        for i,x in enumerate(s):
            assert x in values[i]
            if x: uses[i][x]+=mass*UNIT
    bound=sum(m for s,m in winners)*UNIT
    for i,support in enumerate(values):
        assert all(uses[i][x]<=p for x,p in zip(support,PROBS[i]))
    assert 0<=bound<=1 and bound==upper
    return upper


def exact_examples():
    half=F(1,2)
    third=F(1,3)
    base_high=[(0,0,half),(0,half,half),(0,half,half)]
    base_plan=[((0,10,9),3),((5,7,8),3*half),((14,0,8),3*half),
               ((14,0,9),2),((14,7,0),3*half)]
    recipes=[
        (BASE,15,[(0,0,half),(0,half,1),(0,half,half)],
         [((0,7,9),2),((5,7,9),1),((5,10,0),3),((14,0,8),3),((14,0,9),2)]),
        (BASE,16,base_high,base_plan), (BASE,18,base_high,base_plan),
        (BASE,19,base_high,base_plan),
        (SWAP,18,[(0,third,third),(0,third,2*third),(0,third,2*third)],
         [((0,7,14),2*third),((0,10,8),2*third),((5,0,14),5*third),
          ((5,7,8),7*third),((9,0,14),8*third),((9,10,0),7*third)]),
        (SWAP,19,[(0,half,half),(0,half,half),(0,0,half)],
         [((0,7,14),1),((5,0,14),4),((9,7,8),2),((9,10,0),3)])]
    for v,t,w,plan in recipes:
        a=check_certificate(v,t,w,plan)
        assert abs(full(v,PROBS,t)-float(a))<1e-9
        assert abs(compressed(v,PROBS,t)-float(a))<1e-9
        print("original" if v==BASE else "swapped",t,str(a), f"{float(100*a):.3f}%")


def solve_square(rows, rhs):
    a=[list(row)+[b] for row,b in zip(rows,rhs)]
    n=len(rows)
    for j in range(n):
        pivot=next((i for i in range(j,n) if a[i][j]),None)
        if pivot is None: return None
        a[j],a[pivot]=a[pivot],a[j]
        a[j]=[x/a[j][j] for x in a[j]]
        for i in range(n):
            if i!=j:
                k=a[i][j]
                a[i]=[v-k*w for v,w in zip(a[i],a[j])]
    return [row[-1] for row in a]


def convolution(values, probs, alpha=F(1,20)):
    # Exact vertex enumeration of the piecewise-linear form of BLLW (14), for small n.
    n=len(values); planes=[]; terms=[]
    for i in range(n):
        e=[F(j==i) for j in range(n)]
        planes.append((e,F(0)))
        for k in range(1,len(values[i])):
            p=sum(probs[i][k:])
            c=p/alpha
            co=[c-x for x in e]
            terms.append((values[i][k]-values[i][k-1],c,co))
            for edge in (0,1): planes.append((co,edge-c))
    best=None
    for group in combinations(planes,n):
        y=solve_square([r for r,_ in group],[b for _,b in group])
        if y is None or min(y)<0: continue
        val=sum(v[0] for v in values)
        for dv,c,co in terms:
            val+=dv*max(0,min(1,c+sum(a*b for a,b in zip(co,y))))
        best=val if best is None else min(val,best)
    return best


def compare_random():
    rng=random.Random(87117); discrepancies=[]; saturated=0
    for n in range(3,7):
        for k in range(40):
            cutoff=15
            values=[]; probs=[]
            for _ in range(n):
                v=[0]+sorted(rng.sample(range(5,15),2))
                if k%3!=0: v.append(rng.randrange(15,20))
                parts=[rng.randint(1,15) for _ in v[1:]]
                den=100 if k%2==0 else sum(parts)+rng.randint(1,5)
                values.append(v); probs.append([F(den-sum(parts),den)]+[F(x,den) for x in parts])
            a=full(values,probs,cutoff); b=compressed(values,probs,cutoff)
            discrepancies.append(abs(a-b)); saturated+=a>1-1e-9
    assert max(discrepancies)<1e-8
    print("full LP vs compressed LP:",len(discrepancies),"fixtures, maximum difference",
          f"{max(discrepancies):.3g},",saturated,"probability-one fixtures")

if __name__=="__main__":
    exact_examples()
    for v in (BASE,SWAP):
        b=convolution(v,PROBS)
        assert b==19
        print("BLLW (14)","original" if v==BASE else "swapped",str(b),float(b))
    compare_random()
