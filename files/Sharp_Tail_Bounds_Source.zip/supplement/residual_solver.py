"""Finite residual-allocation solver used for the five-name comparisons."""
from itertools import combinations, product
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

class Matrix:
    def __init__(self):
        self.rows,self.cols,self.data=[],[],[]
    def add(self,row,col,v):
        self.rows.append(row)
        self.cols.append(col)
        self.data.append(v)
    def array(self,nrow,ncol):
        return coo_matrix((self.data,(self.rows,self.cols)),shape=(nrow,ncol)).tocsr()


def lp(objective,eq,eqb,ub=None,ubb=None):
    sol=linprog(-np.asarray(objective),A_eq=eq,b_eq=eqb,A_ub=ub,b_ub=ubb,
                method='highs',options={'threads':1})
    if not sol.success:
        raise RuntimeError(sol.message)
    return -sol.fun


def residual(values,probs,d):
    n=len(values)
    high=sum(p for vs,ps in zip(values,probs) for a,p in zip(vs,ps) if a>=d)
    low=[[(a,p) for a,p in zip(vs,ps) if 0<a<d and p>0] for vs,ps in zip(values,probs)]
    minima=sorted(min(a for a,_ in row) for row in low if row)
    k=next((i for i in range(2,n+1) if i>len(minima) or sum(minima[:i])>=d),None)
    if k is None:
        raise ValueError('no qualifying compression layer')
    b=[sum(p for _,p in row) for row in low]
    if k==2:
        return (min(1.,high+min(sum(b)/2,sum(b)-max(b))),0)
    ub=Matrix()
    rhs=[]
    atom_rows={}
    for i,atoms in enumerate(low):
        for a,p in atoms:
            atom_rows[i,a]=len(rhs)
            rhs.append(p)
    budget=len(rhs)
    rhs.extend(b)
    individual=len(rhs)
    rhs.extend([0.]*n)
    obj=[]
    for size in range(2,k):
        for group in combinations(range(n),size):
            for marks in product(*(low[i] for i in group)):
                amounts=[a for a,p in marks]
                total=sum(amounts)
                # Every successful outcome has a minimal witness.
                if total<d or total-min(amounts)>=d:
                    continue
                col=len(obj)
                obj.append(1.)
                for i,a in zip(group,amounts):
                    ub.add(atom_rows[i,a],col,1)
                    ub.add(budget+i,col,1)
    eq=Matrix()
    for i in range(n):
        col=len(obj)
        obj.append(0.)
        ub.add(budget+i,col,1)
        ub.add(individual+i,col,1)
        eq.add(0,col,1)
    t=len(obj)
    obj.append(1.)
    for i in range(n):
        ub.add(individual+i,t,-1)
    eq.add(0,t,-k)
    return min(1.,high+lp(obj,eq.array(1,len(obj)),[0.],ub.array(len(rhs),len(obj)),rhs)),len(obj)
