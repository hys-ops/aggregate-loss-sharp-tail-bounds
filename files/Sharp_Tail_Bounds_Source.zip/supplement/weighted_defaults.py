"""All five-name assignments of five severities to five different default probabilities."""
from fractions import Fraction as F
from pathlib import Path
from itertools import permutations, combinations
import csv, warnings
from statistics import median
from scipy.optimize import OptimizeWarning
import accuracy
from prior_verification import solve_square
from residual_solver import residual

OUT=Path(__file__).resolve().parent
P=tuple(F(49*j,10000) for j in (5,6,7,8,9))
LOSSES=(4,5,6,8,11)
CONF_TAIL=F(1,20)


def breakpoints():
    planes=[]
    terms=[]
    for i,p in enumerate(P):
        e=tuple(F(i==j) for j in range(len(P)))
        planes.append((e,F(0)))
        ratio=p/CONF_TAIL
        c=tuple(ratio-x for x in e)
        terms.append((ratio,c))
        planes.extend([(c,-ratio),(c,1-ratio)])
    coeffs=set()
    for group in combinations(planes,len(P)):
        y=solve_square([r for r,_ in group],[v for _,v in group])
        if y is None or min(y)<0:
            continue
        coeffs.add(tuple(max(0,min(1,a+sum(x*z for x,z in zip(y,c))))
                         for a,c in terms))
    return coeffs


def needed_k(values,d):
    mins=sorted(x for x in values if x<d)
    return next(k for k in range(2,len(values)+1) if k>len(mins) or sum(mins[:k])>=d)


def main():
    clipped=breakpoints()
    probs=[[1-p,p] for p in P]
    rows=[]
    for loss in permutations(LOSSES):
        v=[[0,x] for x in loss]
        lattice,tail=accuracy.sharp_checker(v,probs)
        bound=min(sum(w*a for w,a in zip(cf,loss)) for cf in clipped)
        lo,hi=0,len(lattice)
        while hi-lo>1:
            mid=(lo+hi)//2
            if tail(lattice[mid])>CONF_TAIL:
                lo=mid
            else:
                hi=mid
        var=lattice[lo]
        p0,p1=tail(var),tail(var+1)
        assert p0>CONF_TAIL>p1
        k0,k1=(needed_k(loss,t) for t in (var,var+1))
        for t,p in ((var,p0),(var+1,p1)):
            val,_=residual(v,[[float(x) for x in row] for row in probs],t)
            assert abs(val-float(p))<1e-9
        rounded=max(x for x in lattice if x<=bound)
        assert var<=rounded
        rows.append([*loss,var,str(bound),rounded,k0,k1,str(p0),str(p1)])
    with (OUT/'weighted_defaults.csv').open('w',newline='') as f:
        w=csv.writer(f)
        w.writerow(['weight1','weight2','weight3','weight4','weight5','sharp_var','BLLW_fraction',
                    'support_rounded_BLLW','k_at_var','k_at_var_plus_one','tail_at_var','tail_at_var_plus_one'])
        w.writerows(rows)
    from collections import Counter
    print('k pairs',Counter((r[8],r[9]) for r in rows))
    for tag,ix in [('raw',6),('support_rounded',7)]:
        gaps=[(F(r[ix])-r[5])/F(r[ix]) for r in rows]
        print(tag,len(gaps),'strict',sum(x>0 for x in gaps),'mean',float(sum(gaps)/len(gaps)),
              'median',float(median(gaps)),'max',float(max(gaps)))
if __name__=='__main__':
    main()
