# Sharp tail bounds for aggregate losses when any k positive losses suffice

Research manuscript and reproducibility supplement, 24 November 2026. The author field remains open, as in the preceding draft.

## Paper

From the root of the extracted directory, build the manuscript using a standard TeX Live installation.

```sh
pdflatex -halt-on-error Sharp_Tail_Bounds.tex
pdflatex -halt-on-error Sharp_Tail_Bounds.tex
```

Theorem 1 gives the sorted residual capacity, the sharp aggregate tail, and attainment of both optimizations. Its mathematical proof is self-contained. Section 2 gives a counterexample if the support hypothesis is dropped. Section 3 calculates a mixed-law example with continuous positive severities. Section 4 gives rational certificates for two portfolios differing only in the name to which two severity amounts are assigned. Section 5 gives the reduced finite linear program and compares exact worst-case VaR with a support-rounded convolution bound on two constructed families. Section 6 maps the mathematical steps to Lean.

## Formal proof

The companion Lean archive is incorporated under `lean/` with its original sources and logs. The main statement is `Finance.sharp_tail_sorted` in `lean/FinanceTheorem.lean`. Both attainment assertions and the boundary cases are in this statement. The general selector is imported for equation (4). The final proof uses the equivalent finite capacity calculation. The bibliography credits the classical probability and convex-geometric identities. The Korean working notes for the earlier residual tool are in `supplement/Joint_Residual_Tool_Guide_KO.md`.

```sh
cd lean
./verify.sh
```

See `lean/README.md` for the pinned Lean and mathlib versions and commands to reproduce the axiom and kernel checks. The 17 new modules, 38 unchanged prerequisite files and prior build evidence have been reused byte for byte. The worked examples, finite-support LP display and numerical comparisons are mathematical consequences or separate checks. The scope of the Lean theorem is recorded in Section 6 and the Korean coverage note.

## Numerical checks

From the root of a fresh extraction:

```sh
cd supplement
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python accuracy.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python weighted_defaults.py
python -c "from prior_verification import exact_examples; exact_examples()"
```

Tested with Python 3.12, NumPy 2.3.5 and SciPy 1.17.0. Keep Python assertions enabled. These scripts regenerate the two CSVs beside the scripts. The full coupling LP uses floating-point optimization to find candidate primal and dual certificates and checks their feasibility and matching objective values over the rationals. The convolution bound uses rational vertex enumeration. As a separate check, the reduced LP agrees with the certified tails to the tolerances in the scripts. In the weighted-default script only inclusion-minimal successful configurations are enumerated: removing a redundant name retains the success while freeing capacity. This gives the same optimum as the formulation in Section 5.

The 90 three-name allocations and 120 five-name permutations were rerun for this edition. Both regenerated CSVs match the archived CSVs byte for byte. The two reproduction logs report the unrounded and the support-rounded comparison. The paper displays the support-rounded results, including all tied cases in the denominator.
