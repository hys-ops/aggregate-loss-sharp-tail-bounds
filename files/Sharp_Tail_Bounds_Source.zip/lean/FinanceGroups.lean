import FinanceOrder
import FinanceCompletion
open MeasureTheory Set Finset
open scoped BigOperators NNReal ENNReal
noncomputable section
namespace Finance
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Upper half of the packing lemma for any family of groups, with arbitrary labels. -/
theorem group_upper {G : Type*} [Fintype G] (I : G → Finset ι) (k : ℕ) (hk : 0 < k)
    (sz : ∀ g, (I g).card = k) (w : G → ℝ) (hw : ∀ g, 0 ≤ w g)
    (r : ι → ℝ) (hr : ∀ i, 0 ≤ r i)
    (use : ∀ i, (∑ g, if i ∈ I g then w g else 0) ≤ r i) :
    ∑ g,w g ≤ jointCapacity r k hk := by
  apply (le_capacity_iff _ hk _).2
  apply (cap_iff_cuts r k _ hr (sum_nonneg fun g _ => hw g)).1
  calc
    _ = ∑ i, ∑ g, if i ∈ I g then w g else 0 := by
      rw [mul_sum,sum_comm]
      apply sum_congr rfl
      intro g _
      simp [Finset.sum_ite_mem,sz]
    _ ≤ _ := sum_le_sum fun i _ => le_min (use i) (sum_le_sum fun g _ => by split_ifs <;> simp [hw])

def groupOf (K : Finset ι) (σ : Equiv.Perm ι) : Finset ι := K.map σ.symm.toEmbedding
omit [Fintype ι] [DecidableEq ι] in
@[simp] theorem mem_groupOf (K : Finset ι) (σ : Equiv.Perm ι) (i : ι) :
    i ∈ groupOf K σ ↔ σ i ∈ K := by
  change i ∈ K.map σ.symm.toEmbedding ↔ _
  simp
omit [Fintype ι] [DecidableEq ι] in
@[simp] theorem card_groupOf (K : Finset ι) (σ : Equiv.Perm ι) : (groupOf K σ).card = K.card := by
  simp [groupOf]

/-- Construct the k-name severity blocks from the actual residual marginal measures.
Zero residual names can have arbitrary normalized reserves and are never assigned positive mass. -/
theorem severity_groups (K : Finset ι) (hk : 0 < K.card) (δ : ι → FiniteMeasure ℝ≥0)
    (S : ι → Set ℝ≥0) (hS : ∀ i, ∀ᵐ x ∂(δ i : Measure ℝ≥0), x ∈ S i)
    (d : ℝ≥0) (ck : ∀ A : Finset ι, A.card = K.card → ∀ x : ι → ℝ≥0,
      (∀ i ∈ A, x i ∈ S i) → d ≤ ∑ i ∈ A,x i) :
    ∃ m : Equiv.Perm ι → FiniteMeasure (ι → ℝ≥0),
      (∑ σ, ((m σ).mass:ℝ)) = jointCapacity (fun i => ((δ i).mass:ℝ)) K.card hk ∧
      (∀ σ, ∀ᵐ x ∂(m σ : Measure (ι → ℝ≥0)), d ≤ ∑ i ∈ groupOf K σ,x i) ∧
      ∀ i, (∑ σ, if i ∈ groupOf K σ then (m σ : Measure (ι → ℝ≥0)).map (Function.eval i) else 0) ≤ (δ i : Measure ℝ≥0) := by
  classical
  let r (i : ι) : ℝ := (δ i).mass
  obtain ⟨w,hw,ht,hu⟩ := (maximum_packing K hk r (fun i => (δ i).mass.property)).1.2
  let a (σ : Equiv.Perm ι) : ℝ≥0 := ⟨w σ,hw σ⟩
  let q (i : ι) : Measure ℝ≥0 := ((δ i).normalize : Measure ℝ≥0)
  let p := Measure.pi q
  have (i : ι) : IsProbabilityMeasure (q i) := (δ i).normalize.property
  let m (σ : Equiv.Perm ι) : FiniteMeasure (ι → ℝ≥0) := ⟨a σ • p,inferInstance⟩
  have orig i : ((δ i).mass:ℝ≥0∞) • q i = (δ i : Measure ℝ≥0) :=
    (congrArg (fun l : FiniteMeasure ℝ≥0 => (l : Measure ℝ≥0)) (δ i).self_eq_mass_smul_normalize).symm
  have hm σ : (m σ).mass = a σ := by
    apply ENNReal.coe_injective
    rw [FiniteMeasure.ennreal_mass]
    change ((a σ:ℝ≥0∞) • p) univ = _
    simp [p,Measure.smul_apply]
  refine ⟨m,by simp_rw [hm]; exact ht,?_,?_⟩
  · intro σ
    change ∀ᵐ x ∂((a σ:ℝ≥0∞) • p), _
    by_cases ha : a σ = 0
    · simp [ha]
    apply Measure.ae_smul_measure
    have members (i : ↥(groupOf K σ)) : ∀ᵐ x ∂p, x i.val ∈ S i.val := by
      have hmem := (mem_groupOf K σ i.val).mp i.property
      have pos : 0 < w σ := lt_of_le_of_ne (hw σ) (fun h => ha (Subtype.ext h.symm))
      have hwle : w σ ≤ r i.val := by
        apply le_trans _ (hu i.val)
        have := single_le_sum (s:=univ) (f:=fun τ : Equiv.Perm ι => if τ i.val ∈ K then w τ else 0)
          (fun τ _ => by split_ifs <;> simp [hw]) (mem_univ σ)
        simpa [hmem] using this
      have hn : ((δ i.val).mass:ℝ≥0∞) ≠ 0 := by
        exact_mod_cast (show (δ i.val).mass ≠ 0 by
          intro h; change w σ ≤ ((δ i.val).mass:ℝ) at hwle; rw [h] at hwle; exact pos.not_ge hwle)
      have hq : ∀ᵐ v ∂q i.val,v ∈ S i.val := (Measure.ae_ennreal_smul_measure_iff hn).1
        (by rw [orig]; exact hS _)
      exact (measurePreserving_eval q i.val).quasiMeasurePreserving.ae hq
    filter_upwards [ae_all_iff.mpr members] with x hx
    exact ck _ (card_groupOf K σ) x (fun i hi => hx ⟨i,hi⟩)
  · intro i
    have coeff : (∑ σ, if σ i ∈ K then a σ else 0) ≤ (δ i).mass := by
      exact_mod_cast (show ∑ σ, ((if σ i ∈ K then a σ else 0 : ℝ≥0):ℝ) ≤ ((δ i).mass:ℝ) by
        have cast (σ : Equiv.Perm ι) : ((if σ i ∈ K then a σ else 0 : ℝ≥0):ℝ) = if σ i ∈ K then w σ else 0 := by split_ifs <;> rfl
        simp_rw [cast]; exact hu i)
    have each (σ : Equiv.Perm ι) :
        (if i ∈ groupOf K σ then (m σ : Measure (ι → ℝ≥0)).map (Function.eval i) else 0) =
        ((if σ i ∈ K then a σ else 0 : ℝ≥0):ℝ≥0∞) • q i := by
      by_cases hi : σ i ∈ K
      · simp only [mem_groupOf,hi,↓reduceIte]
        exact (Measure.map_smul _ (measurable_pi_apply i).aemeasurable).trans
          (congrArg ((a σ:ℝ≥0∞) • ·) (measurePreserving_eval q i).map_eq)
      · simp [hi]
    simp_rw [each]
    rw [← Finset.sum_smul,← ENNReal.ofNNReal_finsetSum,← orig i]
    apply Measure.le_iff.mpr
    intro s _
    simp only [Measure.smul_apply,smul_eq_mul]
    exact mul_le_mul_of_nonneg_right (by exact_mod_cast coeff) zero_le
end Finance
