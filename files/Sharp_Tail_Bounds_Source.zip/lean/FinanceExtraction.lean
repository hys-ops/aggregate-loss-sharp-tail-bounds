import FinanceSelection
import FinanceCompletion
open MeasureTheory Set Finset
open scoped NNReal ENNReal BigOperators
noncomputable section
namespace Finance
variable {ι : Type*} [Fintype ι] [DecidableEq ι]
abbrev Losses (ι : Type*) := ι → ℝ≥0

def Marginals (μ : ι → Measure ℝ≥0) (γ : Measure (Losses ι)) : Prop :=
  ∀ i, γ.map (Function.eval i) = μ i

def Covers (μ : ι → Measure ℝ≥0) (d : ℝ≥0) (k : ℕ) : Prop :=
  ∃ S : ι → Set ℝ≥0, (∀ i, MeasurableSet (S i) ∧ μ i (S i) = 1) ∧
    ∀ A : Finset ι, A.card = k → ∀ a : Losses ι,
      (∀ i ∈ A, a i ∈ S i ∧ 0 < a i ∧ a i < d) → d ≤ ∑ i ∈ A,a i

def Tail (d : ℝ≥0) : Set (Losses ι) := {x | d ≤ ∑ i,x i}
omit [DecidableEq ι] in
theorem measurable_tail (d : ℝ≥0) : MeasurableSet (Tail (ι:=ι) d) :=
  measurableSet_le measurable_const (Finset.measurable_fun_sum _ fun i _ => measurable_pi_apply i)

/-- Each successful sample contributes exactly once, with no repeated use of a marginal.
The stored measures are restrictions of the actual full Borel joint law. -/
theorem extract_reserves (μ : ι → Measure ℝ≥0) (γ : Measure (Losses ι)) [IsProbabilityMeasure γ]
    (hmarg : Marginals μ γ) (d : ℝ≥0) (hd : 0 < d) (k : ℕ) (hk : 0 < k)
    (hc : Covers μ d k) :
    ∃ m : Finset ι → FiniteMeasure (Losses ι),
      (∀ A, ∀ᵐ x ∂(m A : Measure (Losses ι)), Witness d k (fun i => (x i : ℝ)) A) ∧
      (∀ i, (∑ A : Finset ι, if i ∈ A then (m A : Measure (Losses ι)).map (Function.eval i) else 0) ≤ μ i) ∧
      (∑ A, ((m A).mass : ℝ≥0∞)) = γ (Tail d) := by
  classical
  obtain ⟨S,hS,hkS⟩ := hc
  let X (i : ι) (x : Losses ι) : ℝ := x i
  have hX (i) : Measurable (X i) := NNReal.continuous_coe.measurable.comp (measurable_pi_apply i)
  let Sr (i : ι) : Set ℝ := {a | a.toNNReal ∈ S i}
  have hSr (i) : ∀ᵐ x ∂γ, X i x ∈ Sr i := by
    have he : γ (Function.eval i ⁻¹' S i) = 1 := by
      rw [← Measure.map_apply (μ:=γ) (measurable_pi_apply i) (hS i).1,hmarg i,(hS i).2]
    have ae : ∀ᵐ x ∂γ, x i ∈ S i := (mem_ae_iff_prob_eq_one ((hS i).1.preimage (measurable_pi_apply i))).mpr he
    exact ae.mono fun x hx => by simpa [X,Sr] using hx
  have hkSr (A : Finset ι) (h : A.card = k) (a : ι → ℝ)
      (ha : ∀ i ∈ A, a i ∈ Sr i ∧ 0 < a i ∧ a i < d) : (d:ℝ) ≤ ∑ i ∈ A,a i := by
    have hh := hkS A h (fun i => (a i).toNNReal) (fun i hi => ⟨(ha i hi).1,
      Real.toNNReal_pos.mpr (ha i hi).2.1,by
        exact_mod_cast (show ((a i).toNNReal:ℝ) < d by simpa [Real.coe_toNNReal _ (ha i hi).2.1.le] using (ha i hi).2.2)⟩)
    have eq : (∑ i ∈ A, (((a i).toNNReal:ℝ≥0):ℝ)) = ∑ i ∈ A, a i :=
      sum_congr rfl fun i hi => Real.coe_toNNReal _ (ha i hi).2.1.le
    rw [← eq]; exact_mod_cast hh
  obtain ⟨B,hB,hdis,hit,union⟩ := select_success_blocks γ X hX d (by exact_mod_cast hd) k hk
    Sr hSr (fun i => Filter.Eventually.of_forall fun x => (x i).property) hkSr
  let m (A : Finset ι) : FiniteMeasure (Losses ι) := ⟨γ.restrict (B A),inferInstance⟩
  refine ⟨m,fun A => (ae_restrict_mem (hB A)).mono (hit A),?_,?_⟩
  · intro i
    apply Measure.le_iff.mpr
    intro s hs
    rw [Measure.finsetSum_apply,← hmarg i,Measure.map_apply (measurable_pi_apply i) hs]
    let C : Set (Losses ι) := (fun x => x i) ⁻¹' s
    have hC : MeasurableSet C := (measurable_pi_apply i) hs
    calc
      _ ≤ ∑ A : Finset ι, γ (C ∩ B A) := by
        apply sum_le_sum
        intro A _
        by_cases hi : i ∈ A
        · simp only [hi, ↓reduceIte]; change (γ.restrict (B A)).map _ s ≤ _
          rw [Measure.map_apply (measurable_pi_apply i) hs,Measure.restrict_apply hC]
        · simp [hi]
      _ = γ (⋃ A, C ∩ B A) := by
        rw [measure_iUnion _ (fun A => hC.inter (hB A)),tsum_fintype]
        exact fun A A' h => (hdis h).mono Set.inter_subset_right Set.inter_subset_right
      _ ≤ _ := measure_mono (iUnion_subset fun _ => Set.inter_subset_left)
  · have mass (A) : ((m A).mass:ℝ≥0∞) = γ (B A) := by
      rw [FiniteMeasure.ennreal_mass]; change γ.restrict (B A) univ = _; simp
    simp_rw [mass]
    have U := measure_iUnion (μ:=γ) hdis hB
    rw [tsum_fintype] at U
    rw [← U]
    apply measure_congr
    exact union.trans (Filter.Eventually.of_forall fun x => by
      apply propext; change ((d:ℝ) ≤ ∑ i,(x i:ℝ)) ↔ d ≤ ∑ i,x i
      norm_cast)
end Finance
