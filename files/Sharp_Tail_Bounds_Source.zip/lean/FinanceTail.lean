import FinanceExtraction
import FinanceReserve
import Mathlib.MeasureTheory.Measure.Prokhorov
import Mathlib.Topology.Semicontinuity.Basic
open Set Finset MeasureTheory Filter
open scoped ENNReal NNReal BigOperators Topology
noncomputable section
namespace Finance
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

def worst (μ : ι → Measure ℝ≥0) (d : ℝ≥0) : ℝ≥0∞ :=
  ⨆ (γ : ProbabilityMeasure (Losses ι)) (_ : Marginals μ γ), (γ : Measure (Losses ι)) (Tail d)

def Reserved (μ : ι → Measure ℝ≥0) (d : ℝ≥0) (k : ℕ)
    (m : Finset ι → FiniteMeasure (Losses ι)) : Prop :=
  (∀ A, ∀ᵐ x ∂(m A : Measure (Losses ι)), Witness d k (fun i => (x i : ℝ)) A) ∧
    ∀ i, (∑ A : Finset ι, if i ∈ A then (m A : Measure (Losses ι)).map (Function.eval i) else 0) ≤ μ i

/-- Exactly the sharp probability, expressed before eliminating the k-name blocks. Both
directions quantify over actual Borel measures. -/
theorem worst_eq_reserved (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)]
    (d : ℝ≥0) (hd : 0 < d) (k : ℕ) (hk : 0 < k) (ck : Covers μ d k) :
    worst μ d = ⨆ (m : Finset ι → FiniteMeasure (Losses ι)) (_ : Reserved μ d k m),
      ((min 1 (∑ A,(m A).mass):ℝ≥0):ℝ≥0∞) := by
  classical
  unfold worst
  apply le_antisymm
  · apply iSup_le; intro γ; apply iSup_le; intro hγ
    obtain ⟨m,hit,use,eq⟩ := extract_reserves μ γ hγ d hd k hk ck
    have ub : (γ : Measure (Losses ι)) (Tail d) ≤ 1 := prob_le_one
    calc
      _ ≤ ((min 1 (∑ A,(m A).mass) : ℝ≥0):ℝ≥0∞) := by
        have q : ((∑ A,(m A).mass : ℝ≥0):ℝ≥0∞) = (γ : Measure (Losses ι)) (Tail d) := by rw [ENNReal.ofNNReal_finsetSum]; exact eq
        rcases le_total (∑ A,(m A).mass) 1 with h|h
        · rw [min_eq_right h,q]
        · rw [min_eq_left h]; exact ub
      _ ≤ _ := le_iSup_of_le m (by have hm : Reserved μ d k m := ⟨hit,use⟩; simp [hm])

  · apply iSup_le; intro m; apply iSup_le; intro hm
    obtain ⟨γ,hγ,marg,ht⟩ := realize_reserves id m μ d hm.2 (fun A =>
      (hm.1 A).mono fun x h => by
        change d ≤ ∑ i ∈ A,x i
        exact_mod_cast (show (d:ℝ) ≤ ∑ i ∈ A,(x i:ℝ) from h.2.2.2))
    exact ht.trans (le_iSup_of_le (⟨γ,hγ⟩ : ProbabilityMeasure _) (le_iSup_of_le marg le_rfl))

omit [DecidableEq ι] in
/-- The outer supremum is achieved for arbitrary Borel nonnegative loss laws. -/
theorem worst_attained (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)] (d : ℝ≥0) :
    ∃ γ : ProbabilityMeasure (Losses ι), Marginals μ γ ∧ (γ : Measure (Losses ι)) (Tail d) = worst μ d := by
  classical
  let C : Set (ProbabilityMeasure (Losses ι)) := {γ | Marginals μ γ}
  have ne : C.Nonempty := ⟨⟨Measure.pi μ,inferInstance⟩,fun i => (measurePreserving_eval μ i).map_eq⟩
  have closed : IsClosed C := by
    let q (i : ι) : ProbabilityMeasure ℝ≥0 := ⟨μ i,inferInstance⟩
    have e : C = ⋂ i, {γ : ProbabilityMeasure (Losses ι) | γ.map (Function.eval i) = q i} := by
      ext γ; simp only [C,Marginals,Set.mem_ofPred_eq,Set.mem_iInter]
      exact forall_congr' fun i => ⟨fun h => Subtype.ext h, fun h => congrArg ProbabilityMeasure.toMeasure h⟩
    rw [e]
    exact isClosed_iInter fun i => isClosed_eq (ProbabilityMeasure.continuous_map (continuous_apply i)) continuous_const
  have tight : IsTightMeasureSet {((γ : ProbabilityMeasure (Losses ι)) : Measure (Losses ι)) | γ ∈ C} := by
    apply isTightMeasureSet_iff_exists_isCompact_measure_compl_le.mpr
    intro ε he
    let n : ℝ≥0∞ := (Fintype.card ι : ℝ≥0∞) + 1
    have hn : n ≠ ⊤ := by simp [n]
    have hn0 : n ≠ 0 := by simp [n]
    have H (i : ι) := isTightMeasureSet_iff_exists_isCompact_measure_compl_le.mp
      (isTightMeasureSet_singleton (μ := μ i)) (ε / n) (ENNReal.div_pos he.ne' hn)
    choose K hK hμ using H
    refine ⟨Set.univ.pi K,isCompact_univ_pi hK,?_⟩
    rintro _ ⟨γ,hγ,rfl⟩
    have sub : (Set.univ.pi K)ᶜ ⊆ ⋃ i, (Function.eval i : Losses ι → ℝ≥0) ⁻¹' (K i)ᶜ := by
      intro x hx
      simpa [Set.mem_univ_pi] using hx
    calc
      _ ≤ (γ : Measure (Losses ι)) (⋃ i, (Function.eval i : Losses ι → ℝ≥0) ⁻¹' (K i)ᶜ) := measure_mono sub
      _ ≤ ∑' i, (γ : Measure (Losses ι)) ((Function.eval i : Losses ι → ℝ≥0) ⁻¹' (K i)ᶜ) := measure_iUnion_le _
      _ ≤ ∑ i : ι, ε/n := by
        rw [tsum_fintype]
        apply sum_le_sum
        intro i _
        rw [← Measure.map_apply (μ:=(γ : Measure (Losses ι))) (measurable_pi_apply i) (hK i).isClosed.measurableSet.compl, hγ i]
        exact hμ i _ (mem_singleton _)
      _ ≤ n*(ε/n) := by
        simp only [sum_const,card_univ,nsmul_eq_mul]
        apply mul_le_mul_of_nonneg_right _ zero_le
        exact le_add_right le_rfl
      _ = ε := by rw [mul_comm,ENNReal.div_mul_cancel hn0 hn]
  have compact : IsCompact C := closed.closure_eq ▸ isCompact_closure_of_isTightMeasureSet tight
  have cf : IsClosed (Tail (ι:=ι) d) := isClosed_le continuous_const
    (continuous_finsetSum _ fun i _ => continuous_apply i)
  have usc : UpperSemicontinuous (fun γ : ProbabilityMeasure (Losses ι) => (γ : Measure (Losses ι)) (Tail d)) :=
    upperSemicontinuous_iff_limsup_le.mpr fun _ =>
      ProbabilityMeasure.limsup_measure_closed_le_of_tendsto tendsto_id cf
  obtain ⟨γ,hγ,hmax⟩ := (usc.upperSemicontinuousOn C).exists_isMaxOn ne compact
  exact ⟨γ,hγ,le_antisymm (le_iSup_of_le γ (le_iSup_of_le hγ le_rfl))
    (iSup_le fun γ' => iSup_le fun hγ' => hmax hγ')⟩
end Finance
