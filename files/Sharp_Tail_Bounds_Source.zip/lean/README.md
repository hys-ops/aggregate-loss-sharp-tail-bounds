# Lean verification of sharp tail bounds for aggregate losses

The main theorem is `Finance.sharp_tail_sorted` in `FinanceTheorem.lean`. It includes the two attained optima and the formula that uses the largest residual masses. The statement uses arbitrary Borel probability measures on the nonnegative reals. `Finance.Covers` is condition (C_k) on full-measure Borel sets. The companion Korean note maps each part of the manuscript to the source.

## Reproduce

Install the toolchain specified in `lean-toolchain` and use Python 3.11 or newer, Bash and sha256sum. From this directory run

```sh
./verify.sh
```

The script fetches the pinned mathlib cache, builds the unchanged prerequisite modules and runs `replay.py`. For a machine with those pinned dependencies already built, the last step alone suffices.

```sh
lake env python3 replay.py
```

Each run creates an empty temporary directory for the 17 finance modules. It compiles each one with warnings treated as errors, checks the output of `#print axioms` against the standard axiom set, and replays the declarations of the finance modules from their imports with `leanchecker`. Outputs go to `logs/` by default. To keep the archived logs intact, pass a new directory as the argument to `replay.py`.

The 38 transitive prerequisite files under `prior/` are byte-for-byte copies from the existing joint residual selector verification. `prior.sha256` records their hashes. They are dependencies, not new finance results. The recorded run started from the pinned mathlib and previously built prerequisite objects. The finance objects were all rebuilt from source. The toolchain, mathlib revision and dependency manifest are included. No compiled objects or network credentials are bundled.

## Evidence

- `logs/clean-build.log` records the version and every finance module compiled.
- `logs/axioms.log` contains the two main theorem statements and each axiom report.
- `logs/kernel-replay.log` records the independent replay from imports of each new module by Lean's kernel.
- `Sharp_Tail_Lean_Coverage_KO.md` explains how the statements match the paper and where the proof uses mathlib.

The general fixed-mass criterion is imported in `FinanceSelector.lean` for the one-hot substitution. The final tail bound uses the equivalent finite capacity calculation. The numerical VaR tables and their Python certificates are outside this formalization.
