"""Clean verification of the finance modules against an already built dependency path."""
from __future__ import annotations
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import os
import re
import shutil
import subprocess
import sys
import tomllib

ROOT = Path(__file__).resolve().parent
EXPECTED_AXIOMS = {'propext', 'Classical.choice', 'Quot.sound'}
SAFE_NAME = re.compile(r'^[A-Za-z0-9_.]+$')

def main():
    cfg = tomllib.loads((ROOT / 'lakefile.toml').read_text())
    modules = next(lib['roots'] for lib in cfg['lean_lib'] if lib['name'] == 'FinanceVerification')
    logdir = Path(sys.argv[1]).resolve() if len(sys.argv) == 2 else ROOT / 'logs'
    logdir.mkdir(parents=True, exist_ok=True)
    lean = shutil.which('lean')
    checker = shutil.which('leanchecker')
    if not lean or not checker:
        raise SystemExit('Run with the pinned Lean toolchain and its leanchecker on PATH.')
    for line in (ROOT/'prior.sha256').read_text().splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == expected, name
    audit_src = (ROOT/'Audit.lean').read_text()
    public = re.findall(r'^#print axioms ([\w.]+)$', audit_src, re.M)
    with TemporaryDirectory(prefix='finance-clean-') as tmp:
        tmp = Path(tmp)
        # Only prior-project objects and mathlib may be reused. Every finance object
        # is created locally in this invocation, in dependency order.
        for m in modules:
            shutil.copyfile(ROOT/f'{m}.lean', tmp/f'{m}.lean')
        shutil.copyfile(ROOT/'Audit.lean',tmp/'Audit.lean')
        env = os.environ.copy()
        env['LEAN_PATH'] = os.pathsep.join([str(tmp), env.get('LEAN_PATH','')])
        with (logdir/'clean-build.log').open('w') as out:
            def say(txt):
                print(txt, file=out, flush=True)
                print(txt, flush=True)
            say(subprocess.check_output([lean,'--version'],text=True).strip())
            say('mathlib ' + cfg['require'][0]['rev'])
            say('Empty finance object directory at start: ' + str(not list(tmp.glob('*.olean'))))
            say(f'{len((ROOT/"prior.sha256").read_text().splitlines())} unchanged prerequisite sources match SHA-256.')
            built = set()
            for m in modules:
                source=(tmp/f'{m}.lean').read_text()
                for dep in re.findall(r'^import (Finance\w+)$',source,re.M):
                    assert dep in built and (tmp/f'{dep}.olean').is_file(), (m,dep)
                say(f'lean -DwarningAsError=true -o {m}.olean {m}.lean')
                subprocess.run([lean,'-j2','-DwarningAsError=true','-o',f'{m}.olean',f'{m}.lean'],cwd=tmp,env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
                built.add(m)
            say(f'PASS: {len(built)} finance modules built from source.')
        res=subprocess.run([lean,'-j2','-DwarningAsError=true','Audit.lean'],cwd=tmp,env=env,capture_output=True,text=True)
        txt=res.stdout+res.stderr
        (logdir/'axioms.log').write_text(txt)
        res.check_returncode()
        for name in public:
            found=re.search(r"'"+re.escape(name)+r"' depends on axioms: \[([^\]]*)\]",txt)
            if found:
                axioms={a.strip() for a in found[1].split(',') if a.strip()}
                if axioms - EXPECTED_AXIOMS:
                    raise RuntimeError((name,axioms))
            elif f"'{name}' does not depend on any axioms" not in txt:
                raise RuntimeError('Missing axiom report for ' + name)
        print(f'PASS: {len(public)} axiom reports checked.',flush=True)
        with (logdir/'kernel-replay.log').open('w') as out:
            for m in modules:
                assert SAFE_NAME.fullmatch(m)
                print('leanchecker ' + m,file=out,flush=True)
                subprocess.run([checker,m],cwd=tmp,env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
            print(f'PASS: {len(modules)} modules replayed from imports.',file=out)
        print('PASS: kernel replay completed.',flush=True)
if __name__ == '__main__':
    main()
