import FinanceCuts
import Mathlib.MeasureTheory.Measure.Restrict
import Mathlib.MeasureTheory.Constructions.BorelSpace.Real
import Mathlib.MeasureTheory.Group.Arithmetic
import Mathlib.Order.Disjointed
open Set Finset MeasureTheory
open scoped BigOperators ENNReal
noncomputable section
namespace Finance
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Before selecting a witness, its names must be positive, and a non-singleton
must contain only losses below the threshold. -/
def Witness (d : ℝ) (k : ℕ) (x : ι → ℝ) (A : Finset ι) : Prop :=
  A.Nonempty ∧ A.card ≤ k ∧ (∀ i ∈ A, 0 < x i ∧ (1 < A.card → x i < d)) ∧
    d ≤ ∑ i ∈ A, x i

omit [DecidableEq ι] in
theorem successful_iff_witness (d : ℝ) (hd : 0 < d) (k : ℕ) (hk : 0 < k)
    (x : ι → ℝ) (hx : ∀ i, 0 ≤ x i)
    (ck : ∀ A : Finset ι, A.card = k → (∀ i ∈ A, 0 < x i ∧ x i < d) → d ≤ ∑ i ∈ A, x i) :
    d ≤ ∑ i, x i ↔ ∃ A, Witness d k x A := by
  classical
  constructor
  · intro h
    by_cases high : ∃ i, d ≤ x i
    · obtain ⟨i,hi⟩ := high
      refine ⟨{i},singleton_nonempty _,by simp; omega,?_,by simpa using hi⟩
      intro j hj
      obtain rfl := mem_singleton.mp hj
      exact ⟨hd.trans_le hi,by simp⟩
    · push Not at high
      let P := univ.filter fun i => 0 < x i
      have hp (i : ι) (hi : i ∈ P) : 0 < x i := (mem_filter.mp hi).2
      have total : (∑ i ∈ P, x i) = ∑ i, x i := by
        apply sum_subset (subset_univ _)
        intro i _ hi
        exact le_antisymm (le_of_not_gt fun h => hi (mem_filter.mpr ⟨mem_univ _,h⟩)) (hx i)
      by_cases enough : k ≤ P.card
      · obtain ⟨A,hA,sz⟩ := exists_subset_card_eq enough
        have good : ∀ i ∈ A, 0 < x i ∧ x i < d := fun i hi => ⟨hp i (hA hi), high i⟩
        exact ⟨A,card_pos.mp (sz ▸ hk),sz.le,fun i hi => ⟨(good i hi).1,fun _ => high i⟩,
          ck A sz good⟩
      · refine ⟨P,?_,by omega,fun i hi => ⟨hp i hi,fun _ => high i⟩,total ▸ h⟩
        by_contra! he
        rw [he,sum_empty] at total
        linarith
  · rintro ⟨A,_,_,_,ha⟩
    exact ha.trans (sum_le_sum_of_subset_of_nonneg (subset_univ _) fun i _ _ => hx i)

variable {Ω : Type*} [MeasurableSpace Ω]
omit [DecidableEq ι] in
theorem measurable_witness (d : ℝ) (k : ℕ) (A : Finset ι) (X : ι → Ω → ℝ)
    (hX : ∀ i, Measurable (X i)) :
    MeasurableSet {ω | Witness d k (fun i => X i ω) A} := by
  classical
  unfold Witness
  repeat' apply MeasurableSet.inter
  · exact MeasurableSet.const _
  · exact MeasurableSet.const _
  · change MeasurableSet {ω | ∀ i ∈ A, 0 < X i ω ∧ (1 < A.card → X i ω < d)}
    simp only [Set.ofPred_forall]
    apply MeasurableSet.iInter
    intro i
    apply MeasurableSet.iInter
    intro _
    apply MeasurableSet.inter (measurableSet_lt measurable_const (hX i))
    by_cases h : 1 < A.card
    · simp only [h,true_implies]
      exact measurableSet_lt (hX i) measurable_const
    · simp only [h,false_implies]
      exact MeasurableSet.univ
  · exact measurableSet_le measurable_const (Finset.measurable_fun_sum _ fun i _ => hX i)

omit [DecidableEq ι] in
/-- Disjoint measurable success blocks; their union agrees almost surely with the
tail event for any joint law under the original full-measure (C_k) hypothesis. -/
theorem select_success_blocks (p : Measure Ω) (X : ι → Ω → ℝ) (hX : ∀ i, Measurable (X i))
    (d : ℝ) (hd : 0 < d) (k : ℕ) (hk : 0 < k)
    (S : ι → Set ℝ) (hS : ∀ i, ∀ᵐ ω ∂p, X i ω ∈ S i) (hx : ∀ i, ∀ᵐ ω ∂p, 0 ≤ X i ω)
    (ck : ∀ A : Finset ι, A.card = k → ∀ a : ι → ℝ,
      (∀ i ∈ A, a i ∈ S i ∧ 0 < a i ∧ a i < d) → d ≤ ∑ i ∈ A, a i) :
    ∃ B : Finset ι → Set Ω, (∀ A, MeasurableSet (B A)) ∧
      Pairwise (fun A C => Disjoint (B A) (B C)) ∧
      (∀ A ω, ω ∈ B A → Witness d k (fun i => X i ω) A) ∧
      (⋃ A, B A) =ᵐ[p] {ω | d ≤ ∑ i, X i ω} := by
  classical
  let e := Fintype.equivFin (Finset ι)
  let G (j : Fin (Fintype.card (Finset ι))) := {ω | Witness d k (fun i => X i ω) (e.symm j)}
  let B (A : Finset ι) := disjointed G (e A)
  have sub (A : Finset ι) (ω : Ω) (h : ω ∈ B A) : Witness d k (fun i => X i ω) A := by
    have hh := disjointed_subset G (e A) h
    simpa [G] using hh
  have hG (j) : MeasurableSet (G j) := measurable_witness d k (e.symm j) X hX
  have hB (A) : MeasurableSet (B A) := by
    rw [show B A = G (e A) \ (Finset.Iio (e A)).sup G from rfl, Finset.sup_eq_iSup]
    exact (hG _).diff (MeasurableSet.iUnion fun j => MeasurableSet.iUnion fun _ => hG j)
  refine ⟨B,hB,
    fun _ _ h => disjoint_disjointed G (e.injective.ne h),sub,?_⟩
  have hu : (⋃ A, B A) = ⋃ j, G j := by
    change (⋃ A, disjointed G (e A)) = _
    rw [e.surjective.iUnion_comp, iUnion_disjointed]
  rw [hu]
  filter_upwards [ae_all_iff.mpr hS,ae_all_iff.mpr hx] with ω hSω hxω
  apply propext
  rw [successful_iff_witness d hd k hk _ hxω]
  · simp [G,e.symm.surjective.exists]
  · intro A hA h
    exact ck A hA _ (fun i hi => ⟨hSω i,h i hi⟩)

end Finance
