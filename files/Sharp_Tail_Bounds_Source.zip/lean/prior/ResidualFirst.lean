import ResidualFinite
open MeasureTheory Set Filter Function
open scoped ENNReal BigOperators
namespace Residual
noncomputable section
variable {X I : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
    [MeasurableSpace X] [BorelSpace X] [SecondCountableTopology X]
    [Fintype I] [MeasurableSpace I] [MeasurableSingletonClass I]

theorem first_from_couplings (ρ : Measure X) [IsProbabilityMeasure ρ] (j k : X → I)
    (mj : Measurable j) (mk : Measurable k) (c : CoupledCells ρ j k)
    (f : X → ℝ) (mf : Measurable f) (lf : MemLp f 2 ρ)
    (aff : ∀ x y, f (midpoint (x,y)) = (f x+f y)/2) :
    let ζ := ρ-midLaw (mass ρ j) (mass ρ k) c.plans
    2*(∫ x,f x ∂ζ) = ∑ i,(mass ρ j i-mass ρ k i)*change ρ j k f i/(mass ρ j i+mass ρ k i) := by
  let a := mass ρ j
  let b := mass ρ k
  let γ := c.plans
  let η := midLaw a b γ
  have hf := lf.integrable (by norm_num : (1:ℝ≥0∞) ≤ 2)
  have each (i : I) :
      ((∫ x in j ⁻¹' {i},f x ∂ρ)+(∫ x in k ⁻¹' {i},f x ∂ρ)) -
      2*(Vortex.harmonicMass (a i) (b i)*(∫ z,f (midpoint z) ∂(γ i : Measure (X × X)))) =
      (a i-b i)*change ρ j k f i/(a i+b i) := by
    let P := (γ i : Measure (X × X))
    let u := fun z : X × X => f z.1
    let v := fun z : X × X => f z.2
    have L := endpoint_int ρ P Prod.fst measurable_fst _ (c.left i) f mf
    have R := endpoint_int ρ P Prod.snd measurable_snd _ (c.right i) f mf
    change a i*(∫ z,u z ∂P)=_ at L
    change b i*(∫ z,v z ∂P)=_ at R
    unfold change; rw [← L,←R]
    have h := harmonic_linear (a i) (b i) (∫ z,u z ∂P) (∫ z,v z ∂P) measureReal_nonneg measureReal_nonneg
    by_cases ha : a i=0
    · simpa [ha,Vortex.harmonicMass] using h
    by_cases hb : b i=0
    · simpa [hb,Vortex.harmonicMass] using h
    have iu := (endpoint_memLp ρ P Prod.fst measurable_fst _ ha (c.left i) f mf lf).integrable (by norm_num : (1:ℝ≥0∞) ≤ 2)
    have iv := (endpoint_memLp ρ P Prod.snd measurable_snd _ hb (c.right i) f mf lf).integrable (by norm_num : (1:ℝ≥0∞) ≤ 2)
    have eqm : (∫ z,f (midpoint z) ∂P) = ((∫ z,u z ∂P)+(∫ z,v z ∂P))/2 := by
      rw [←integral_add (f:=u) (g:=v) iu iv,←integral_div]
      exact integral_congr_ae (.of_forall fun z => aff z.1 z.2)
    change _ - 2*(Vortex.harmonicMass (a i) (b i)*(∫ z,f (midpoint z) ∂P)) = _
    rw [eqm,←mul_assoc]; exact h
  have tot := Finset.sum_congr (s₁:=Finset.univ) rfl (fun i _ => each i)
  simp only [Finset.sum_sub_distrib,Finset.sum_add_distrib,←Finset.mul_sum,
    fiber_sum ρ j mj f hf,fiber_sum ρ k mk f hf] at tot
  have eqn := midLaw_integral ρ a b γ (fun _ => measureReal_nonneg) (fun _ => measureReal_nonneg)
    c.dominated f mf hf
  change 2*(∫ x,f x ∂(ρ-η)) = ∑ i,(a i-b i)*change ρ j k f i/(a i+b i)
  rw [residual_int c.dominated f hf]
  linarith only [tot,eqn]

end
end Residual
