import Geometry
open MeasureTheory Set
open scoped ENNReal
namespace Vortex
noncomputable section
def sliceImpulse (ρ : ℝ) (E B : Set Space) (z : ℝ) :=
  ∫ x : H, (x.1^2+x.2^2)*(patch E ρ (x,z)-patch B ρ (x,z))

/-- The physical inputs for ONE time. E0, E and B are the actual initial,
current and reference patches. No density/velocity conclusion is a field. -/
structure TimeInputs (E0 E B : Set Space) (ρ R a b : ℝ) (U V : Space → H) : Prop where
  measurableE : MeasurableSet E
  measurableB : MeasurableSet B
  l1 : Integrable (fun y => |patch E ρ y-patch B ρ y|)
  slices : ∀ᵐ z : ℝ, volume (slice E z) ≠ ∞ ∧ volume (slice B z) ≠ ∞ ∧
    volume.real (slice E z) = volume.real (slice B z)
  slab : ∀ᵐ z : ℝ, z ∉ Icc a b → exchanged E B z = 0
  slabImpulse : ∀ᵐ z : ℝ, z ∉ Icc a b → sliceImpulse ρ E B z = 0
  impulseInt : Integrable (fun y : Space => (y.1.1^2+y.1.2^2)*(patch E ρ y-patch B ρ y))
  conserve : impulse E B ρ = impulse E0 B ρ
  deltaInt : IntegrableOn (exchanged E B) (Icc a b)
  deltaSqInt : IntegrableOn (fun z => (exchanged E B z)^2) (Icc a b)
  rearrange : ∀ᵐ z ∂volume.restrict (Icc a b),
    (ρ/Real.pi)*(exchanged E B z)^2 ≤ sliceImpulse ρ E B z
  ovInt : Integrable (overlap E B ρ Prod.fst U V)
  fluxInt : Integrable (fun y => flux (patch E ρ y) (patch B ρ y) (U y) (V y))
  endpoint : (∫ y, flux (patch E ρ y) (patch B ρ y) (U y) (V y)) ≤
    R^2*∫ y, (patch E ρ y-patch B ρ y)^2/(patch E ρ y+patch B ρ y)

theorem at_time {E0 E B : Set Space} {ρ R a b : ℝ} {U V : Space → H}
    (hρ : 0 < ρ) (hab : a ≤ b) (h : TimeInputs E0 E B ρ R a b U V) :
    ρ * (∫ y in E ∩ B, distSq (vel y.1 (U y)) (vel y.1 (V y))) ≤
    4*R^2*Real.sqrt (Real.pi*ρ*(b-a)*impulse E0 B ρ) := by
  let f := fun y : Space => (y.1.1^2+y.1.2^2)*(patch E ρ y-patch B ρ y)
  have fi : Integrable f ((volume : Measure H).prod (volume : Measure ℝ)) := h.impulseInt
  have fi' : Integrable (sliceImpulse ρ E B) volume := fi.integral_prod_right
  have iz : impulse E B ρ = ∫ z in Icc a b, sliceImpulse ρ E B z := by
    change (∫ y, f y) = _
    rw [Measure.volume_eq_prod H ℝ, integral_prod_symm _ fi,← integral_indicator measurableSet_Icc]
    apply integral_congr_ae
    filter_upwards [h.slabImpulse] with z hz
    change sliceImpulse ρ E B z = _
    by_cases hmem : z ∈ Icc a b
    · simp [hmem]
    · simpa [hmem] using hz hmem
  have hann := integral_mono_ae (h.deltaSqInt.const_mul (ρ/Real.pi)) fi'.integrableOn h.rearrange
  rw [integral_const_mul,← iz] at hann
  have hf := patch_fubini E B ρ a b hρ h.measurableE h.measurableB h.l1 h.slices h.slab
  have hh := overlap_velocity E B ρ R a b (impulse E0 B ρ) (impulse E B ρ) _
    U V hρ hab h.deltaInt h.deltaSqInt hf hann h.conserve h.ovInt h.fluxInt h.endpoint
  have eqv : overlap E B ρ Prod.fst U V =
      (E ∩ B).indicator (fun y => ρ * distSq (vel y.1 (U y)) (vel y.1 (V y))) := by
    classical funext y; by_cases hy : y ∈ E ∩ B <;> simp [overlap,hy]
  rwa [eqv,integral_indicator (h.measurableE.inter h.measurableB),integral_const_mul] at hh

theorem almost_every_time (times : Set ℝ) (E0 B : Set Space)
    (E : ℝ → Set Space) (U : ℝ → Space → H) (V : Space → H) (ρ R a b : ℝ)
    (hρ : 0 < ρ) (hab : a ≤ b)
    (h : ∀ᵐ t ∂volume.restrict times, TimeInputs E0 (E t) B ρ R a b (U t) V) :
    ∀ᵐ t ∂volume.restrict times,
    ρ*(∫ y in E t ∩ B, distSq (vel y.1 (U t y)) (vel y.1 (V y))) ≤
      4*R^2*Real.sqrt (Real.pi*ρ*(b-a)*impulse E0 B ρ) :=
  h.mono (fun _ ht => at_time hρ hab ht)
end
end Vortex
