import ContinuumDensity
import ContinuumPower
import Torque
import Mathlib.Analysis.InnerProductSpace.PiL2

open MeasureTheory Filter Set
open scoped Topology NNReal ENNReal BoundedContinuousFunction BigOperators InnerProductSpace
namespace Vortex
noncomputable section

def physicalCost (K : Set Space) (z : Space × K) := quadraticCost z.1 z.2.1

def linearScore (y x : Space) := y.1.1*x.1.1 + y.1.2*x.1.2 + y.2*x.2

def verticalStretch (e : ℝ) (x : Space) : Space := (x.1,e*x.2)

private def stretchedVector (e : ℝ) (x : Space) : EuclideanSpace ℝ (Fin 3) :=
  WithLp.toLp 2 ![x.1.1,x.1.2,e*x.2]

def stretchedCoordinates (K : Set Space) [CompactSpace K] (e : ℝ) : K →ᵇ EuclideanSpace ℝ (Fin 3) :=
  BoundedContinuousFunction.mkOfCompact ⟨fun x => stretchedVector e x.1,by
    apply (PiLp.continuous_toLp ..).comp
    apply continuous_pi
    intro i
    fin_cases i <;> simp [Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_two] <;> fun_prop⟩

/-- Labels of ordinary or vertically transformed physical power cells.
The parameters are additive intercepts, and all ties may be resolved measurably. -/
def PowerLabels {K : Set Space} (T : ProbabilityMeasure K) {N : ℕ} (site : Fin N → Space)
    (physical : K → Space) (tag : K → Fin N) : Prop :=
  ∃ w : Fin N → ℝ, ∀ᵐ x ∂(T : Measure K), ∀ j,
    linearScore (site j) (physical x) + w j ≤ linearScore (site (tag x)) (physical x) + w (tag x)

/-- Existence of semidiscrete intercepts attaining the prescribed cell masses.
This is a static OT input for a nonatomic uniform physical law. -/
def PowerRealization (K : Set Space) (T : ProbabilityMeasure K) (P : ProbabilityMeasure Space) : Prop :=
  ∀ G : CommonGrid Space, ∃ tag : K → Fin G.size, Measurable tag ∧
    T.map tag = P.map G.label ∧ PowerLabels T G.site Subtype.val tag

/-- Only a finite theorem: for each finite distinct site list compare two
physical power diagrams by their actual raw moments and actual label masses.
The physical body has been stretched vertically by e. -/
def StretchedFiniteTool (K : Set Space) [CompactSpace K] (T : ProbabilityMeasure K)
    (R Ht : ℝ) : Prop :=
  ∀ e : ℝ, 0 < e → ∀ (N : ℕ) (site : Fin N → Space), Function.Injective site →
  ∀ a b : K → Fin N, Measurable a → Measurable b →
  PowerLabels T site (fun x => verticalStretch e x.val) a →
  PowerLabels T site (fun x => verticalStretch e x.val) b →
  (∑ i, ‖rawMoment T a (stretchedCoordinates K e) i - rawMoment T b (stretchedCoordinates K e) i‖^2 /
    ((T : Measure K).real (a ⁻¹' {i}) + (T : Measure K).real (b ⁻¹' {i}))) ≤
    (R^2+e^2*Ht^2) * ∑ i, discr ((T : Measure K).real (a ⁻¹' {i})) ((T : Measure K).real (b ⁻¹' {i}))

theorem reciprocal_scores (e : ℝ) (he : e ≠ 0) (x y : Space) :
    linearScore (verticalStretch e⁻¹ y) (verticalStretch e x) = linearScore y x := by
  dsimp [linearScore,verticalStretch]
  field_simp

private theorem stretched_injective (e : ℝ) (he : e ≠ 0) : Function.Injective (verticalStretch e) := by
  rintro ⟨y,u⟩ ⟨z,v⟩ h
  have hz := congrArg Prod.fst h
  have hv := congrArg Prod.snd h
  exact Prod.ext hz ((mul_right_inj' he).mp hv)

private theorem fit_of_scores {K : Set Space} (T : ProbabilityMeasure K) (G : CommonGrid Space)
    (P : ProbabilityMeasure Space) {a : K → Fin G.size}
    (ha : Measurable a) (hm : T.map a=P.map G.label) (power : PowerLabels T G.site Subtype.val a) :
    CellFit (physicalCost K) G P T a := by
  obtain ⟨w,hw⟩ := power
  let norm2 (y : Space) := y.1.1^2+y.1.2^2+y.2^2
  have hc : Continuous (physicalCost K) := by unfold physicalCost quadraticCost distSq; fun_prop
  apply cellFit_of_power_cells (physicalCost K) hc G P T a ha hm
    (fun i => norm2 (G.site i)+2*w i)
  filter_upwards [hw] with x hx
  intro j
  have h := hx j
  dsimp [linearScore] at h
  dsimp [physicalCost,quadraticCost,distSq,norm2]
  linarith

private theorem real_densityFlux_stretched {K : Set Space} [CompactSpace K] (e : ℝ)
    (p q : ℝ≥0) (x v : K) :
    densityFlux p q (stretchedCoordinates K e x) (stretchedCoordinates K e v) =
    stretchedFlux e p q x.val.1 v.val.1 x.val.2 v.val.2 := by
  rw [densityFlux,EuclideanSpace.real_norm_sq_eq,Fin.sum_univ_three]
  rfl

/-- From the *finite* tool and static OT, the horizontal endpoint integral
over the entire geostrophic space. No continuum estimate is an input.
Reciprocal rescaling preserves the finite labels before taking weak limits. -/
theorem physical_horizontal_endpoint (K : Set Space) [CompactSpace K]
    (P Q : ProbabilityMeasure Space) (T : ProbabilityMeasure K)
    (p q : Space → ℝ≥0) (hp : Measurable p) (hq : Measurable q)
    (hP : (P : Measure Space) = volume.withDensity (fun y => (p y : ℝ≥0∞)))
    (hQ : (Q : Measure Space) = volume.withDensity (fun y => (q y : ℝ≥0∞)))
    (U V : Space → K) (hU : Measurable U) (hV : Measurable V)
    (uniqueP : ∀ η, SequentialRanks.certifiedPlan (physicalCost K) P T η → η=P.map (fun y => (y,U y)))
    (uniqueQ : ∀ η, SequentialRanks.certifiedPlan (physicalCost K) Q T η → η=Q.map (fun y => (y,V y)))
    (R Ht : ℝ) (cellsP : PowerRealization K T P) (cellsQ : PowerRealization K T Q)
    (finite : StretchedFiniteTool K T R Ht) :
    (∫ y, flux (p y) (q y) (U y).val.1 (V y).val.1) ≤ R^2*(∫ y, discr (p y) (q y)) := by
  apply endpoint_of_stretches volume _ _ _ _ (fun y => (U y).val.2) (fun y => (V y).val.2) R Ht
    (.of_forall (fun y => add_nonneg (p y).coe_nonneg (q y).coe_nonneg))
  intro e he
  have nc : 0 ≤ R^2+e^2*Ht^2 := by positivity
  let k := stretchedCoordinates K e
  have hfinite (G : CommonGrid Space) : ∃ a b : K → Fin G.size,
      CellFit (physicalCost K) G P T a ∧ CellFit (physicalCost K) G Q T b ∧
      ∑ i, ‖rawMoment T a k i-rawMoment T b k i‖^2 /
        ((P : Measure Space).real (G.label ⁻¹' {i})+(Q : Measure Space).real (G.label ⁻¹' {i})) ≤
      (Real.sqrt (R^2+e^2*Ht^2))^2 * ∑ i, discr ((P : Measure Space).real (G.label ⁻¹' {i})) ((Q : Measure Space).real (G.label ⁻¹' {i})) := by
    obtain ⟨a,ma,ha,pa⟩ := cellsP G
    obtain ⟨b,mb,hb,pb⟩ := cellsQ G
    have ca := fit_of_scores T G P ma ha pa
    have cb := fit_of_scores T G Q mb hb pb
    refine ⟨a,b,ca,cb,?_⟩
    have equiv (tag : K → Fin G.size) (pt : PowerLabels T G.site Subtype.val tag) :
        PowerLabels T (fun i => verticalStretch e⁻¹ (G.site i)) (fun x => verticalStretch e x.val) tag := by
      obtain ⟨w,hw⟩ := pt
      exact ⟨w,by simpa only [reciprocal_scores e he.ne'] using hw⟩
    have bd := finite e he G.size (fun i => verticalStretch e⁻¹ (G.site i))
      ((stretched_injective _ (inv_ne_zero he.ne')).comp G.injective) a b ma mb (equiv a pa) (equiv b pb)
    simpa only [Real.sq_sqrt nc, ca.mass_at,cb.mass_at] using bd
  have hc : Continuous (physicalCost K) := by unfold physicalCost quadraticCost distSq; fun_prop
  have bound := density_endpoint_from_finite_tool (physicalCost K) hc k volume p q hp hq P Q T
    hP hQ U V hU hV uniqueP uniqueQ (Real.sqrt (R^2+e^2*Ht^2)) hfinite
  have intg := density_flux_integrable volume p q hp hq P Q hP hQ k U V hU hV
  constructor
  · simpa only [k,real_densityFlux_stretched] using intg
  · simpa only [k,real_densityFlux_stretched,Real.sq_sqrt nc] using bound

end
end Vortex
