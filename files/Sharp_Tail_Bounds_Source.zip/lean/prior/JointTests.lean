import JointBody

open MeasureTheory Set
open scoped BigOperators
noncomputable section
namespace JointResidual
variable {X : Type*} [MeasurableSpace X] {d : ℕ}

/-- The extra constant coordinate enforces any prescribed residual mass, including 0 and 1. -/
theorem fixedMass_iff (ρ : Measure X) [IsProbabilityMeasure ρ] (F : X → Vec d)
    (hF : ∀ j, Integrable (fun x => F x j) ρ) (u : ℝ) (v : Vec d) :
    (∃ g, Residual.admissibleWeight ρ u g ∧ v=value ρ F g) ↔
    ∀ (a : Vec d) (t : ℝ), test a v - t*u ≤ ∫ x,max (test a (F x)-t) 0 ∂ρ := by
  let G (x : X) : Vec (d+1) := Fin.cons 1 (F x)
  have hi : ∀ j, Integrable (fun x => G x j) ρ := by
    intro j; refine Fin.cases (integrable_const _) (fun i => hF i) j
  have aux (g : X → ℝ) : value ρ G g = Fin.cons (∫ x,g x ∂ρ) (value ρ F g) := by
    funext j; refine Fin.cases ?_ (fun _ => rfl) j
    simp [value,G]
  have mem : (∃ g, Residual.admissibleWeight ρ u g ∧ v=value ρ F g) ↔
      Fin.cons u v ∈ body ρ G := by
    constructor
    · rintro ⟨g,hg,rfl⟩
      exact ⟨g,⟨hg.1,hg.2.1⟩,by rw [aux,hg.2.2]⟩
    · rintro ⟨g,hg,eq⟩
      rw [aux] at eq
      exact ⟨g,⟨hg.1,hg.2,(congrFun eq 0).symm⟩,funext fun j => congrFun eq j.succ⟩
  have pair (a b : Vec d) (c z : ℝ) :
      test (Fin.cons c a) (Fin.cons z b)= c*z+test a b := by
    simp [test,Fin.sum_univ_succ]
  rw [mem,mem_iff_tests ρ G hi]
  constructor
  · intro h a t
    simpa only [G,pair,mul_one,neg_mul,sub_eq_add_neg,add_comm] using h (Fin.cons (-t) a)
  · intro h a
    let b := fun j : Fin d => a j.succ
    have eq : a=Fin.cons (a 0) b := by funext j; exact Fin.cases rfl (fun _ => rfl) j
    rw [eq]
    simpa only [G,pair,mul_one,neg_mul,sub_neg_eq_add,sub_eq_add_neg,neg_neg,add_comm] using h b (-(a 0))

def SignedSelector (ρ : Measure X) (s : X → ℝ) : Prop :=
  Measurable s ∧ ∀ᵐ x ∂ρ, |s x|≤1

private theorem centered_value (ρ : Measure X) (F : X → Vec d)
    (hF : ∀ j,Integrable (fun x => F x j) ρ) {g} (hg : Selector ρ g) (j : Fin d) :
    value ρ F (fun x => 2*g x-1) j = 2 * value ρ F g j - ∫ x,F x j ∂ρ := by
  unfold value; simp only [sub_mul,one_mul,mul_assoc]
  rw [integral_sub ((Residual.admissible_integrable_mul hg.adm (hF j)).const_mul _) (hF j),integral_const_mul]

theorem signed_iff (ρ : Measure X) [IsProbabilityMeasure ρ] (F : X → Vec d)
    (hF : ∀ j, Integrable (fun x => F x j) ρ) (v : Vec d) :
    (∃ s, SignedSelector ρ s ∧ v=value ρ F s) ↔
    ∀ a, |test a v|≤∫ x, |test a (F x)| ∂ρ := by
  let z : Vec d := fun j => (v j + ∫ x,F x j ∂ρ)/2
  have mem : (∃ s, SignedSelector ρ s ∧ v=value ρ F s) ↔ z ∈ body ρ F := by
    constructor
    · rintro ⟨s,hs,e⟩
      let g := fun x => (s x+1)/2
      have hg : Selector ρ g := ⟨(hs.1.add_const _).div_const _,hs.2.mono fun x hx => by
        have hh := abs_le.mp hx; constructor <;> dsimp [g] <;> linarith [hh.1,hh.2]⟩
      have idg : (fun x => 2*g x-1)=s := funext fun x => by dsimp [g]; ring
      refine ⟨g,hg,funext fun j => ?_⟩
      have key := centered_value ρ F hF hg j
      rw [idg,←e] at key; dsimp [z]; linarith
    · rintro ⟨g,hg,e⟩
      refine ⟨fun x => 2*g x-1,⟨(measurable_const.mul hg.1).sub_const _,hg.2.mono fun x hx =>
        abs_le.mpr ⟨by linarith [hx.1],by linarith [hx.2]⟩⟩,funext fun j => ?_⟩
      rw [centered_value ρ F hF hg,←e]; dsimp [z]; ring
  have scale (a : Vec d) : 2*test a z=test a v + ∫ x,test a (F x) ∂ρ := by
    unfold test
    rw [integral_finsetSum _ (fun j _ => (hF j).const_mul (a j)),←Finset.sum_add_distrib,Finset.mul_sum]
    exact Finset.sum_congr rfl fun j _ => by rw [integral_const_mul]; dsimp [z]; ring
  have pospart (a : Vec d) :
      2*(∫ x,max (test a (F x)) 0 ∂ρ)=(∫ x,test a (F x) ∂ρ)+∫ x,|test a (F x)| ∂ρ := by
    have h := testIntegrable hF a
    rw [←integral_add h h.abs,←integral_const_mul]
    apply integral_congr_ae; filter_upwards with x
    by_cases hp : 0≤test a (F x)
    · rw [max_eq_left hp,abs_of_nonneg hp]; ring
    · rw [max_eq_right (le_of_not_ge hp),abs_of_neg (lt_of_not_ge hp)]; ring
  have negTest (a w : Vec d) : test (-a) w = -test a w := by simp [test,Finset.sum_neg_distrib]
  rw [mem,mem_iff_tests ρ F hF]
  constructor
  · intro h a
    have up (b : Vec d) : test b v ≤ ∫ x,|test b (F x)| ∂ρ := by
      linarith only [scale b,pospart b,h b]
    have low := up (-a)
    simp only [negTest,abs_neg] at low
    exact abs_le.mpr ⟨by linarith only [low],up a⟩
  · intro h a
    have e := (le_abs_self (test a v)).trans (h a)
    linarith only [e,scale a,pospart a]

end JointResidual
