import ContinuumCells

open MeasureTheory Filter Set
open scoped Topology NNReal ENNReal BoundedContinuousFunction BigOperators InnerProductSpace
namespace Vortex
noncomputable section
set_option linter.unusedSectionVars false

variable {Y K F : Type*}
    [MetricSpace Y] [SecondCountableTopology Y] [CompleteSpace Y] [MeasurableSpace Y] [BorelSpace Y]
    [MetricSpace K] [SecondCountableTopology K] [CompleteSpace K] [MeasurableSpace K] [BorelSpace K]
    [NormedAddCommGroup F] [InnerProductSpace ℝ F] [CompleteSpace F] [SecondCountableTopology F]
    [MeasurableSpace F] [BorelSpace F]

def densityFlux (p q : ℝ≥0) (u v : F) : ℝ := ‖(p : ℝ) • u - (q : ℝ) • v‖^2 / (p+q : ℝ)

private def baryDifference (p q : ℝ≥0) (u v : F) : F :=
  (p+q : ℝ)⁻¹ • ((p : ℝ) • u - (q : ℝ) • v)

private theorem bary_bound (p q : ℝ≥0) (u v : F) {C : ℝ} (hu : ‖u‖ ≤ C) (hv : ‖v‖ ≤ C) :
    ‖baryDifference p q u v‖ ≤ C := by
  have n : 0 ≤ (p+q : ℝ) := add_nonneg p.coe_nonneg q.coe_nonneg
  rcases eq_or_lt_of_le n with h|h
  · simp [baryDifference,←h]; exact (norm_nonneg u).trans hu
  · rw [baryDifference,norm_smul,Real.norm_eq_abs,abs_of_nonneg (inv_nonneg.mpr n),← div_eq_inv_mul]
    apply (div_le_iff₀ h).mpr
    calc _ ≤ ‖(p : ℝ) • u‖+‖(q : ℝ) • v‖ := norm_sub_le .. 
         _ = (p : ℝ)*‖u‖+(q : ℝ)*‖v‖ := by simp [norm_smul,Real.norm_eq_abs]
         _ ≤ (p : ℝ)*C+(q : ℝ)*C := add_le_add (mul_le_mul_of_nonneg_left hu p.coe_nonneg)
           (mul_le_mul_of_nonneg_left hv q.coe_nonneg)
         _ = C*((p : ℝ)+q) := by ring

private theorem bary_pair (p q : ℝ≥0) (u v g : F) :
    (p+q : ℝ)*⟪baryDifference p q u v,g⟫_ℝ =
      (p : ℝ)*⟪u,g⟫_ℝ - (q : ℝ)*⟪v,g⟫_ℝ := by
  by_cases h : (p+q : ℝ) = 0
  · have a : (p : ℝ)=0 := by linarith [p.coe_nonneg,q.coe_nonneg]
    have b : (q : ℝ)=0 := by linarith [p.coe_nonneg,q.coe_nonneg]
    simp [a,b]
  · simp only [baryDifference,real_inner_smul_left,inner_sub_left]
    field_simp

private theorem bary_energy (p q : ℝ≥0) (u v : F) :
    (p+q : ℝ)*‖baryDifference p q u v‖^2 = densityFlux p q u v := by
  unfold baryDifference densityFlux
  rw [norm_smul,Real.norm_eq_abs,abs_of_nonneg (inv_nonneg.mpr (add_nonneg p.coe_nonneg q.coe_nonneg))]
  by_cases h : (p+q : ℝ)=0
  · simp [h]
  · field_simp

private theorem density_mass (μ : Measure Y) (p : Y → ℝ≥0) (hp : Measurable p)
    (P : ProbabilityMeasure Y) (hP : (P : Measure Y)=μ.withDensity (fun y => (p y : ℝ≥0∞)))
    (A : Set Y) (hA : MeasurableSet A) :
    (P : Measure Y).real A = ∫ y in A, (p y : ℝ) ∂μ := by
  rw [Measure.real,hP,withDensity_apply _ hA,integral_eq_lintegral_of_nonneg_ae
    (Eventually.of_forall (fun y => (p y).coe_nonneg)) hp.coe_nnreal_real.aestronglyMeasurable]
  simp

private theorem real_density_integrable (μ : Measure Y) (p : Y → ℝ≥0) (hp : Measurable p)
    (P : ProbabilityMeasure Y) (hP : (P : Measure Y)=μ.withDensity (fun y => (p y : ℝ≥0∞))) :
    Integrable (fun y => (p y : ℝ)) μ := by
  have intg : Integrable (fun _ : Y => (1 : ℝ)) (μ.withDensity (fun y => (p y : ℝ≥0∞))) :=
    hP ▸ integrable_const _
  simpa [NNReal.smul_def,smul_eq_mul] using (integrable_withDensity_iff_integrable_smul hp).mp intg

private theorem discr_int {μ : Measure Y} (p q : Y → ℝ≥0) (hp : Measurable p) (hq : Measurable q)
    (ip : Integrable (fun y => (p y : ℝ)) μ) (iq : Integrable (fun y => (q y : ℝ)) μ) :
    Integrable (fun y => discr (p y) (q y)) μ := by
  have a := hp.coe_nnreal_real
  have b := hq.coe_nnreal_real
  refine (ip.add iq).mono' (((a.sub b).pow_const 2).div (a.add b)).aestronglyMeasurable ?_
  filter_upwards with y
  have p0 := (p y).coe_nonneg
  have q0 := (q y).coe_nonneg
  change ‖((p y : ℝ)-q y)^2/(p y+q y : ℝ)‖ ≤ (p y+q y : ℝ)
  rw [Real.norm_eq_abs,abs_of_nonneg (div_nonneg (sq_nonneg _) (add_nonneg p0 q0))]
  rcases eq_or_lt_of_le (add_nonneg p0 q0) with h|h
  · simp [←h]
  · apply (div_le_iff₀ h).mpr
    nlinarith only [mul_nonneg p0 q0]

theorem density_flux_integrable (μ : Measure Y) (p q : Y → ℝ≥0)
    (hp : Measurable p) (hq : Measurable q) (P Q : ProbabilityMeasure Y)
    (hP : (P : Measure Y)=μ.withDensity (fun y => (p y : ℝ≥0∞)))
    (hQ : (Q : Measure Y)=μ.withDensity (fun y => (q y : ℝ≥0∞)))
    (k : K →ᵇ F) (U V : Y → K) (hU : Measurable U) (hV : Measurable V) :
    Integrable (fun y => densityFlux (p y) (q y) (k (U y)) (k (V y))) μ := by
  have h : Integrable (fun y => ((p y : ℝ)+q y)*‖k‖^2) μ :=
    ((real_density_integrable μ p hp P hP).add (real_density_integrable μ q hq Q hQ)).mul_const _
  have hm : Measurable (fun y => densityFlux (p y) (q y) (k (U y)) (k (V y))) := by
    unfold densityFlux
    have pu := hp.coe_nnreal_real.smul (k.continuous.measurable.comp hU)
    have qv := hq.coe_nnreal_real.smul (k.continuous.measurable.comp hV)
    exact ((pu.sub qv).norm.pow_const 2).div (hp.coe_nnreal_real.add hq.coe_nnreal_real)
  apply h.mono' hm.aestronglyMeasurable
  filter_upwards with y
  rw [← bary_energy,Real.norm_eq_abs,abs_of_nonneg (mul_nonneg (add_nonneg (p y).coe_nonneg (q y).coe_nonneg) (sq_nonneg _))]
  exact mul_le_mul_of_nonneg_left
    (pow_le_pow_left₀ (norm_nonneg _) (bary_bound _ _ _ _ (k.norm_coe_le_norm _) (k.norm_coe_le_norm _)) _)
    (add_nonneg (p y).coe_nonneg (q y).coe_nonneg)

/-- The finite cell inequality gives the actual continuum density formula,
without a plan-stability, narrow convergence, Jensen, lower semicontinuity,
bounded-support-of-observations, or continuum endpoint premise. The two
transport inputs are stated separately: existence of finite power cells with
the finite inequality, and uniqueness of the limiting cyclic graph plans. -/
theorem density_endpoint_from_finite_tool
    (c : Y × K → ℝ) (hc : Continuous c) (k : K →ᵇ F)
    (μ : Measure Y) (p q : Y → ℝ≥0) (hp : Measurable p) (hq : Measurable q)
    (P Q : ProbabilityMeasure Y) (T : ProbabilityMeasure K)
    (hP : (P : Measure Y)=μ.withDensity (fun y => (p y : ℝ≥0∞)))
    (hQ : (Q : Measure Y)=μ.withDensity (fun y => (q y : ℝ≥0∞)))
    (U V : Y → K) (hU : Measurable U) (hV : Measurable V)
    (uniqueP : ∀ η, SequentialRanks.certifiedPlan c P T η → η = P.map (fun y => (y,U y)))
    (uniqueQ : ∀ η, SequentialRanks.certifiedPlan c Q T η → η = Q.map (fun y => (y,V y)))
    (R : ℝ)
    (finiteTool : ∀ G : CommonGrid Y, ∃ a b : K → Fin G.size,
      CellFit c G P T a ∧ CellFit c G Q T b ∧
      ∑ i, ‖rawMoment T a k i - rawMoment T b k i‖^2 /
        ((P : Measure Y).real (G.label ⁻¹' {i})+(Q : Measure Y).real (G.label ⁻¹' {i})) ≤
      R^2 * ∑ i, discr ((P : Measure Y).real (G.label ⁻¹' {i})) ((Q : Measure Y).real (G.label ⁻¹' {i}))) :
    (∫ y, densityFlux (p y) (q y) (k (U y)) (k (V y)) ∂μ) ≤
      R^2*(∫ y, discr (p y) (q y) ∂μ) := by
  let m := (P : Measure Y)+(Q : Measure Y)
  let f := fun y => baryDifference (p y) (q y) (k (U y)) (k (V y))
  have pm := hp.coe_nnreal_real
  have qm := hq.coe_nnreal_real
  have um := k.continuous.measurable.comp hU
  have vm := k.continuous.measurable.comp hV
  have mf : Measurable f := (pm.add qm).inv.smul ((pm.smul um).sub (qm.smul vm))
  have hf : MemLp f 2 m := (memLp_const ‖k‖).mono' mf.aestronglyMeasurable
    (.of_forall (fun y => bary_bound _ _ _ _ (k.norm_coe_le_norm _) (k.norm_coe_le_norm _)))
  have ms : Measurable (fun y => p y + q y) := hp.add hq
  have hm : m = μ.withDensity (fun y => ((p y+q y : ℝ≥0) : ℝ≥0∞)) := by
    dsimp [m]; rw [hP,hQ]
    rw [← withDensity_add_left hp.coe_nnreal_ennreal (fun y => (q y : ℝ≥0∞))]
    congr 1
  have idE : (∫ y, ‖f y‖^2 ∂m) = ∫ y, densityFlux (p y) (q y) (k (U y)) (k (V y)) ∂μ := by
    rw [hm,integral_withDensity_eq_integral_smul ms]
    exact integral_congr_ae (.of_forall (fun y => bary_energy _ _ _ _))
  rw [← idE]
  apply endpoint_from_finite_cells c hc k P Q T _ _ uniqueP uniqueQ f hf
  · intro g
    have mc : Continuous (fun z : Y × K => ⟪k z.2,g z.1⟫_ℝ) :=
      (k.continuous.comp continuous_snd).inner (g.continuous.comp continuous_fst)
    have mu : Measurable (fun y => (y,U y)) := measurable_id.prodMk hU
    have mv : Measurable (fun y => (y,V y)) := measurable_id.prodMk hV
    rw [ProbabilityMeasure.toMeasure_map,ProbabilityMeasure.toMeasure_map,integral_map mu.aemeasurable mc.aestronglyMeasurable,
      integral_map mv.aemeasurable mc.aestronglyMeasurable]
    have it (D : ProbabilityMeasure Y) (W : Y → K) (hw : Measurable W) :
        Integrable (fun y => ⟪k (W y),g y⟫_ℝ) (D : Measure Y) := by
      apply (integrable_const (‖k‖*‖g‖)).mono'
        ((k.continuous.measurable.comp hw).aestronglyMeasurable.inner g.continuous.aestronglyMeasurable)
      exact .of_forall (fun y => (norm_inner_le_norm _ _).trans
        (mul_le_mul (k.norm_coe_le_norm _) (g.norm_coe_le_norm _) (norm_nonneg _) (norm_nonneg _)))
    have ia := (integrable_withDensity_iff_integrable_smul hp).mp (hP ▸ it P U hU)
    have ib := (integrable_withDensity_iff_integrable_smul hq).mp (hQ ▸ it Q V hV)
    change _-_ = ∫ x, ⟪f x,g x⟫_ℝ ∂m
    rw [hP,hQ,hm,integral_withDensity_eq_integral_smul hp,integral_withDensity_eq_integral_smul hq,
      integral_withDensity_eq_integral_smul ms]
    rw [← integral_sub ia ib]
    exact integral_congr_ae (.of_forall (fun y => (bary_pair _ _ _ _ _).symm))
  · intro G
    obtain ⟨a,b,ha,hb,bd⟩ := finiteTool G
    refine ⟨a,b,ha,hb,bd.trans (mul_le_mul_of_nonneg_left ?_ (sq_nonneg _))⟩
    simp_rw [density_mass μ p hp P hP _ (G.measurableLabel (measurableSet_singleton _)),
      density_mass μ q hq Q hQ _ (G.measurableLabel (measurableSet_singleton _))]
    have ip := real_density_integrable μ p hp P hP
    have iq := real_density_integrable μ q hq Q hQ
    exact grid_discr_le G _ _ ip iq (.of_forall (fun y => (p y).coe_nonneg))
      (.of_forall (fun y => (q y).coe_nonneg)) (discr_int p q hp hq ip iq)

end
end Vortex
