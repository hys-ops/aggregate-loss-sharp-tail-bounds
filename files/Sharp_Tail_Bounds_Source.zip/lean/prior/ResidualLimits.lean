import ContinuumPlans
import Mathlib.MeasureTheory.Measure.Portmanteau
open MeasureTheory Filter Set
open scoped ENNReal Topology
namespace Residual
noncomputable section
variable {X : Type*} [MetricSpace X] [MeasurableSpace X] [BorelSpace X]
  [SecondCountableTopology X] [CompleteSpace X]

omit [CompleteSpace X] in
/-- A weak limit of measures dominated by uniformly scaled copies of one fixed finite
measure inherits the limiting domination. Open sets suffice by outer regularity. -/
theorem dominated_weak_limit (ρ : Measure X) [IsFiniteMeasure ρ]
    (p : ℕ → ProbabilityMeasure X) (P : ProbabilityMeasure X) (v : ℕ → ℝ≥0∞) (c : ℝ≥0∞)
    (hc : c ≠ ⊤) (hp : Tendsto p atTop (𝓝 P)) (hv : Tendsto v atTop (𝓝 c))
    (h : ∀ n,(p n : Measure X) ≤ v n • ρ) : (P : Measure X) ≤ c • ρ := by
  have bound (s : Set X) (hs : IsOpen s) : (P : Measure X) s ≤ (c • ρ) s := by
    have e := ProbabilityMeasure.le_liminf_measure_open_of_tendsto hp hs
    have t : Tendsto (fun n => v n * ρ s) atTop (𝓝 (c*ρ s)) :=
      ENNReal.Tendsto.mul hv (.inr (measure_ne_top _ _)) tendsto_const_nhds (.inr hc)
    change _ ≤ c*ρ s
    exact e.trans ((liminf_le_liminf (.of_forall fun n => h n s)).trans_eq t.liminf_eq)
  have : IsFiniteMeasure (c • ρ) := ⟨by rw [Measure.smul_apply,smul_eq_mul]; exact ENNReal.mul_lt_top hc.lt_top (measure_lt_top _ _)⟩
  intro A
  rw [A.measure_eq_iInf_isOpen (c • ρ)]
  exact le_iInf fun s => le_iInf fun sub => le_iInf (fun op => (measure_mono sub).trans (bound s op))

theorem plans_subsequence (p q : ℕ → ProbabilityMeasure X) (P Q : ProbabilityMeasure X)
    (hp : Tendsto p atTop (𝓝 P)) (hq : Tendsto q atTop (𝓝 Q))
    (γ : ℕ → ProbabilityMeasure (X × X))
    (hl : ∀ n,(γ n).map Prod.fst=p n) (hr : ∀ n,(γ n).map Prod.snd=q n) :
    ∃ π : ProbabilityMeasure (X × X), ∃ r : ℕ → ℕ, StrictMono r ∧
      Tendsto (γ ∘ r) atTop (𝓝 π) ∧ π.map Prod.fst=P ∧ π.map Prod.snd=Q := by
  let S := {((μ : ProbabilityMeasure (X × X)) : Measure (X × X)) | μ ∈ range γ}
  have tg (f : ℕ → ProbabilityMeasure X) (L : ProbabilityMeasure X) (hf : Tendsto f atTop (𝓝 L)) :
      IsTightMeasureSet {((z : ProbabilityMeasure X) : Measure X) | z ∈ range f} := by
    apply isTightMeasureSet_of_isCompact_closure
    exact hf.isCompact_insert_range.closure_of_subset (subset_insert ..)
  have tight : IsTightMeasureSet S := by
    apply IsTightMeasureSet.prodMk
    · apply (tg p P hp).subset
      rintro _ ⟨_,⟨μ,⟨n,rfl⟩,rfl⟩,rfl⟩
      exact ⟨_,⟨n,rfl⟩,(congrArg ProbabilityMeasure.toMeasure (hl n)).symm⟩
    · apply (tg q Q hq).subset
      rintro _ ⟨_,⟨μ,⟨n,rfl⟩,rfl⟩,rfl⟩
      exact ⟨_,⟨n,rfl⟩,(congrArg ProbabilityMeasure.toMeasure (hr n)).symm⟩
  have compact : IsCompact (closure (range γ)) := isCompact_closure_of_isTightMeasureSet tight
  obtain ⟨π,_,r,rmono,hπ⟩ := compact.tendsto_subseq (x := γ) (fun i => subset_closure (mem_range_self i))
  refine ⟨π,r,rmono,hπ,?_,?_⟩
  · have hh := ((ProbabilityMeasure.continuous_map (f:=(Prod.fst : X × X → X)) continuous_fst).tendsto π).comp hπ
    exact tendsto_nhds_unique hh ((hp.comp rmono.tendsto_atTop).congr fun n => (hl (r n)).symm)
  · have hh := ((ProbabilityMeasure.continuous_map (f:=(Prod.snd : X × X → X)) continuous_snd).tendsto π).comp hπ
    exact tendsto_nhds_unique hh ((hq.comp rmono.tendsto_atTop).congr fun n => (hr (r n)).symm)

end
end Residual
