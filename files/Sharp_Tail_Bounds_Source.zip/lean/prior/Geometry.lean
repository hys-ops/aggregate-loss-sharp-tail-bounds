import SG
import Mathlib.MeasureTheory.Integral.Prod
open MeasureTheory Set
open scoped ENNReal
namespace Vortex
noncomputable section
def slice (E : Set Space) (z : ℝ) : Set H := (fun x => (x,z)) ⁻¹' E
def exchanged (E B : Set Space) (z : ℝ) := volume.real (slice E z \ slice B z)
def impulse (E B : Set Space) (ρ : ℝ) :=
  ∫ y : Space, (y.1.1^2+y.1.2^2)*(patch E ρ y-patch B ρ y)

theorem equal_exchanges {A D : Set H} (hA : MeasurableSet A) (hD : MeasurableSet D)
    (fa : volume A ≠ ∞) (fd : volume D ≠ ∞) (same : volume.real A = volume.real D) :
    volume.real (A \ D) = volume.real (D \ A) := by
  have h := measureReal_sdiff_add_inter (μ := volume) hD fa
  have k := measureReal_sdiff_add_inter (μ := volume) hA fd
  rw [inter_comm D A] at k
  linarith

theorem section_l1 (ρ : ℝ) (hp : 0 < ρ) (A D : Set H) (ma : MeasurableSet A)
    (md : MeasurableSet D) (fa : volume A ≠ ∞) (fd : volume D ≠ ∞)
    (same : volume.real A = volume.real D) :
    (∫ x, |patch A ρ x-patch D ρ x|) = 2*ρ*volume.real (A \ D) := by
  classical
  have point (x : H) : |patch A ρ x-patch D ρ x| =
      (A \ D).indicator (fun _ => ρ) x + (D \ A).indicator (fun _ => ρ) x := by
    by_cases ha : x ∈ A <;> by_cases hd : x ∈ D <;>
      simp [patch,Set.indicator,ha,hd,abs_of_pos hp]
  have i1 : IntegrableOn (fun _ : H => ρ) (A \ D) :=
    integrableOn_const (measure_ne_top_of_subset sdiff_subset fa)
  have i2 : IntegrableOn (fun _ : H => ρ) (D \ A) :=
    integrableOn_const (measure_ne_top_of_subset sdiff_subset fd)
  simp_rw [point]
  rw [integral_add ((integrable_indicator_iff (ma.diff md)).2 i1) ((integrable_indicator_iff (md.diff ma)).2 i2),
    integral_indicator_const ρ (ma.diff md),integral_indicator_const ρ (md.diff ma),
    ← equal_exchanges ma md fa fd same]
  simp only [smul_eq_mul]; ring

/-- Plain Fubini for three-dimensional Lebesgue measure; equal slice areas are
the output needed from the PDE. Slices outside the slab carry no excess. -/
theorem patch_fubini (E B : Set Space) (ρ a b : ℝ) (hp : 0 < ρ)
    (me : MeasurableSet E) (mb : MeasurableSet B)
    (fi : Integrable (fun y => |patch E ρ y-patch B ρ y|))
    (slices : ∀ᵐ z : ℝ, volume (slice E z) ≠ ∞ ∧ volume (slice B z) ≠ ∞ ∧
       volume.real (slice E z) = volume.real (slice B z))
    (support : ∀ᵐ z : ℝ, z ∉ Icc a b → exchanged E B z = 0) :
    (∫ y, |patch E ρ y-patch B ρ y|) = 2*ρ*∫ z in Icc a b, exchanged E B z := by
  classical
  have hm (S : Set Space) (hS : MeasurableSet S) (z : ℝ) : MeasurableSet (slice S z) :=
    hS.preimage (measurable_id.prodMk measurable_const)
  rw [← integral_const_mul, ← integral_indicator measurableSet_Icc]
  rw [Measure.volume_eq_prod H ℝ] at fi ⊢
  rw [integral_prod_symm _ fi]
  apply integral_congr_ae
  filter_upwards [slices,support] with z hz hs
  have hh := section_l1 ρ hp (slice E z) (slice B z) (hm E me z) (hm B mb z) hz.1 hz.2.1 hz.2.2
  change (∫ x, |patch (slice E z) ρ x-patch (slice B z) ρ x|) = _
  rw [hh]
  by_cases h : z ∈ Icc a b
  · simp [Set.indicator_of_mem h,exchanged]
  · simp [Set.indicator_of_notMem h,← show exchanged E B z = volume.real (slice E z \ slice B z) from rfl,hs h]

/-- The one-dimensional sharp rearrangement underlying each of the two shells.
ν is the distribution of excess area as a function of signed area-distance
from the boundary, flipped to the positive half line. -/
theorem halfline_moment (ν : Measure ℝ) [IsFiniteMeasure ν]
    (cap : ν ≤ volume) (support : ∀ᵐ t ∂ν, 0 ≤ t) (hi : Integrable (fun t : ℝ => t) ν) :
    (ν.real univ)^2/2 ≤ ∫ t, t ∂ν := by
  classical
  let d := ν.real univ
  have hd : 0 ≤ d := ENNReal.toReal_nonneg
  let f := (Icc 0 d).indicator (fun t : ℝ => d-t)
  have hfi : IntegrableOn (fun t : ℝ => d-t) (Icc 0 d) :=
    (continuous_const.sub continuous_id).continuousOn.integrableOn_Icc
  have hf : Integrable f volume := (integrable_indicator_iff measurableSet_Icc).2 hfi
  have hfpos (t : ℝ) : 0 ≤ f t := by
    by_cases ht : t ∈ Icc 0 d
    · simpa [f, ht] using sub_nonneg.mpr ht.2
    · simp [f, ht]
  have pt : (fun t : ℝ => d-t) ≤ᵐ[ν] f := by
    filter_upwards [support] with t ht
    by_cases h : t ≤ d
    · simp [f, Set.mem_Icc.mpr ⟨ht,h⟩]
    · have hh : t ∉ Icc 0 d := fun k => h k.2
      simpa [f,hh] using (sub_nonpos.mpr (le_of_not_ge h))
  have h0 := integral_mono_ae ((integrable_const d).sub hi) (hf.mono_measure cap) pt
  have h1 := integral_mono_measure cap (Filter.Eventually.of_forall hfpos) hf
  have ev : (∫ t, f t) = d^2/2 := by
    have hc : IntegrableOn (fun _ : ℝ => d) (Icc 0 d) := integrable_const d
    have hid : IntegrableOn (fun x : ℝ => x) (Icc 0 d) := continuous_id.continuousOn.integrableOn_Icc
    rw [show f = _ from rfl, integral_indicator measurableSet_Icc, integral_sub hc hid,
      setIntegral_const,integral_Icc_eq_integral_Ioc, ← intervalIntegral.integral_of_le hd,integral_id]
    simp [Measure.real,Real.volume_Icc,ENNReal.toReal_ofReal hd,smul_eq_mul]
    ring
  change (∫ x, d-x ∂ν) ≤ _ at h0
  rw [integral_sub (integrable_const d) hi, integral_const,smul_eq_mul] at h0
  rw [ev] at h1
  change d^2/2 ≤ _
  change d*d - _ ≤ _ at h0
  linarith

/-- Combine both shell bounds at one height; the conversion between area
coordinate and squared horizontal radius gives the factor pi. -/
theorem annulus_pair (out inn : Measure ℝ) [IsFiniteMeasure out] [IsFiniteMeasure inn]
    (ho : out ≤ volume) (hi : inn ≤ volume)
    (so : ∀ᵐ x ∂out, 0 ≤ x) (si : ∀ᵐ x ∂inn, 0 ≤ x)
    (io : Integrable (fun x : ℝ => x) out) (ii : Integrable (fun x : ℝ => x) inn)
    (equalMass : out.real univ = inn.real univ) :
    (out.real univ)^2/Real.pi ≤ ((∫ x, x ∂out)+(∫ x, x ∂inn))/Real.pi := by
  have o := halfline_moment out ho so io
  have i := halfline_moment inn hi si ii
  rw [← equalMass] at i
  exact div_le_div_of_nonneg_right (by linarith) Real.pi_pos.le

end
end Vortex
