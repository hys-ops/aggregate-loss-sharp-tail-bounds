import ResidualCertificate
import Mathlib.Probability.Distributions.Gaussian.Real
import Mathlib.MeasureTheory.Integral.Pi

open MeasureTheory ProbabilityTheory Set Filter Matrix
open scoped ENNReal BigOperators Topology
namespace Residual
noncomputable section

abbrev productNormal (d : ℕ) : Measure (Fin d → ℝ) :=
  Measure.pi (fun _ : Fin d => gaussianReal 0 1)

def radiusSquare {d : ℕ} (x : Fin d → ℝ) : ℝ := ∑ i,x i^2

theorem normal_exp_squares {d : ℕ} (a : ℝ) (ha : a<1/2) :
    Integrable (fun x => Real.exp (a*radiusSquare x)) (productNormal d) := by
  have one : Integrable (fun t : ℝ => Real.exp (a*t^2)) (gaussianReal 0 1) := by
    rw [gaussianReal_of_var_ne_zero _ one_ne_zero,integrable_withDensity_iff_integrable_smul'
      (measurable_gaussianPDF _ _) (.of_forall fun _ => gaussianPDF_lt_top)]
    have h := (integrable_exp_neg_mul_sq (show 0<1/2-a by linarith)).const_mul (Real.sqrt (2*Real.pi))⁻¹
    apply h.congr
    filter_upwards with x
    rw [toReal_gaussianPDF,gaussianPDFReal_def]
    simp only [NNReal.coe_one,mul_one,sub_zero,smul_eq_mul,mul_assoc,← Real.exp_add]
    congr 2
    ring
  have h := Integrable.fin_nat_prod (μ:=fun _ : Fin d => gaussianReal 0 1) (f:=fun _ t => Real.exp (a*t^2)) (fun _ => one)
  apply h.congr
  filter_upwards with x
  rw [←Real.exp_sum,radiusSquare,Finset.mul_sum]

theorem radiusSquare_nonneg {d : ℕ} (x : Fin d → ℝ) : 0≤radiusSquare x :=
  Finset.sum_nonneg fun i _ => sq_nonneg (x i)

theorem radiusSquare_integrable (d : ℕ) : Integrable (@radiusSquare d) (productNormal d) := by
  have e := (normal_exp_squares (d:=d) (1/4) (by norm_num)).const_mul 4
  apply e.mono' ((Finset.measurable_sum _ fun i _ => (measurable_pi_apply i).pow_const 2).aestronglyMeasurable)
  filter_upwards with x
  change ‖radiusSquare x‖ ≤ 4*Real.exp ((1/4)*radiusSquare x)
  rw [Real.norm_eq_abs,abs_of_nonneg (radiusSquare_nonneg x)]
  linarith [Real.add_one_le_exp ((1/4)*radiusSquare x)]

/-- An exponential-moment tail bound for every dominated measure, simultaneously in its mass
and the exponential tilt. This avoids any regularity assumption on its Radon–Nikodym density. -/
theorem submeasure_exponential_trim {Ω : Type*} [MeasurableSpace Ω]
    (ρ ζ : Measure Ω) [IsFiniteMeasure ρ] (dom : ζ ≤ ρ) (W : Ω → ℝ) (a t : ℝ)
    (apos : 0<a) (iW : Integrable W ρ) (ie : Integrable (fun x => Real.exp (a*W x)) ρ) :
    (∫ x,W x ∂ζ) ≤ ζ.real univ*t+
      (Real.exp (-(a*t))/a)*(∫ x,Real.exp (a*W x) ∂ρ) := by
  let K := Real.exp (-(a*t))/a
  let _ : IsFiniteMeasure ζ := isFiniteMeasure_of_le _ dom
  have kpos : 0≤K := div_nonneg (Real.exp_pos _).le apos.le
  have step (x) : W x ≤ t+K*Real.exp (a*W x) := by
    have hh := Real.add_one_le_exp (-(a*t)+a*W x)
    rw [Real.exp_add] at hh
    dsimp [K]
    rw [div_mul_eq_mul_div]
    have hd : W x-t ≤ Real.exp (-(a*t))*Real.exp (a*W x)/a := (le_div_iff₀ apos).mpr (by linarith)
    linarith
  calc
    _ ≤ ∫ x,t+K*Real.exp (a*W x) ∂ζ := integral_mono (iW.mono_measure dom)
      ((integrable_const _).add ((ie.mono_measure dom).const_mul _)) step
    _ = ζ.real univ*t+K*(∫ x,Real.exp (a*W x) ∂ζ) := by
      rw [integral_add (integrable_const _) ((ie.mono_measure dom).const_mul _),integral_const_mul,integral_const,smul_eq_mul]
    _ ≤ _ := add_le_add (le_refl _) (mul_le_mul_of_nonneg_left
      (integral_mono_measure dom (.of_forall fun x => (Real.exp_pos _).le) ie) kpos)

end
end Residual
