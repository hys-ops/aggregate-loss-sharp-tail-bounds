import ResidualFirst
import Mathlib.LinearAlgebra.Matrix.PosDef
open MeasureTheory Set Filter Matrix
open scoped ENNReal BigOperators
namespace Residual
noncomputable section

def outerMoment {Ω : Type*} [MeasurableSpace Ω] {m : ℕ} (μ : Measure Ω) (F : Fin m → Ω → ℝ) :
    Matrix (Fin m) (Fin m) ℝ := fun i j => ∫ x,F i x*F j x ∂μ

def mix {Ω : Type*} {m : ℕ} (h : Fin m → ℝ) (F : Fin m → Ω → ℝ) (x : Ω) :=
  ∑ i,h i*F i x

theorem sq_mix {Ω : Type*} {m : ℕ} (h : Fin m → ℝ) (F : Fin m → Ω → ℝ) (x : Ω) :
    mix h F x ^ 2 = ∑ i, ∑ j, h i*(F i x*F j x)*h j := by
  simp only [mix,pow_two,Finset.sum_mul,Finset.mul_sum]
  apply Finset.sum_congr rfl; intro i _
  apply Finset.sum_congr rfl; intro j _; ring

theorem outer_quad {Ω : Type*} [MeasurableSpace Ω] {m : ℕ}
    (μ : Measure Ω) (F : Fin m → Ω → ℝ) (h : Fin m → ℝ) (l : ∀ i, MemLp (F i) 2 μ) :
    h ⬝ᵥ (outerMoment μ F *ᵥ h) = ∫ x,mix h F x ^ 2 ∂μ := by
  simp_rw [sq_mix]
  have ij (i j) : Integrable (fun x => h i*(F i x*F j x)*h j) μ :=
    (((l i).integrable_mul (l j)).const_mul _).mul_const _
  rw [integral_finsetSum _ (fun i _ => integrable_finsetSum _ (fun j _ => ij i j))]
  simp only [dotProduct,mulVec,Finset.mul_sum,outerMoment]
  apply Finset.sum_congr rfl; intro i _
  rw [integral_finsetSum _ (fun j _ => ij i j)]
  apply Finset.sum_congr rfl; intro j _
  rw [integral_mul_const,integral_const_mul]; ring

def errorMatrix {X I : Type*} [MeasurableSpace X] [Fintype I] {m : ℕ}
    (ρ : Measure X) (j k : X → I) (F : Fin m → X → ℝ) : Matrix (Fin m) (Fin m) ℝ :=
  fun u v => ∑ i, change ρ j k (F u) i * change ρ j k (F v) i / (mass ρ j i+mass ρ k i)

theorem change_mix {X I : Type*} [MeasurableSpace X] {m : ℕ}
    (ρ : Measure X) (j k : X → I) (F : Fin m → X → ℝ) (h : Fin m → ℝ)
    (lf : ∀ i, Integrable (F i) ρ) (n : I) :
    change ρ j k (mix h F) n = ∑ i,h i*change ρ j k (F i) n := by
  unfold change mix
  rw [integral_finsetSum _ (fun i _ => ((lf i).integrableOn.const_mul _)),
      integral_finsetSum _ (fun i _ => ((lf i).integrableOn.const_mul _))]
  simp only [integral_const_mul,mul_sub,Finset.sum_sub_distrib]

theorem error_quad {X I : Type*} [MeasurableSpace X] [Fintype I] {m : ℕ}
    (ρ : Measure X) (j k : X → I) (F : Fin m → X → ℝ) (h : Fin m → ℝ)
    (lf : ∀ i, Integrable (F i) ρ) :
    h ⬝ᵥ (errorMatrix ρ j k F *ᵥ h) = scalarEnergy ρ j k (mix h F) := by
  let v := fun l i => change ρ j k (F l) i
  let w := fun i => mass ρ j i+mass ρ k i
  change (∑ l,h l*(∑ t,(∑ i,v l i*v t i/w i)*h t)) = ∑ i, change ρ j k (mix h F) i ^ 2 / w i
  simp_rw [change_mix ρ j k F h lf]
  change _ = ∑ i, (mix h v i)^2/w i
  simp_rw [sq_mix]
  calc
    _ = ∑ l, ∑ t, ∑ i, h l*(v l i*v t i)*h t/w i := by
      simp only [Finset.sum_mul,Finset.mul_sum]
      apply Finset.sum_congr rfl; intro l _
      apply Finset.sum_congr rfl; intro t _
      apply Finset.sum_congr rfl; intro i _; ring
    _ = ∑ i, (∑ l, ∑ t, h l*(v l i*v t i)*h t)/w i := by
      simp only [Finset.sum_div]
      calc
        _ = ∑ l,∑ i,∑ t, h l*(v l i*v t i)*h t/w i := by
          apply Finset.sum_congr rfl; intro l _; exact Finset.sum_comm
        _ = _ := Finset.sum_comm

theorem matrix_from_tests {X I : Type*} [MeasurableSpace X] [Fintype I] {m : ℕ}
    (ρ ζ : Measure X) (j k : X → I) (F : Fin m → X → ℝ)
    (lρ : ∀ i,Integrable (F i) ρ) (lζ : ∀ i,MemLp (F i) 2 ζ)
    (q : ∀ h, scalarEnergy ρ j k (mix h F) ≤ 2*∫ x,mix h F x^2 ∂ζ) :
    ((2:ℝ) • outerMoment ζ F-errorMatrix ρ j k F).PosSemidef := by
  apply Matrix.PosSemidef.of_dotProduct_mulVec_nonneg
  · ext i j
    simp [outerMoment,errorMatrix,Matrix.conjTranspose_apply,mul_comm]
  · intro h
    rw [sub_mulVec,smul_mulVec,dotProduct_sub,dotProduct_smul]
    simp only [star_trivial,smul_eq_mul]
    rw [outer_quad ζ F h lζ,error_quad ρ j k F h lρ]
    linarith [q h]

end
end Residual
