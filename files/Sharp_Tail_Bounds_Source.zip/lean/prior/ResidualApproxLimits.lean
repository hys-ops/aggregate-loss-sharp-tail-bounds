import ResidualLimits
import Mathlib.MeasureTheory.Function.ContinuousMapDense
open MeasureTheory Filter Set
open scoped Topology ENNReal BoundedContinuousFunction
namespace Residual
noncomputable section
variable {X : Type*} [MetricSpace X] [MeasurableSpace X] [BorelSpace X]
  [SecondCountableTopology X] [CompleteSpace X]

theorem convergence_by_approx {a : ℕ → ℝ} {b : ℝ}
    (approx : ∀ ε : ℝ, 0<ε → ∃ u : ℕ → ℝ, ∃ v : ℝ, Tendsto u atTop (𝓝 v) ∧
       (∀ n, |a n-u n|≤ε) ∧ |b-v|≤ε) : Tendsto a atTop (𝓝 b) := by
  apply Metric.tendsto_nhds.mpr
  intro ε hp
  obtain ⟨u,v,hu,ha,hb⟩ := approx (ε/4) (by positivity)
  filter_upwards [Metric.tendsto_nhds.mp hu (ε/4) (by positivity)] with n hn
  simp only [←Real.dist_eq] at ha hb
  calc dist (a n) b ≤ dist (a n) (u n) + dist (u n) v + dist v b :=
        (dist_triangle (a n) v b).trans (add_le_add (dist_triangle (a n) (u n) v) le_rfl)
       _ < ε := by rw [dist_comm v b]; linarith [ha n]

omit [CompleteSpace X] in
/-- Domination upgrades bounded-continuous tests to every integrable test. -/
theorem dominated_l1_tests (P : Measure X) [IsFiniteMeasure P] (Z : ℕ → Measure X) (ζ : Measure X)
    (zn : ∀ n,Z n ≤ P) (z : ζ≤P)
    (weak : ∀ h : X →ᵇ ℝ,Tendsto (fun n => ∫ x,h x ∂(Z n)) atTop (𝓝 (∫ x,h x ∂ζ)))
    (f : X → ℝ) (hf : Integrable f P) :
    Tendsto (fun n => ∫ x,f x ∂(Z n)) atTop (𝓝 (∫ x,f x ∂ζ)) := by
  apply convergence_by_approx
  intro ε he
  obtain ⟨h,err,ih⟩ := hf.exists_boundedContinuous_integral_sub_le he
  have bound (η : Measure X) (le : η≤P) : |(∫ x,f x ∂η)-(∫ x,h x ∂η)|≤ε := by
    rw [←integral_sub (hf.mono_measure le) (ih.mono_measure le)]
    exact abs_integral_le_integral_abs.trans ((integral_mono_measure le (.of_forall fun _ => abs_nonneg _)
      (hf.sub ih).abs).trans err)
  exact ⟨_,_,weak h,fun n => bound _ (zn n),bound _ z⟩

/-- On a fixed dominated interval of measures one subsequence converges
simultaneously on *all* L¹ tests, including source-square observables and
the constant mass test. Encode the residual and complement as a probability
on the disjoint union of two copies of the source. -/
theorem dominated_subsequence (P : ProbabilityMeasure X) (Z : ℕ → Measure X) (zn : ∀ n,Z n ≤ P) :
    ∃ ζ : Measure X, ζ ≤ P ∧ ∃ r : ℕ → ℕ, StrictMono r ∧
      ∀ (f : X → ℝ), Integrable f (P : Measure X) →
      Tendsto (fun n => ∫ x,f x ∂(Z (r n))) atTop (𝓝 (∫ x,f x ∂ζ)) := by
  classical
  have Iz (n) : IsFiniteMeasure (Z n) := ⟨(zn n univ).trans_lt (measure_lt_top _ _)⟩
  let j (b : Bool) := fun x : X => (x,b)
  have mj (b) : Measurable (j b) := measurable_id.prodMk measurable_const
  let lift (n : ℕ) := ((P : Measure X)-Z n).map (j false) + (Z n).map (j true)
  have marginal (n) : (lift n).map Prod.fst = (P : Measure X) := by
    dsimp [lift]
    rw [Measure.map_add _ _ measurable_fst,Measure.map_map measurable_fst (mj false),
      Measure.map_map measurable_fst (mj true)]
    change ((P : Measure X)-Z n).map id + (Z n).map id=_
    simpa only [Measure.map_id] using Measure.sub_add_cancel_of_le (zn n)
  let π (n) : ProbabilityMeasure (X×Bool) := ⟨lift n,⟨by
    have h := congrArg (fun μ : Measure X => μ univ) (marginal n)
    simpa only [Measure.map_apply measurable_fst MeasurableSet.univ,preimage_univ,measure_univ] using h⟩⟩
  let D := (P : Measure X).map (j false) + (P : Measure X).map (j true)
  have dD (n) : (π n : Measure (X×Bool))≤D :=
    add_le_add (Measure.map_mono Measure.sub_le (mj false)) (Measure.map_mono (zn n) (mj true))
  have tight : IsTightMeasureSet {((u : ProbabilityMeasure (X×Bool)) : Measure (X×Bool)) | u∈range π} := by
    apply isTightMeasureSet_iff_exists_isCompact_measure_compl_le.mpr
    intro ε pos
    obtain ⟨K,cK,hK⟩ := isTightMeasureSet_iff_exists_isCompact_measure_compl_le.mp
      (isTightMeasureSet_singleton (μ:=D)) ε pos
    refine ⟨K,cK,?_⟩
    rintro _ ⟨_,⟨n,rfl⟩,rfl⟩
    exact (dD n _).trans (hK _ (mem_singleton _))
  obtain ⟨γ,_,r,mono,weak⟩ := (isCompact_closure_of_isTightMeasureSet tight).tendsto_subseq
    (x:=π) fun n => subset_closure (mem_range_self n)
  have first : (γ : Measure (X×Bool)).map Prod.fst=P := by
    have h := ((ProbabilityMeasure.continuous_map (f := (Prod.fst : X×Bool→X)) continuous_fst).tendsto γ).comp weak
    have H : γ.map Prod.fst = P := tendsto_nhds_unique h (tendsto_const_nhds.congr (fun n =>
      (show (π (r n)).map Prod.fst = P by apply ProbabilityMeasure.toMeasure_injective; exact marginal _).symm))
    exact congrArg ProbabilityMeasure.toMeasure H
  let A : Set (X×Bool) := Prod.snd ⁻¹' ({true} : Set Bool)
  have clop : IsClopen A := (show IsClopen ({true}:Set Bool) from ⟨isClosed_singleton,isOpen_discrete _⟩).preimage continuous_snd
  let sel (ν : Measure (X×Bool)) := (ν.restrict A).map Prod.fst
  have slice (n) : sel (π n) = Z n := by
    change Measure.map Prod.fst ((lift n).restrict A)=_
    simp only [lift,Measure.restrict_add,Measure.restrict_map (mj false) clop.1.measurableSet,
      Measure.restrict_map (mj true) clop.1.measurableSet]
    have no : j false ⁻¹' A=∅ := by ext x; simp [A,j]
    have yes : j true ⁻¹' A=univ := by ext x; simp [A,j]
    rw [no,yes,Measure.restrict_empty,Measure.map_zero,zero_add,Measure.restrict_univ,
      Measure.map_map measurable_fst (mj true)]; exact Measure.map_id
  have le : sel γ ≤ P := (Measure.map_mono Measure.restrict_le_self measurable_fst).trans_eq first
  refine ⟨sel γ,le,r,mono,dominated_l1_tests P (Z ∘ r) _ (fun n => zn (r n)) le ?_⟩
  intro h
  let f := fun z : X×Bool => h z.1
  let hh := BoundedContinuousFunction.ofNormedAddCommGroup (A.indicator f) (clop.continuous_indicator
    (h.continuous.comp continuous_fst)) ‖h‖ (fun z => by
      by_cases hz : z ∈ A
      · simpa only [indicator_of_mem hz,f] using h.norm_coe_le_norm z.1
      · simp [hz])
  have eq (ν : Measure (X×Bool)) : (∫ x,h x ∂(sel ν))=∫ z,hh z ∂ν := by
    rw [show sel ν=(ν.restrict A).map Prod.fst from rfl,integral_map measurable_fst.aemeasurable h.continuous.aestronglyMeasurable]
    exact (integral_indicator clop.1.measurableSet).symm
  have law := ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp weak hh
  rw [eq]
  exact law.congr fun n => ((slice (r n)) ▸ eq (π (r n))).symm

end
end Residual
