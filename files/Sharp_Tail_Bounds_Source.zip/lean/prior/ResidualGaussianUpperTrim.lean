import ResidualGaussianUpper
import Mathlib.Analysis.Matrix.Order
import Mathlib.Analysis.SpecialFunctions.ContinuousFunctionalCalculus.Rpow.Basic
open MeasureTheory Filter Set Matrix
open scoped ENNReal BigOperators MatrixOrder
namespace Residual
noncomputable section

def admissibleWeight {X : Type*} [MeasurableSpace X] (ρ : Measure X) (u : ℝ) (g : X → ℝ) : Prop :=
  Measurable g ∧ (∀ᵐ x ∂ρ, g x ∈ Icc 0 1) ∧ (∫ x,g x ∂ρ)=u

def trimmedMoment {X : Type*} [MeasurableSpace X] (ρ : Measure X) (u : ℝ) (W : X → ℝ) : ℝ :=
  sSup {z | ∃ g : X → ℝ, admissibleWeight ρ u g ∧ z = ∫ x,g x*W x ∂ρ}

private theorem weighted_integrable {X : Type*} [MeasurableSpace X] {ρ : Measure X}
    {u : ℝ} {g W : X → ℝ} (hg : admissibleWeight ρ u g) (hw : Integrable W ρ) :
    Integrable (fun x => g x*W x) ρ :=
  hw.bdd_mul hg.1.aestronglyMeasurable (hg.2.1.mono fun x hx => by
    rw [Real.norm_eq_abs,abs_of_nonneg hx.1]; exact hx.2)

theorem trimmed_candidate_le {X : Type*} [MeasurableSpace X] {ρ : Measure X} [IsFiniteMeasure ρ]
    {u : ℝ} {g W : X → ℝ} (hg : admissibleWeight ρ u g) (hw : Integrable W ρ) (a : ℝ) :
    (∫ x,g x*W x ∂ρ) ≤ u*a + ∫ x,max (W x-a) 0 ∂ρ := by
  have iw : Integrable (fun x => g x*a) ρ := weighted_integrable hg (integrable_const _)
  have ip : Integrable (fun x => max (W x-a) 0) ρ := (hw.sub (integrable_const a)).pos_part
  have bd : ∀ᵐ x ∂ρ,g x*W x ≤ g x*a+max (W x-a) 0 := by
    filter_upwards [hg.2.1] with x hx
    by_cases e : a≤W x
    · rw [max_eq_left (by linarith)]
      nlinarith [mul_nonneg (sub_nonneg.mpr hx.2) (sub_nonneg.mpr e)]
    · rw [max_eq_right (by linarith)]
      nlinarith [mul_nonneg hx.1 (sub_nonneg.mpr (le_of_not_ge e))]
  have h := integral_mono_ae (weighted_integrable hg hw) (iw.add ip) bd
  change _ ≤ ∫ x,g x*a+max (W x-a) 0 ∂ρ at h
  rw [integral_add iw ip,integral_mul_const,hg.2.2] at h
  exact h

theorem le_trimmedMoment {X : Type*} [MeasurableSpace X] {ρ : Measure X} [IsFiniteMeasure ρ]
    {u : ℝ} {g W : X → ℝ} (hg : admissibleWeight ρ u g) (hw : Integrable W ρ) :
    (∫ x,g x*W x ∂ρ) ≤ trimmedMoment ρ u W := by
  unfold trimmedMoment
  refine le_csSup ?_ ⟨g,hg,rfl⟩
  refine ⟨u*0 + ∫ x,max (W x-0) 0 ∂ρ,?_⟩
  rintro z ⟨f,hf,rfl⟩
  exact trimmed_candidate_le hf hw 0

theorem trimmedMoment_le_threshold {X : Type*} [MeasurableSpace X] {ρ : Measure X} [IsProbabilityMeasure ρ]
    (W : X → ℝ) (hw : Integrable W ρ) (u : ℝ) (hu : u ∈ Icc 0 1) (a : ℝ) :
    trimmedMoment ρ u W ≤ u*a + ∫ x,max (W x-a) 0 ∂ρ := by
  have wt : admissibleWeight ρ u (fun _ => u) := ⟨measurable_const,.of_forall fun _ => hu,by simp⟩
  unfold trimmedMoment
  refine csSup_le (s:={z | ∃ g : X → ℝ, admissibleWeight ρ u g ∧ z = ∫ x,g x*W x ∂ρ}) ⟨∫ x,u*W x ∂ρ,(fun _ => u),wt,rfl⟩ ?_
  rintro z ⟨g,hg,rfl⟩
  exact trimmed_candidate_le hg hw a

/-- Express an arbitrary common submeasure as an admissible trimming rule.
The density may take both endpoint values. -/
theorem submeasure_le_trimmedMoment {X : Type*} [MeasurableSpace X] (ρ ζ : Measure X) [IsFiniteMeasure ρ]
    (sub : ζ ≤ ρ) (W : X → ℝ) (hw : Integrable W ρ) :
    (∫ x,W x ∂ζ) ≤ trimmedMoment ρ (ζ.real univ) W := by
  let _ : IsFiniteMeasure ζ := isFiniteMeasure_of_le _ sub
  let g := fun x => (ζ.rnDeriv ρ x).toReal
  have hg : admissibleWeight ρ (ζ.real univ) g := by
    refine ⟨(Measure.measurable_rnDeriv _ _).ennreal_toReal,?_,Measure.integral_toReal_rnDeriv sub.absolutelyContinuous⟩
    filter_upwards [Measure.rnDeriv_le_one_of_le sub] with x hx
    exact ⟨ENNReal.toReal_nonneg,(ENNReal.toReal_mono ENNReal.one_ne_top hx).trans_eq ENNReal.toReal_one⟩
  rw [← integral_toReal_rnDeriv_mul sub.absolutelyContinuous]
  exact le_trimmedMoment hg hw

/-- Any PSD matrix test inherits the scalar, fixed-mass trimming bound. -/
theorem matrix_trimmed_test {X : Type*} [MeasurableSpace X] (ρ ζ : Measure X) [IsFiniteMeasure ρ]
    (sub : ζ ≤ ρ) {m : ℕ} (F : Fin m → X → ℝ) (hF : ∀ i, MemLp (F i) 2 ρ)
    (E H : Matrix (Fin m) (Fin m) ℝ) (test : H.PosSemidef)
    (dom : ((2:ℝ) • outerMoment ζ F-E).PosSemidef) :
    (H*E).trace ≤ 2*trimmedMoment ρ (ζ.real univ)
      (fun x => ∑ i, ∑ j,H i j*(F j x*F i x)) := by
  let W := fun x => ∑ i,∑ j,H i j*(F j x*F i x)
  have iw : Integrable W ρ := integrable_finsetSum _ (fun i _ => integrable_finsetSum _ (fun j _ =>
    ((hF j).integrable_mul (hF i)).const_mul (H i j)))
  have mom : (H * outerMoment ζ F).trace = ∫ x,W x ∂ζ := by
    have entry (i j : Fin m) : Integrable (fun x => H i j*(F j x*F i x)) ζ :=
      (((hF j).integrable_mul (hF i)).mono_measure sub).const_mul _
    change (∑ i, ∑ j, H i j * outerMoment ζ F j i) = ∫ x, ∑ i,∑ j,H i j*(F j x*F i x) ∂ζ
    rw [integral_finsetSum Finset.univ (fun i _ => integrable_finsetSum Finset.univ (fun j _ => entry i j))]
    apply Finset.sum_congr rfl; intro i _
    rw [integral_finsetSum _ (fun j _ => entry i j)]
    simp [outerMoment,integral_const_mul]
  obtain ⟨K,hK⟩ := CStarAlgebra.nonneg_iff_eq_star_mul_self.mp test.nonneg
  have hh := (dom.mul_mul_conjTranspose_same K).trace_nonneg
  rw [trace_mul_cycle] at hh
  change H=Kᴴ*K at hK
  rw [←hK,mul_sub,Matrix.mul_smul,trace_sub,trace_smul,smul_eq_mul,mom] at hh
  linarith [submeasure_le_trimmedMoment ρ ζ sub W iw]

end
end Residual
