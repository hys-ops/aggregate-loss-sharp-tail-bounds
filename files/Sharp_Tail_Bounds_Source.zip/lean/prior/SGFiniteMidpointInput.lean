import ContinuumUniform

open MeasureTheory Set
open scoped ENNReal
namespace Vortex
noncomputable section

/-- A normalized midpoint coupling for any two positive-mass measurable pieces
of one uniform compact convex physical body. The midpoint is measured in Space. -/
def CellMidpoints : Prop :=
  ∀ (J : Set Space) [CompactSpace J], Convex ℝ J → ∀ (W : ProbabilityMeasure J),
    UniformBodyLaw J W → ∀ A B : Set J, MeasurableSet A → MeasurableSet B →
    0 < (W : Measure J).real A → 0 < (W : Measure J).real B →
    ∃ γ : ProbabilityMeasure (J × J),
      (γ : Measure (J × J)).map Prod.fst = ((W : Measure J) A)⁻¹ • (W : Measure J).restrict A ∧
      (γ : Measure (J × J)).map Prod.snd = ((W : Measure J) B)⁻¹ • (W : Measure J).restrict B ∧
      ENNReal.ofReal (Real.sqrt ((W : Measure J).real A * (W : Measure J).real B)) •
        (γ : Measure (J × J)).map (fun z => (1/2 : ℝ) • (z.1.val+z.2.val)) ≤
        (W : Measure J).map Subtype.val

end
end Vortex
