import ResidualCoupling
import Mathlib.MeasureTheory.Function.L2Space

open MeasureTheory Set Filter Function
open scoped ENNReal BigOperators
namespace Residual
noncomputable section

theorem harmonic_linear (a b u v : ℝ) (na : 0 ≤ a) (nb : 0 ≤ b) :
    a*u+b*v-2*Vortex.harmonicMass a b*((u+v)/2) = (a-b)*(a*u-b*v)/(a+b) := by
  by_cases h : a+b=0
  · have za : a=0 := by linarith
    have zb : b=0 := by linarith
    simp [za,zb,Vortex.harmonicMass]
  · unfold Vortex.harmonicMass; field_simp; ring

private theorem jensen_sq {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {g : Ω → ℝ} (l : MemLp g 2 μ) : (∫ x,g x ∂μ)^2 ≤ ∫ x,(g x)^2 ∂μ :=
  (even_two.convexOn_pow (𝕜 := ℝ)).map_integral_le (continuous_pow 2).continuousOn isClosed_univ
    (.of_forall fun _ => mem_univ _) (l.integrable (by norm_num)) l.integrable_sq

private theorem cell_energy_pos {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    (a b : ℝ) (na : 0 ≤ a) (nb : 0 ≤ b) (u v : Ω → ℝ) (lu : MemLp u 2 μ) (lv : MemLp v 2 μ) :
    (a*(∫ x,u x ∂μ)-b*(∫ x,v x ∂μ))^2/(a+b) ≤
    a*(∫ x,u x^2 ∂μ)+b*(∫ x,v x^2 ∂μ)
      -2*Vortex.harmonicMass a b*(∫ x,((u x+v x)/2)^2 ∂μ) := by
  let g := fun x => a*u x-b*v x
  let m := fun x => (u x+v x)/2
  have lg : MemLp g 2 μ := (lu.const_mul a).sub (lv.const_mul b)
  have lm : MemLp m 2 μ := by simpa [m,div_eq_mul_inv] using (lu.add lv).mul_const (2:ℝ)⁻¹
  have j := div_le_div_of_nonneg_right (jensen_sq lg) (add_nonneg na nb)
  have ug := lu.integrable (by norm_num : (1:ℝ≥0∞) ≤ 2)
  have vg := lv.integrable (by norm_num : (1:ℝ≥0∞) ≤ 2)
  have e : (∫ x,g x ∂μ) = a*(∫ x,u x ∂μ)-b*(∫ x,v x ∂μ) := by
    unfold g; rw [integral_sub (ug.const_mul _) (vg.const_mul _),integral_const_mul,integral_const_mul]
  rw [e] at j
  apply j.trans_eq
  rw [←integral_div,←integral_const_mul,←integral_const_mul,←integral_const_mul,
    ←integral_add (lu.integrable_sq.const_mul _) (lv.integrable_sq.const_mul _),
    ←integral_sub (f := fun x => a*u x^2+b*v x^2) (g := fun x => 2*Vortex.harmonicMass a b*(m x)^2) ((lu.integrable_sq.const_mul _).add (lv.integrable_sq.const_mul _)) (lm.integrable_sq.const_mul _)]
  apply integral_congr_ae; filter_upwards with x
  by_cases z : a+b=0
  · have za : a=0 := by linarith
    have zb : b=0 := by linarith
    simp [za,zb,g,Vortex.harmonicMass]
  · dsimp [g,m]; unfold Vortex.harmonicMass; field_simp; ring

theorem cell_energy {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    (a b : ℝ) (na : 0 ≤ a) (nb : 0 ≤ b) (u v : Ω → ℝ)
    (lu : a ≠ 0 → MemLp u 2 μ) (lv : b ≠ 0 → MemLp v 2 μ) :
    (a*(∫ x,u x ∂μ)-b*(∫ x,v x ∂μ))^2/(a+b) ≤
    a*(∫ x,u x^2 ∂μ)+b*(∫ x,v x^2 ∂μ)
      -2*Vortex.harmonicMass a b*(∫ x,((u x+v x)/2)^2 ∂μ) := by
  by_cases ha : a=0 <;> by_cases hb : b=0
  · simp [ha,hb,Vortex.harmonicMass]
  · simpa [ha,Vortex.harmonicMass] using cell_energy_pos μ a b na nb (fun _ => 0) v (memLp_const 0) (lv hb)
  · simpa [hb,Vortex.harmonicMass] using cell_energy_pos μ a b na nb u (fun _ => 0) (lu ha) (memLp_const 0)
  · exact cell_energy_pos μ a b na nb u v (lu ha) (lv hb)

end
end Residual
