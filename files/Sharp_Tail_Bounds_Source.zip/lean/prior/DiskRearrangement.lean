import Geometry
import DiskArea
open MeasureTheory Set
open scoped ENNReal
namespace Vortex
noncomputable section

private theorem single_shell (S : Set H) (hs : MeasurableSet S) (fs : volume S ≠ ∞)
    (g : H → ℝ) (mg : Measurable g) (cap : (volume : Measure H).map g ≤ volume)
    (nonneg : ∀ x ∈ S, 0 ≤ g x) (hi : IntegrableOn g S) :
    (volume.real S)^2/2 ≤ ∫ x in S, g x := by
  let μ : Measure H := volume.restrict S
  let ν := μ.map g
  let _ : IsFiniteMeasure μ := isFiniteMeasure_restrict.mpr fs
  have c : ν ≤ volume := (Measure.map_mono Measure.restrict_le_self mg).trans cap
  have supp : ∀ᵐ t ∂ν, 0 ≤ t :=
    (ae_map_iff mg.aemeasurable measurableSet_Ici).2
      ((ae_restrict_mem hs).mono fun x hx => nonneg x hx)
  have ig : Integrable (fun t : ℝ => t) ν :=
    (integrable_map_measure measurable_id.aestronglyMeasurable mg.aemeasurable).2 hi
  have hk := halfline_moment ν c supp ig
  have hm : ν.real univ = volume.real S := by
    simp [ν,μ,Measure.real,Measure.map_apply mg]
  rw [hm] at hk
  exact hk.trans_eq (integral_map (μ := μ) (f := fun t : ℝ => t) mg.aemeasurable measurable_id.aestronglyMeasurable)

def disk (a : ℝ) : Set H := areaCoord ⁻¹' Iic a

/-- Sharp planar angular impulse for an arbitrary measurable patch of equal
area to the specified centered disk. Finite second moments only, no boundary smoothness. -/
theorem disk_rearrange (ρ a : ℝ) (hρ : 0 < ρ) (E : Set H) (me : MeasurableSet E)
    (fe : volume E ≠ ∞) (ie : IntegrableOn areaCoord E)
    (idisk : IntegrableOn areaCoord (disk a)) (same : volume.real E = volume.real (disk a)) :
    (ρ/Real.pi)*(volume.real (E \ disk a))^2 ≤
    ∫ x : H, (x.1^2+x.2^2)*(patch E ρ x-patch (disk a) ρ x) := by
  classical
  let S := E \ disk a
  let Q := disk a \ E
  have md : MeasurableSet (disk a) := areaCoord_meas measurableSet_Iic
  have fd : volume (disk a) ≠ ∞ := by rw [disk,disk_area]; exact ENNReal.ofReal_ne_top
  have mS : MeasurableSet S := me.diff md
  have mQ : MeasurableSet Q := md.diff me
  have fS : volume S ≠ ∞ := measure_ne_top_of_subset sdiff_subset fe
  have fQ : volume Q ≠ ∞ := measure_ne_top_of_subset sdiff_subset fd
  have hS : IntegrableOn areaCoord S := ie.mono_set sdiff_subset
  have hQ : IntegrableOn areaCoord Q := idisk.mono_set sdiff_subset
  have cS : IntegrableOn (fun _ : H => a) S := integrableOn_const fS
  have cQ : IntegrableOn (fun _ : H => a) Q := integrableOn_const fQ
  have acap : (volume : Measure H).map areaCoord ≤ volume := by
    rw [area_distribution]; exact Measure.restrict_le_self
  have shift (g : ℝ → ℝ) (hg : MeasurePreserving g volume volume) :
      (volume : Measure H).map (g ∘ areaCoord) ≤ volume := by
    rw [← Measure.map_map hg.measurable areaCoord_meas,← hg.map_eq]
    exact Measure.map_mono acap hg.measurable
  have out := single_shell S mS fS (fun x => areaCoord x-a) (areaCoord_meas.sub measurable_const)
    (shift _ (measurePreserving_sub_right volume a))
    (fun x hx => sub_nonneg.mpr (le_of_not_ge hx.2)) (hS.sub cS)
  have inn := single_shell Q mQ fQ (fun x => a-areaCoord x) (measurable_const.sub areaCoord_meas)
    (shift _ (volume.measurePreserving_sub_left a))
    (fun x hx => sub_nonneg.mpr hx.1) (cQ.sub hQ)
  rw [integral_sub hS cS,setIntegral_const,smul_eq_mul] at out
  rw [integral_sub cQ hQ,setIntegral_const,smul_eq_mul] at inn
  have heq : volume.real S = volume.real Q := equal_exchanges me md fe fd same
  rw [← heq] at inn
  have hb : (volume.real S)^2 ≤ (∫ x in S, areaCoord x)-(∫ x in Q, areaCoord x) := by linarith
  have pp (x : H) : (x.1^2+x.2^2)*(patch E ρ x-patch (disk a) ρ x) =
      (ρ/Real.pi)*(S.indicator areaCoord x-Q.indicator areaCoord x) := by
    by_cases hx : x ∈ E <;> by_cases hd : x ∈ disk a <;>
      simp [S,Q,patch,Set.indicator,hx,hd,areaCoord] <;> field_simp
  simp_rw [pp]
  rw [integral_const_mul,integral_sub ((integrable_indicator_iff mS).2 hS)
    ((integrable_indicator_iff mQ).2 hQ),integral_indicator mS,integral_indicator mQ]
  exact mul_le_mul_of_nonneg_left hb (div_nonneg hρ.le Real.pi_pos.le)

end
end Vortex
