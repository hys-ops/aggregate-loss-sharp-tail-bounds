import ContinuumLimit
import CyclicPlans

open MeasureTheory Filter Set
open scoped Topology ENNReal BoundedContinuousFunction BigOperators
namespace Vortex
noncomputable section

/-- A common finite quantizer. Empty cells under one particular law are allowed. -/
structure CommonGrid (Y : Type*) [MeasurableSpace Y] where
  size : ℕ
  site : Fin size → Y
  injective : Function.Injective site
  label : Y → Fin size
  measurableLabel : Measurable label

def CommonGrid.round {Y : Type*} [MeasurableSpace Y] (G : CommonGrid Y) (y : Y) : Y :=
  G.site (G.label y)

theorem CommonGrid.measurable_round {Y : Type*} [MeasurableSpace Y] (G : CommonGrid Y) :
    Measurable G.round :=
  (measurable_of_finite G.site).comp G.measurableLabel

/-- One common sequence of finite grids converges narrowly for *every* law
on the observation space, with the same sites for both endpoints. -/
theorem common_grids_for_all_laws {Y : Type*} [MetricSpace Y] [SecondCountableTopology Y]
    [MeasurableSpace Y] [BorelSpace Y] :
    ∃ G : ℕ → CommonGrid Y, ∀ P : ProbabilityMeasure Y,
    Tendsto (fun n => P.map (G n).round) atTop (𝓝 P) := by
  classical
  let h : StronglyMeasurable (id : Y → Y) := measurable_id.stronglyMeasurable
  let sf := h.approx
  let eqv (n : ℕ) := Fintype.equivFin ↥(sf n).range
  let tag (n : ℕ) (y : Y) : ↥(sf n).range := ⟨sf n y,(sf n).mem_range_self _⟩
  let G (n : ℕ) : CommonGrid Y := {
    size := Fintype.card ↥(sf n).range
    site := fun i => ((eqv n).symm i).val
    injective := Subtype.val_injective.comp (eqv n).symm.injective
    label := fun y => eqv n (tag n y)
    measurableLabel := (measurable_of_finite (eqv n)).comp ((sf n).measurable.subtype_mk) }
  have round_eq (n : ℕ) (y : Y) : (G n).round y = sf n y := by simp [CommonGrid.round,G,tag]
  refine ⟨G,fun P => ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mpr (fun g => ?_)⟩
  simp only [ProbabilityMeasure.toMeasure_map, integral_map (CommonGrid.measurable_round _).aemeasurable
    g.continuous.aestronglyMeasurable]
  apply tendsto_integral_of_dominated_convergence (fun _ => ‖g‖)
    (fun n => (g.continuous.measurable.comp (G n).measurable_round).aestronglyMeasurable) (integrable_const _)
  · exact fun n => .of_forall (fun y => g.norm_coe_le_norm _)
  · apply Eventually.of_forall
    intro y
    exact ((g.continuous.tendsto y).comp (h.tendsto_approx y)).congr (fun n => congrArg g (round_eq n y).symm)

private theorem dual_discr {u v t : ℝ} (hu : 0 ≤ u) (hv : 0 ≤ v) :
    (2*t)*(u-v)-t^2*(u+v) ≤ discr u v := by
  rcases eq_or_lt_of_le (add_nonneg hu hv) with h|h
  · have a : u=0 := by linarith
    have b : v=0 := by linarith
    simp [a,b,discr]
  · apply (le_div_iff₀ h).mpr
    nlinarith only [sq_nonneg ((u-v)-t*(u+v))]

private theorem discr_by_test (u v : ℝ) :
    discr u v = (2*((u-v)/(u+v)))*(u-v)-((u-v)/(u+v))^2*(u+v) := by
  unfold discr
  by_cases h : u+v=0
  · simp [h]
  · field_simp; ring

/-- Data processing for triangular discrimination on a single cell. -/
theorem discr_integrals_le {Y : Type*} [MeasurableSpace Y] {μ : Measure Y}
    (p q : Y → ℝ) (hp : Integrable p μ) (hq : Integrable q μ)
    (pn : ∀ᵐ y ∂μ, 0 ≤ p y) (qn : ∀ᵐ y ∂μ, 0 ≤ q y)
    (integralDisc : Integrable (fun y => discr (p y) (q y)) μ) :
    discr (∫ y, p y ∂μ) (∫ y, q y ∂μ) ≤ ∫ y, discr (p y) (q y) ∂μ := by
  let t := ((∫ y, p y ∂μ)-(∫ y, q y ∂μ))/((∫ y, p y ∂μ)+(∫ y, q y ∂μ))
  have a : Integrable (fun y => (2*t)*(p y-q y)) μ := (hp.sub hq).const_mul _
  have b : Integrable (fun y => t^2*(p y+q y)) μ := (hp.add hq).const_mul _
  have bound := integral_mono_ae (a.sub b) integralDisc ((pn.and qn).mono (fun y h => dual_discr (t := t) h.1 h.2))
  rw [discr_by_test]
  change (2*t)*_ - t^2*_ ≤ _
  simpa only [Pi.sub_apply,integral_sub a b,integral_const_mul,integral_add hp hq,integral_sub hp hq] using bound

theorem CommonGrid.sum_fibers {Y F : Type*} [MeasurableSpace Y] [NormedAddCommGroup F]
    [NormedSpace ℝ F] {μ : Measure Y} (G : CommonGrid Y) (f : Y → F) (hf : Integrable f μ) :
    (∑ i, ∫ y in G.label ⁻¹' {i}, f y ∂μ) = ∫ y, f y ∂μ := by
  rw [← integral_iUnion_fintype (fun i => G.measurableLabel (measurableSet_singleton i)) _ (fun i => hf.integrableOn)]
  · have full : (⋃ i, G.label ⁻¹' {i}) = univ := by ext y; simp
    rw [full,setIntegral_univ]
  · intro a b hab
    exact Disjoint.preimage G.label (Set.disjoint_singleton.mpr hab)

/-- The right hand side of the geometric *finite* inequality is bounded by
the unquantized discrimination for every grid, including labels of mass zero. -/
theorem grid_discr_le {Y : Type*} [MeasurableSpace Y] {μ : Measure Y}
    (G : CommonGrid Y) (p q : Y → ℝ) (hp : Integrable p μ) (hq : Integrable q μ)
    (pn : ∀ᵐ y ∂μ, 0 ≤ p y) (qn : ∀ᵐ y ∂μ, 0 ≤ q y)
    (hd : Integrable (fun y => discr (p y) (q y)) μ) :
    (∑ i, discr (∫ y in G.label ⁻¹' {i}, p y ∂μ) (∫ y in G.label ⁻¹' {i}, q y ∂μ))
      ≤ ∫ y, discr (p y) (q y) ∂μ := by
  rw [← G.sum_fibers _ hd]
  exact Finset.sum_le_sum (fun i _ => discr_integrals_le _ _ hp.integrableOn hq.integrableOn
    (ae_restrict_of_ae pn) (ae_restrict_of_ae qn) hd.integrableOn)

end
end Vortex
