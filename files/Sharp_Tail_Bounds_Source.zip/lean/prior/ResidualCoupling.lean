import SGFiniteHarmonic
import Mathlib.MeasureTheory.Measure.Sub
import Mathlib.Analysis.Normed.Lp.PiLp

open MeasureTheory Set Filter Function
open scoped ENNReal BigOperators
namespace Residual
noncomputable section

/-- Real masses of labels for an ordinary measurable partition. -/
def mass {X I : Type*} [MeasurableSpace X] (ρ : Measure X) (tag : X → I) (i : I) :=
  ρ.real (tag ⁻¹' {i})

def delta {I : Type*} [Fintype I] (a b : I → ℝ) :=
  ∑ i, (a i-b i)^2/(a i+b i)

def midpoint {X : Type*} [Add X] [SMul ℝ X] (z : X × X) := (1/2 : ℝ) • (z.1+z.2)

def midLaw {X I : Type*} [MeasurableSpace X] [Add X] [SMul ℝ X] [Fintype I]
    (a b : I → ℝ) (γ : I → ProbabilityMeasure (X × X)) : Measure X :=
  ∑ i, ENNReal.ofReal (Vortex.harmonicMass (a i) (b i)) • (γ i : Measure (X × X)).map midpoint

theorem harmonic_defect {a b : ℝ} (_ha : 0 ≤ a) (_hb : 0 ≤ b) :
    (a+b)/2 - Vortex.harmonicMass a b = (a-b)^2/(a+b)/2 := by
  by_cases h : a+b=0
  · simp [Vortex.harmonicMass,h]
  · unfold Vortex.harmonicMass
    field_simp
    ring

theorem mass_sum {X I : Type*} [MeasurableSpace X] [Fintype I] [MeasurableSpace I]
    [MeasurableSingletonClass I] (ρ : Measure X) [IsProbabilityMeasure ρ]
    (tag : X → I) (m : Measurable tag) : ∑ i, mass ρ tag i = 1 := by
  classical
  have dis : Pairwise (Disjoint on fun i : I => tag ⁻¹' {i}) := fun _ _ h =>
    Disjoint.preimage _ (Set.disjoint_singleton.mpr h)
  have un : (⋃ i, tag ⁻¹' {i}) = univ := by ext x; simp
  have e := measure_iUnion dis (fun i => m (measurableSet_singleton i)) (μ := ρ)
  rw [un,measure_univ,tsum_fintype] at e
  have r := congrArg ENNReal.toReal e
  simpa [mass,Measure.real,ENNReal.toReal_sum (fun i _ => measure_ne_top ρ _)] using r.symm

theorem midLaw_mass {X I : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
    [MeasurableSpace X] [BorelSpace X] [SecondCountableTopology X] [Fintype I]
    (a b : I → ℝ) (γ : I → ProbabilityMeasure (X × X))
    (na : ∀ i, 0 ≤ a i) (nb : ∀ i, 0 ≤ b i) (sa : ∑ i, a i=1) (sb : ∑ i, b i=1) :
    (midLaw a b γ).real univ = 1-delta a b/2 := by
  classical
  have mm : Measurable (@midpoint X _ _) := by unfold midpoint; fun_prop
  have ev : (midLaw a b γ) univ = ∑ i, ENNReal.ofReal (Vortex.harmonicMass (a i) (b i)) := by
    simp [midLaw,Measure.finsetSum_apply,Measure.map_apply mm MeasurableSet.univ]
  rw [Measure.real,ev,ENNReal.toReal_sum (fun _ _ => ENNReal.ofReal_ne_top)]
  simp_rw [ENNReal.toReal_ofReal (Vortex.harmonic_nonneg (na _) (nb _))]
  have e := Finset.sum_congr (s₁:=Finset.univ) rfl (fun i _ => harmonic_defect (na i) (nb i))
  simp only [Finset.sum_sub_distrib,←Finset.sum_div,Finset.sum_add_distrib,sa,sb] at e
  unfold delta
  linarith

theorem residual_mass {X I : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
    [MeasurableSpace X] [BorelSpace X] [SecondCountableTopology X] [Fintype I]
    (ρ : Measure X) [IsProbabilityMeasure ρ] (a b : I → ℝ) (γ : I → ProbabilityMeasure (X × X))
    (na : ∀ i, 0 ≤ a i) (nb : ∀ i, 0 ≤ b i) (sa : ∑ i, a i=1) (sb : ∑ i, b i=1)
    (dom : midLaw a b γ ≤ ρ) :
    let ζ := ρ - midLaw a b γ
    ζ ≤ ρ ∧ ζ.real univ = delta a b/2 ∧ ζ + midLaw a b γ = ρ := by
  let η := midLaw a b γ
  have : IsFiniteMeasure η := ⟨(dom _).trans_lt (measure_lt_top ρ univ)⟩
  have e : ρ-η+η = ρ := Measure.sub_add_cancel_of_le dom
  have ne : ρ-η ≤ ρ := Measure.sub_le
  refine ⟨ne,?_,e⟩
  have : IsFiniteMeasure (ρ-η) := ⟨(ne _).trans_lt (measure_lt_top ρ univ)⟩
  have r := congrArg (fun m : Measure X => m.real univ) e
  rw [measureReal_add_apply, show ρ.real univ=1 by simp [Measure.real]] at r
  have v := midLaw_mass a b γ na nb sa sb
  change (ρ-η).real univ = _
  change η.real univ = _ at v
  linarith

end
end Residual
