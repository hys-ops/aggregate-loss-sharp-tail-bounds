import PublishedSG
import Mathlib.Analysis.Calculus.BumpFunction.FiniteDimension
import Mathlib.Analysis.Distribution.AEEqOfIntegralContDiff

open MeasureTheory Set Filter
open scoped Topology ContDiff
namespace Vortex
noncomputable section

/-- Weak continuity equation between two finite indicator traces. The current is horizontal;
μ is the spacetime occupation measure and w is its horizontal velocity. -/
def HorizontalTrace (E0 E : Set Space) (μ : Measure (ℝ × Space)) (w : ℝ × Space → H) : Prop :=
  ∀ f : Space → ℝ, ContDiff ℝ ∞ f → HasCompactSupport f →
    (∫ y in E, f y) - (∫ y in E0, f y) =
      ∫ s, fderiv ℝ f s.2 (w s,0) ∂μ

def traceBump : ContDiffBump (0 : Space) := ⟨1,2,by norm_num,by norm_num⟩
def traceScale (n : ℕ) : ℝ := 1/((n : ℝ)+1)
private def test (g : ℝ → ℝ) (n : ℕ) (y : Space) := traceBump (traceScale n • y)*g y.2
theorem traceScale_pos (n : ℕ) : 0 < traceScale n := by unfold traceScale; positivity
theorem traceScale_tendsto : Tendsto traceScale atTop (𝓝 0) := tendsto_one_div_add_atTop_nhds_zero_nat

private theorem test_smooth (g : ℝ → ℝ) (hg : ContDiff ℝ ∞ g) (n : ℕ) :
    ContDiff ℝ ∞ (test g n) := by
  have scaled : ContDiff ℝ ∞ (fun y : Space => traceScale n • y) :=
    (traceScale n • ContinuousLinearMap.id ℝ Space).contDiff
  exact (traceBump.contDiff.comp scaled).mul (hg.comp contDiff_snd)
private theorem test_compact (g : ℝ → ℝ) (n : ℕ) : HasCompactSupport (test g n) :=
  (traceBump.hasCompactSupport.comp_homeomorph
    (Homeomorph.smulOfNeZero (α := Space) (traceScale n) (traceScale_pos n).ne')).mul_right

private theorem test_horizontal (g : ℝ → ℝ) (hg : ContDiff ℝ ∞ g) (n : ℕ) (y : Space) (v : H) :
    fderiv ℝ (test g n) y (v,0) =
      g y.2 * (fderiv ℝ (traceBump : Space → ℝ) (traceScale n • y)) (traceScale n • (v,0)) := by
  let L : Space →L[ℝ] Space := traceScale n • ContinuousLinearMap.id ℝ Space
  change fderiv ℝ (((traceBump : Space → ℝ) ∘ L) * (g ∘ Prod.snd)) y (v,0) = _
  have db := (traceBump.contDiff (n := ⊤)).differentiable (by simp)
  have dg := hg.differentiable (by simp)
  rw [fderiv_mul ((db.comp L.differentiable).differentiableAt)
    ((dg.comp differentiable_snd).differentiableAt),
    fderiv_comp y db.differentiableAt L.differentiableAt, L.fderiv,
    fderiv_comp y dg.differentiableAt differentiableAt_snd, fderiv_snd]
  rw [map_smul]
  simp [L]

private theorem boundary_vanishes (g : ℝ → ℝ) (hg : ContDiff ℝ ∞ g) (hc : HasCompactSupport g)
    (μ : Measure (ℝ × Space)) (w : ℝ × Space → H) (hw : Integrable w μ) :
    Tendsto (fun n => ∫ s, fderiv ℝ (test g n) s.2 (w s,0) ∂μ) atTop (𝓝 0) := by
  obtain ⟨C,hC⟩ := hc.exists_bound_of_continuous hg.continuous
  obtain ⟨K,hK⟩ := (traceBump.hasCompactSupport.fderiv ℝ).exists_bound_of_continuous
    ((traceBump.contDiff (n := ⊤)).continuous_fderiv (by simp))
  have C0 : 0 ≤ C := (norm_nonneg _).trans (hC 0)
  apply squeeze_zero_norm (a := fun n => traceScale n*((C*K)*∫ s, ‖w s‖ ∂μ))
  · intro n
    calc
      _ ≤ ∫ s, (traceScale n*(C*K))*‖w s‖ ∂μ := by
        apply norm_integral_le_of_norm_le (hw.norm.const_mul _)
        filter_upwards with s
        rw [test_horizontal g hg,norm_mul]
        have h := (fderiv ℝ (traceBump : Space → ℝ) (traceScale n • s.2)).le_opNorm (traceScale n • (w s,0))
        have hh := h.trans (mul_le_mul_of_nonneg_right (hK _) (norm_nonneg _))
        rw [norm_smul,show ‖traceScale n‖ = traceScale n from Real.norm_of_nonneg (traceScale_pos n).le] at hh
        have hv : ‖((w s,0) : Space)‖ = ‖w s‖ := by simp [Prod.norm_def]
        rw [hv] at hh
        calc
          _ ≤ C*(K*(traceScale n*‖w s‖)) :=
            mul_le_mul (hC _) hh (norm_nonneg _) C0
          _ = _ := by ring
      _ = _ := by rw [integral_const_mul]; ring
  · simpa using traceScale_tendsto.mul_const ((C*K)*∫ s, ‖w s‖ ∂μ)

private theorem trace_limit (A : Set Space) (hA : volume A ≠ ⊤) (g : ℝ → ℝ)
    (hg : ContDiff ℝ ∞ g) (hc : HasCompactSupport g) :
    Tendsto (fun n => ∫ y in A, test g n y) atTop (𝓝 (∫ y in A, g y.2)) := by
  obtain ⟨C,hC⟩ := hc.exists_bound_of_continuous hg.continuous
  apply tendsto_integral_of_dominated_convergence (fun _ => C)
    (fun n => (test_smooth g hg n).continuous.aestronglyMeasurable) (integrableOn_const hA)
  · intro n
    filter_upwards with y
    unfold test
    rw [norm_mul,Real.norm_eq_abs,abs_of_nonneg traceBump.nonneg]
    exact (mul_le_mul_of_nonneg_right traceBump.le_one (norm_nonneg _)).trans (by simpa using hC y.2)
  · filter_upwards with y
    have h : Tendsto (fun n => traceScale n • y) atTop (𝓝 (0 : Space)) := by
      simpa using traceScale_tendsto.smul_const y
    have b0 : traceBump 0 = 1 := traceBump.one_of_mem_closedBall (Metric.mem_closedBall_self traceBump.rIn_pos.le)
    simpa [test,b0] using (traceBump.continuous.continuousAt.tendsto.comp h).mul_const (g y.2)

/-- Compactly supported spatial tests suffice for every smooth compact height test,
even when the horizontal patch support is unbounded. -/
theorem height_test_conserved (E0 E : Set Space) (h0 : volume E0 ≠ ⊤) (hE : volume E ≠ ⊤)
    (μ : Measure (ℝ × Space)) (w : ℝ × Space → H) (hw : Integrable w μ)
    (eqn : HorizontalTrace E0 E μ w) (g : ℝ → ℝ) (hg : ContDiff ℝ ∞ g) (hc : HasCompactSupport g) :
    (∫ y in E, g y.2) = ∫ y in E0, g y.2 := by
  have L := (trace_limit E hE g hg hc).sub (trace_limit E0 h0 g hg hc)
  have R := boundary_vanishes g hg hc μ w hw
  apply sub_eq_zero.mp
  apply tendsto_nhds_unique L
  exact R.congr (fun n => (eqn _ (test_smooth g hg n) (test_compact g n)).symm)

private theorem section_data (A : Set Space) (mA : MeasurableSet A) (fA : volume A ≠ ⊤) :
    Integrable (fun z => volume.real (slice A z)) ∧ ∀ᵐ z : ℝ, volume (slice A z) ≠ ⊤ := by
  have h := Measure.prod_apply_symm (μ := (volume : Measure H)) (ν := (volume : Measure ℝ)) mA
  have hs : (∫⁻ z, volume (slice A z)) ≠ ⊤ := by
    change (∫⁻ z, volume ((fun x : H => (x,z)) ⁻¹' A)) ≠ ⊤
    rw [← h]; exact fA
  have hm : Measurable (fun z => volume (slice A z)) := measurable_measure_prodMk_right mA
  exact ⟨integrable_toReal_of_lintegral_ne_top hm.aemeasurable hs,
    (ae_lt_top hm hs).mono (fun _ hlt => hlt.ne)⟩

private theorem test_by_sections (A : Set Space) (mA : MeasurableSet A) (fA : volume A ≠ ⊤)
    (g : ℝ → ℝ) (hg : ContDiff ℝ ∞ g) (hc : HasCompactSupport g) :
    (∫ y in A, g y.2) = ∫ z, g z • volume.real (slice A z) := by
  obtain ⟨C,hC⟩ := hc.exists_bound_of_continuous hg.continuous
  have hi : IntegrableOn (fun y : Space => g y.2) A :=
    (integrableOn_const (C := C) fA).mono' (hg.continuous.comp continuous_snd).aestronglyMeasurable
      (Filter.Eventually.of_forall (fun y => hC y.2))
  rw [← integral_indicator mA, Measure.volume_eq_prod H ℝ,integral_prod_symm _ ((integrable_indicator_iff mA).mpr hi)]
  apply integral_congr_ae
  filter_upwards with z
  have hz : MeasurableSet (slice A z) := mA.preimage (measurable_id.prodMk measurable_const)
  change (∫ x : H, (slice A z).indicator (fun _ => g z) x) = _
  rw [integral_indicator hz,setIntegral_const]
  simp [smul_eq_mul,mul_comm]

/-- Area equality, not merely equality of total patch mass. No slice conservation premise. -/
theorem slice_area_from_horizontal_transport (E0 E : Set Space) (m0 : MeasurableSet E0)
    (mE : MeasurableSet E) (h0 : volume E0 ≠ ⊤) (hE : volume E ≠ ⊤)
    (μ : Measure (ℝ × Space)) (w : ℝ × Space → H) (hw : Integrable w μ)
    (eqn : HorizontalTrace E0 E μ w) :
    ∀ᵐ z : ℝ, volume (slice E z) = volume (slice E0 z) := by
  obtain ⟨hi,finite⟩ := section_data E mE hE
  obtain ⟨hi0,finite0⟩ := section_data E0 m0 h0
  have ha := ae_eq_of_integral_contDiff_smul_eq hi.locallyIntegrable hi0.locallyIntegrable
    (fun g hg hc => (test_by_sections E mE hE g hg hc).symm.trans
      ((height_test_conserved E0 E h0 hE μ w hw eqn g hg hc).trans (test_by_sections E0 m0 h0 g hg hc)))
  filter_upwards [ha,finite,finite0] with z hz h1 h2
  exact (ENNReal.toReal_eq_toReal_iff' h1 h2).mp hz

end
end Vortex
