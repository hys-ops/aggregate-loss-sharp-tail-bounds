import SGFiniteMidpointInput
import Mathlib.Analysis.Convex.Integral

open MeasureTheory Set
open scoped ENNReal NNReal InnerProductSpace BigOperators
namespace Vortex
noncomputable section

def harmonicMass (a b : ℝ) := 2*a*b/(a+b)
theorem harmonic_nonneg {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) : 0 ≤ harmonicMass a b :=
  div_nonneg (by positivity) (add_nonneg ha hb)

theorem harmonic_le_sqrt {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) : harmonicMass a b ≤ Real.sqrt (a*b) := by
  by_cases s : 0 < a+b
  · apply (div_le_iff₀ s).mpr
    have h1 := Real.sq_sqrt (mul_nonneg ha hb)
    have ham : 2*Real.sqrt (a*b) ≤ a+b := by
      rw [Real.sqrt_mul ha]
      nlinarith only [sq_nonneg (Real.sqrt a-Real.sqrt b),Real.sq_sqrt ha,Real.sq_sqrt hb]
    nlinarith only [h1,mul_le_mul_of_nonneg_right ham (Real.sqrt_nonneg (a*b))]
  · have za : a=0 := by linarith
    simp [harmonicMass,za]

/-- The single exact radius-defect identity includes one or two empty label cells. -/
theorem harmonic_energy_identity {F : Type*} [NormedAddCommGroup F] [InnerProductSpace ℝ F]
    (a b C : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (X Z : F) :
    (a*(C-‖X‖^2)+b*(C-‖Z‖^2))/2 - harmonicMass a b*(C-‖(1/2:ℝ) • (X+Z)‖^2) =
      (C*discr a b-‖a • X - b • Z‖^2/(a+b))/2 := by
  by_cases e : a+b=0
  · have az : a=0 := by linarith
    have bz : b=0 := by linarith
    simp [az,bz,harmonicMass,discr]
  · rw [norm_sub_sq_real,norm_smul,norm_smul,norm_smul,real_inner_smul_left,real_inner_smul_right,
      Real.norm_of_nonneg ha,Real.norm_of_nonneg hb]
    simp only [mul_pow,norm_add_sq_real]
    simp only [Real.norm_of_nonneg (by norm_num : 0 ≤ (1/2:ℝ))]
    unfold harmonicMass discr
    field_simp [e]
    ring

private theorem comp_integrable {X F : Type*} [TopologicalSpace X] [CompactSpace X]
    [MeasurableSpace X] [OpensMeasurableSpace X] [T2Space X] [NormedAddCommGroup F]
    [SecondCountableTopology F] (μ : Measure X) [IsFiniteMeasure μ] (f : X → F) (hf : Continuous f) :
    Integrable f μ := by
  obtain ⟨D,hD⟩ := (isCompact_univ.image hf.norm).bddAbove
  exact (integrable_const D).mono' hf.aestronglyMeasurable
    (.of_forall fun x => hD (mem_image_of_mem _ (mem_univ x)))

/-- Integrate the exact harmonic identity against its cell coupling, then apply Jensen
to the actual vector-valued moment difference. -/
theorem harmonic_coupling_step {X F : Type*} [TopologicalSpace X] [CompactSpace X]
    [MeasurableSpace X] [OpensMeasurableSpace X] [T2Space X]
    [NormedAddCommGroup F] [InnerProductSpace ℝ F] [CompleteSpace F] [SecondCountableTopology F]
    (γ : ProbabilityMeasure X) (u v : X → F) (hu : Continuous u) (hv : Continuous v)
    (a b C : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) :
    ‖a • (∫ x,u x ∂(γ:Measure X))-b • (∫ x,v x ∂(γ:Measure X))‖^2/(a+b) +
      a*(∫ x,C-‖u x‖^2 ∂(γ:Measure X)) + b*(∫ x,C-‖v x‖^2 ∂(γ:Measure X)) -
      2*harmonicMass a b*(∫ x,C-‖(1/2:ℝ) • (u x+v x)‖^2 ∂(γ:Measure X)) ≤ C*discr a b := by
  let μ : Measure X := γ
  let g := fun x => a • u x-b • v x
  let pu := fun x => C-‖u x‖^2
  let pv := fun x => C-‖v x‖^2
  let pm := fun x => C-‖(1/2:ℝ) • (u x+v x)‖^2
  have cg : Continuous g := (hu.const_smul a).sub (hv.const_smul b)
  have iu := comp_integrable μ u hu
  have iv := comp_integrable μ v hv
  have ig := comp_integrable μ g cg
  have ip := comp_integrable μ pu (continuous_const.sub (hu.norm.pow _))
  have iq := comp_integrable μ pv (continuous_const.sub (hv.norm.pow _))
  have im := comp_integrable μ pm (continuous_const.sub (((hu.add hv).const_smul (1/2:ℝ)).norm.pow _))
  have isq := comp_integrable μ (fun x => ‖g x‖^2) (cg.norm.pow 2)
  have m : (∫ x,g x ∂μ) = a • (∫ x,u x ∂μ) - b • (∫ x,v x ∂μ) := by
    unfold g
    rw [integral_sub (f := fun x => a • u x) (g := fun x => b • v x) (iu.smul a) (iv.smul b),
      integral_smul, integral_smul]
  have jensen : ‖∫ x,g x ∂μ‖^2 ≤ ∫ x,‖g x‖^2 ∂μ := by
    have js := (even_two.convexOn_pow (𝕜 := ℝ)).map_integral_le (μ := μ)
      (f := fun x => ‖g x‖) (continuous_pow 2).continuousOn isClosed_univ
      (.of_forall fun _ => mem_univ _) ig.norm isq
    exact (pow_le_pow_left₀ (norm_nonneg _) (norm_integral_le_integral_norm (μ := μ) g) 2).trans js
  have ident (x : X) :
      ‖g x‖^2/(a+b) + (a*pu x + b*pv x) - (2*harmonicMass a b)*pm x = C*discr a b := by
    have h := harmonic_energy_identity a b C ha hb (u x) (v x)
    dsimp [pu,pv,pm,g]
    linarith
  have hi := congrArg (fun f : X → ℝ => ∫ x,f x ∂μ) (funext ident)
  change (∫ x, ‖g x‖^2/(a+b)+(a*pu x + b*pv x) - (2*harmonicMass a b)*pm x ∂μ) = _ at hi
  rw [integral_sub (f := fun x => ‖g x‖^2/(a+b)+(a*pu x+b*pv x)) (g := fun x => (2*harmonicMass a b)*pm x)
      ((isq.div_const _).add ((ip.const_mul _).add (iq.const_mul _))) (im.const_mul _),
    integral_add (f := fun x => ‖g x‖^2/(a+b)) (g := fun x => a*pu x+b*pv x) (isq.div_const _) ((ip.const_mul _).add (iq.const_mul _)),
    integral_add (f := fun x => a*pu x) (g := fun x => b*pv x) (ip.const_mul _) (iq.const_mul _),
    integral_div,integral_const_mul,integral_const_mul,integral_const_mul,integral_const] at hi
  have normprob : μ.real univ = 1 := by simp [μ,Measure.real]
  change _ = μ.real univ • (C*discr a b) at hi
  rw [normprob,one_smul] at hi
  rw [m] at jensen
  have divbd := div_le_div_of_nonneg_right jensen (add_nonneg ha hb)
  change _/(a+b) + a*(∫ x,pu x ∂μ) + b*(∫ x,pv x ∂μ) -
    2*harmonicMass a b*(∫ x,pm x ∂μ) ≤ _
  linarith

end
end Vortex
