import ResidualWeightMoments
import Mathlib.Analysis.LocallyConvex.Separation

open MeasureTheory Set Filter
open scoped BigOperators Topology
noncomputable section
namespace JointResidual
variable {X : Type*} [MeasurableSpace X] {d : ℕ}
abbrev Vec (d : ℕ) := Fin d → ℝ

def Selector (ρ : Measure X) (g : X → ℝ) : Prop :=
  Measurable g ∧ ∀ᵐ x ∂ρ, g x ∈ Icc 0 1

theorem Selector.adm {ρ : Measure X} {g : X → ℝ} (hg : Selector ρ g) :
    Residual.admissibleWeight ρ (∫ x,g x ∂ρ) g := ⟨hg.1,hg.2,rfl⟩

def value (ρ : Measure X) (F : X → Vec d) (g : X → ℝ) : Vec d :=
  fun j => ∫ x,g x * F x j ∂ρ

def body (ρ : Measure X) (F : X → Vec d) : Set (Vec d) :=
  {v | ∃ g, Selector ρ g ∧ v = value ρ F g}

theorem featureLaw (ρ : Measure X) [IsProbabilityMeasure ρ]
    (F : X → Vec d) (mF : Measurable F) :
    body ρ F = body (ρ.map F) id := by
  ext v; constructor
  · rintro ⟨g,hg,rfl⟩
    let η := (Residual.weightMeasure ρ g).map F
    have sub : η ≤ ρ.map F := Measure.map_mono (Residual.weightMeasure_le hg.adm) mF
    obtain ⟨h,ok,eq⟩ := Residual.density_of_submeasure sub
    refine ⟨h,⟨ok.1,ok.2.1⟩,?_⟩
    funext j; change (∫ x,g x*F x j ∂ρ)=∫ y,h y*y j ∂ρ.map F
    rw [eq]; change _ = ∫ y,y j ∂(Residual.weightMeasure ρ g).map F
    rw [integral_map mF.aemeasurable (measurable_pi_apply j).aestronglyMeasurable,
      Residual.weightMeasure_integral hg.adm]
  · rintro ⟨g,hg,rfl⟩
    refine ⟨g ∘ F,⟨hg.1.comp mF,(ae_map_iff mF.aemeasurable (measurableSet_Icc.preimage hg.1)).mp hg.2⟩,?_⟩
    funext j
    exact integral_map mF.aemeasurable (hg.1.mul (measurable_pi_apply j)).aestronglyMeasurable

private theorem compactOnLaw (P : ProbabilityMeasure (Vec d))
    (hF : ∀ j : Fin d,Integrable (fun x : Vec d => x j) (P : Measure (Vec d))) :
    IsCompact (body (P : Measure (Vec d)) id) := by
  apply isCompact_iff_isSeqCompact.mpr
  intro A hA
  choose g hg eq using hA
  let Z := fun n => Residual.weightMeasure (P : Measure (Vec d)) (g n)
  obtain ⟨η,sub,r,inc,lim⟩ := Residual.dominated_subsequence P Z (fun n => Residual.weightMeasure_le (hg n).adm)
  obtain ⟨h,ok,he⟩ := Residual.density_of_submeasure sub
  refine ⟨_,⟨h,⟨ok.1,ok.2.1⟩,rfl⟩,r,inc,tendsto_pi_nhds.mpr ?_⟩
  intro j
  have t := lim (fun z => z j) (hF j)
  rw [← he] at t
  simpa only [Z,Residual.weightMeasure_integral (hg _).adm,eq,Function.comp_apply,value,id] using t

theorem compactBody (ρ : Measure X) [IsProbabilityMeasure ρ] (F : X → Vec d)
    (hF : ∀ j,Integrable (fun x => F x j) ρ) : IsCompact (body ρ F) := by
  choose G mG eq using fun j => (hF j).aestronglyMeasurable.aemeasurable
  let Z (x : X) (j : Fin d) := G j x
  have mz : Measurable Z := measurable_pi_iff.mpr mG
  have vb (g : X → ℝ) : value ρ F g=value ρ Z g := by
    funext j; exact integral_congr_ae ((eq j).mono fun x hx => congrArg (g x * ·) hx)
  have same : body ρ F=body ρ Z := by unfold body; simp only [vb]
  rw [same,featureLaw ρ Z mz]
  let _ : IsProbabilityMeasure (ρ.map Z) := (Measure.isProbabilityMeasure_map_iff mz.aemeasurable).mpr inferInstance
  apply compactOnLaw (⟨ρ.map Z,inferInstance⟩ : ProbabilityMeasure (Vec d))
  intro j
  apply (integrable_map_measure (measurable_pi_apply j).aestronglyMeasurable mz.aemeasurable).mpr
  exact (hF j).congr (eq j)

theorem convexBody (ρ : Measure X) (F : X → Vec d)
    (hF : ∀ j,Integrable (fun x => F x j) ρ) : Convex ℝ (body ρ F) := by
  rintro _ ⟨g,hg,rfl⟩ _ ⟨h,hh,rfl⟩ a b ha hb hab
  refine ⟨fun x => a*g x+b*h x,⟨(measurable_const.mul hg.1).add (measurable_const.mul hh.1),?_⟩,?_⟩
  · filter_upwards [hg.2,hh.2] with x hx hy
    exact ⟨add_nonneg (mul_nonneg ha hx.1) (mul_nonneg hb hy.1),by
      simpa only [mul_one,hab] using add_le_add (mul_le_mul_of_nonneg_left hx.2 ha) (mul_le_mul_of_nonneg_left hy.2 hb)⟩
  · funext j
    change a*(∫ x,g x*F x j ∂ρ)+b*(∫ x,h x*F x j ∂ρ)=∫ x,(a*g x+b*h x)*F x j ∂ρ
    simp only [add_mul,mul_assoc]
    rw [integral_add ((Residual.admissible_integrable_mul hg.adm (hF j)).const_mul _)
      ((Residual.admissible_integrable_mul hh.adm (hF j)).const_mul _),integral_const_mul,integral_const_mul]

def test (a v : Vec d) : ℝ := ∑ i,a i*v i

theorem test_value (ρ : Measure X) (F : X → Vec d)
    (hF : ∀ j,Integrable (fun x => F x j) ρ) {g} (hg : Selector ρ g) (a : Vec d) :
    test a (value ρ F g)=∫ x,g x*test a (F x) ∂ρ := by
  have eq (x) : g x*test a (F x)=∑ j,a j*(g x*F x j) := by
    unfold test; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun j _ => by ring
  simp only [eq]
  rw [integral_finsetSum _ (fun j _ => (Residual.admissible_integrable_mul hg.adm (hF j)).const_mul (a j))]
  simp [test,value,integral_const_mul]

theorem testIntegrable {ρ : Measure X} {F : X → Vec d} (hF : ∀ j,Integrable (fun x => F x j) ρ)
    (a : Vec d) : Integrable (fun x => test a (F x)) ρ :=
  integrable_finsetSum _ fun j _ => (hF j).const_mul (a j)

/-- Sharp positive-part support, including attainment by a shared selector. -/
theorem support (ρ : Measure X) (F : X → Vec d) (hF : ∀ j,Integrable (fun x => F x j) ρ)
    (a : Vec d) : IsGreatest (test a '' body ρ F) (∫ x,max (test a (F x)) 0 ∂ρ) := by
  let W := fun x => test a (F x)
  have iw : Integrable W ρ := testIntegrable hF a
  obtain ⟨V,mv,ev⟩ := iw.aestronglyMeasurable.aemeasurable
  let g := fun x => if 0 < V x then (1:ℝ) else 0
  have hg : Selector ρ g := ⟨Measurable.ite (measurableSet_lt measurable_const mv) measurable_const measurable_const,
    .of_forall fun x => by dsimp [g]; split <;> simp⟩
  constructor
  · refine ⟨_,⟨g,hg,rfl⟩,?_⟩
    rw [test_value ρ F hF hg]
    apply integral_congr_ae
    filter_upwards [ev] with x hx
    change g x*W x=max (W x) 0
    dsimp [g]; rw [hx]; split_ifs with h
    · rw [one_mul,max_eq_left h.le]
    · rw [zero_mul,max_eq_right (le_of_not_gt h)]
  · rintro _ ⟨_,⟨h,hh,rfl⟩,rfl⟩
    rw [test_value ρ F hF hh]
    apply integral_mono_ae (Residual.admissible_integrable_mul hh.adm iw) iw.pos_part
    filter_upwards [hh.2] with x hx
    change h x*W x≤max (W x) 0
    rcases le_total 0 (W x) with hp|hn
    · simpa [max_eq_left hp] using mul_le_mul_of_nonneg_right hx.2 hp
    · exact (mul_nonpos_of_nonneg_of_nonpos hx.1 hn).trans (le_max_right _ _)

private theorem dual_coordinates (l : (Vec d) →L[ℝ] ℝ) (v : Vec d) :
    l v = test (fun j => l (Pi.single j 1)) v := by
  classical
  have e : v = ∑ j,v j • Pi.single j (1:ℝ) := by
    ext k; simp [Finset.sum_apply,Pi.single_apply,Pi.smul_apply]
  conv_lhs => rw [e]
  simp [test,map_sum,mul_comm]

/-- Exact common-residual membership on any probability space, for arbitrary signed L1 features. -/
theorem mem_iff_tests (ρ : Measure X) [IsProbabilityMeasure ρ] (F : X → Vec d)
    (hF : ∀ j,Integrable (fun x => F x j) ρ) (v : Vec d) :
    v ∈ body ρ F ↔ ∀ a : Vec d, test a v ≤ ∫ x,max (test a (F x)) 0 ∂ρ := by
  constructor
  · exact fun hv a => (support ρ F hF a).2 ⟨v,hv,rfl⟩
  · intro all; by_contra no
    obtain ⟨l,b,small,large⟩ := geometric_hahn_banach_closed_point (convexBody ρ F hF) (compactBody ρ F hF).isClosed no
    let a : Vec d := fun j => l (Pi.single j 1)
    obtain ⟨z,hz,eq⟩ := (support ρ F hF a).1
    have tz := small z hz
    rw [dual_coordinates l z] at tz
    rw [dual_coordinates l v] at large
    exact (not_lt_of_ge (all a)) (eq ▸ lt_trans tz large)

end JointResidual
