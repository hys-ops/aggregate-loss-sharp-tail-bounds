import ResidualMatrix
import Mathlib.MeasureTheory.Function.LpSpace.Basic

open MeasureTheory Set Filter Matrix
open scoped ENNReal BigOperators
namespace Residual
noncomputable section

variable {X I : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
    [MeasurableSpace X] [BorelSpace X] [SecondCountableTopology X]
    [Fintype I] [MeasurableSpace I] [MeasurableSingletonClass I]

/-- A single submeasure is chosen before the feature dimension, linear rows, and offsets. -/
def FiniteConclusion (ρ : Measure X) (j k : X → I) : Prop :=
  ∃ ζ : Measure X, ζ ≤ ρ ∧ ζ.real univ = delta (mass ρ j) (mass ρ k)/2 ∧
    ∀ (m : ℕ) (L : Fin m → X →L[ℝ] ℝ) (c : Fin m → ℝ),
      let F := fun i x => L i x+c i
      ((2:ℝ) • outerMoment ζ F-errorMatrix ρ j k F).PosSemidef ∧
      ∀ v, 2*(∫ x,F v x ∂ζ) =
        ∑ i,(mass ρ j i-mass ρ k i)*change ρ j k (F v) i/(mass ρ j i+mass ρ k i)

theorem finite_from_couplings (ρ : Measure X) [IsProbabilityMeasure ρ] (j k : X → I)
    (mj : Measurable j) (mk : Measurable k) (hρ : Integrable (fun x : X => ‖x‖^2) ρ)
    (q : CoupledCells ρ j k) : FiniteConclusion ρ j k := by
  let η := midLaw (mass ρ j) (mass ρ k) q.plans
  let ζ := ρ-η
  obtain ⟨le,sz,_⟩ := residual_mass ρ _ _ q.plans (fun _ => measureReal_nonneg) (fun _ => measureReal_nonneg)
    (mass_sum ρ j mj) (mass_sum ρ k mk) q.dominated
  refine ⟨ζ,le,sz,?_⟩
  intro m L c
  let F := fun (i : Fin m) (x : X) => L i x+c i
  have lid : MemLp (fun x : X => x) 2 ρ := (memLp_two_iff_integrable_sq_norm measurable_id.aestronglyMeasurable).mpr hρ
  have iF (i) : MemLp (F i) 2 ρ := (lid.continuousLinearMap_comp (L i)).add (memLp_const _)
  have mF (i) : Measurable (F i) := (L i).continuous.measurable.add measurable_const
  have aff (i) (x y : X) : F i (midpoint (x,y))=(F i x+F i y)/2 := by
    simp [F,midpoint,map_smul,map_add,smul_eq_mul]; ring
  constructor
  · apply matrix_from_tests ρ ζ j k F (fun i => (iF i).integrable (by norm_num)) (fun i => (iF i).mono_measure le)
    intro v
    apply scalar_from_couplings ρ j k mj mk q
    · exact Finset.measurable_sum _ fun i _ => measurable_const.mul (mF i)
    · exact memLp_finsetSum _ (fun i _ => (iF i).const_mul (v i))
    · intro x y
      simp only [mix,aff,mul_div_assoc',mul_add,←Finset.sum_div,Finset.sum_add_distrib]
  · intro v
    exact first_from_couplings ρ j k mj mk q (F v) (mF v) (iF v) (aff v)
end
end Residual
