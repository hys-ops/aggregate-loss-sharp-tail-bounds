import ResidualApproxLimits
import ResidualGaussianUpperTrim

open MeasureTheory Matrix Set Filter
open scoped Topology ENNReal BigOperators
namespace Residual
noncomputable section
variable {X : Type*} [MeasurableSpace X] {d : ℕ}

def weightedMoment (ρ : Measure X) (g : X → ℝ) (F : Fin d → X → ℝ) : Matrix (Fin d) (Fin d) ℝ :=
  fun i j => ∫ x, g x*(F i x*F j x) ∂ρ

def weightMoments (ρ : Measure X) (u : ℝ) (F : Fin d → X → ℝ) : Set (Matrix (Fin d) (Fin d) ℝ) :=
  {A | ∃ g, admissibleWeight ρ u g ∧ A = weightedMoment ρ g F}

theorem admissible_integrable_mul {ρ : Measure X} {g W : X → ℝ} {u : ℝ}
    (hg : admissibleWeight ρ u g) (hw : Integrable W ρ) : Integrable (fun x => g x*W x) ρ :=
  hw.bdd_mul hg.1.aestronglyMeasurable (hg.2.1.mono fun x hx => by
    rw [Real.norm_eq_abs,abs_of_nonneg hx.1]; exact hx.2)

theorem weightMoments_sym {ρ : Measure X} {u : ℝ} {F : Fin d → X → ℝ} :
    ∀ A∈weightMoments ρ u F, A.IsHermitian := by
  rintro _ ⟨g,_,rfl⟩; ext i j; simp [weightedMoment,conjTranspose_apply,mul_comm]

theorem weightMoments_convex (ρ : Measure X) [IsProbabilityMeasure ρ] (u : ℝ)
    (F : Fin d → X → ℝ) (hF : ∀ i, MemLp (F i) 2 ρ) : Convex ℝ (weightMoments ρ u F) := by
  rintro A ⟨g,hg,rfl⟩ B ⟨h,hh,rfl⟩ a b ha hb hab
  let g' := fun x => a*g x + b*h x
  have ig {s : X → ℝ} (hs : admissibleWeight ρ u s) : Integrable s ρ := by
    simpa using admissible_integrable_mul hs (integrable_const (1:ℝ))
  have ag : admissibleWeight ρ u g' := by
    refine ⟨(measurable_const.mul hg.1).add (measurable_const.mul hh.1),?_,?_⟩
    · filter_upwards [hg.2.1,hh.2.1] with x gx hx
      exact ⟨add_nonneg (mul_nonneg ha gx.1) (mul_nonneg hb hx.1),by
        change a*g x+b*h x≤1
        simpa only [mul_one,hab] using add_le_add (mul_le_mul_of_nonneg_left gx.2 ha) (mul_le_mul_of_nonneg_left hx.2 hb)⟩
    · rw [show (∫ x,g' x ∂ρ) = a*(∫ x,g x ∂ρ)+b*(∫ x,h x ∂ρ) by
          dsimp [g']; rw [integral_add ((ig hg).const_mul _) ((ig hh).const_mul _),integral_const_mul,integral_const_mul],
        hg.2.2,hh.2.2,←add_mul,hab,one_mul]
  refine ⟨g',ag,?_⟩
  ext i j
  have w : Integrable (fun x => F i x*F j x) ρ := (hF i).integrable_mul (hF j)
  have igl := (admissible_integrable_mul hg w).const_mul a
  have ihl := (admissible_integrable_mul hh w).const_mul b
  change a*(∫ x,g x*(F i x*F j x) ∂ρ)+b*(∫ x,h x*(F i x*F j x) ∂ρ) = ∫ x,(a*g x+b*h x)*(F i x*F j x) ∂ρ
  simp only [add_mul,mul_assoc]; rw [integral_add igl ihl,integral_const_mul,integral_const_mul]

def weightMeasure (ρ : Measure X) (g : X → ℝ) := ρ.withDensity (fun x => ENNReal.ofReal (g x))

theorem weightMeasure_le {ρ : Measure X} {g : X → ℝ} {u : ℝ} (hg : admissibleWeight ρ u g) : weightMeasure ρ g ≤ ρ := by
  calc
    _ ≤ ρ.withDensity 1 := withDensity_mono (hg.2.1.mono (fun x hx => ENNReal.ofReal_le_one.mpr hx.2))
    _ = _ := withDensity_one

theorem weightMeasure_integral {ρ : Measure X} {g : X → ℝ} {u : ℝ} (hg : admissibleWeight ρ u g)
    (f : X → ℝ) : (∫ x,f x ∂weightMeasure ρ g)=∫ x,g x*f x ∂ρ := by
  rw [weightMeasure,integral_withDensity_eq_integral_toReal_smul hg.1.ennreal_ofReal (.of_forall fun x => ENNReal.ofReal_lt_top)]
  apply integral_congr_ae; filter_upwards [hg.2.1] with x hx
  rw [ENNReal.toReal_ofReal hx.1,smul_eq_mul]

theorem weightMeasure_mass {ρ : Measure X} {g : X → ℝ} {u : ℝ} (hg : admissibleWeight ρ u g) :
    (weightMeasure ρ g).real univ = u := by
  simpa [hg.2.2] using weightMeasure_integral hg (fun _ => (1:ℝ))

theorem density_of_submeasure {ρ : Measure X} [IsFiniteMeasure ρ] {ζ : Measure X} (sub : ζ≤ρ) :
    ∃ g, admissibleWeight ρ (ζ.real univ) g ∧ ∀ f : X → ℝ, (∫ x,g x*f x ∂ρ)=∫ x,f x ∂ζ := by
  let _ := isFiniteMeasure_of_le _ sub
  let g := fun x => (ζ.rnDeriv ρ x).toReal
  refine ⟨g,⟨(Measure.measurable_rnDeriv _ _).ennreal_toReal,?_,Measure.integral_toReal_rnDeriv sub.absolutelyContinuous⟩,
    fun _ => integral_toReal_rnDeriv_mul sub.absolutelyContinuous⟩
  filter_upwards [Measure.rnDeriv_le_one_of_le sub] with x hx
  exact ⟨ENNReal.toReal_nonneg,(ENNReal.toReal_mono ENNReal.one_ne_top hx).trans_eq ENNReal.toReal_one⟩

/-- Subsequence compactness of dominated measures preserves all moment entries,
even for unbounded square-integrable features. -/
theorem weightMoments_compact_polish [MetricSpace X] [BorelSpace X] [SecondCountableTopology X]
    [CompleteSpace X] (P : ProbabilityMeasure X) (u : ℝ) (F : Fin d → X → ℝ)
    (hF : ∀ i, MemLp (F i) 2 (P : Measure X)) : IsCompact (weightMoments (P : Measure X) u F) := by
  let _ : TopologicalSpace.PseudoMetrizableSpace (Matrix (Fin d) (Fin d) ℝ) := inferInstanceAs (TopologicalSpace.PseudoMetrizableSpace (Fin d → Fin d → ℝ))
  apply isCompact_iff_isSeqCompact.mpr
  intro A ha
  choose g hg e using ha
  let Z := fun n => weightMeasure (P : Measure X) (g n)
  obtain ⟨η,sub,φ,mono,lim⟩ := dominated_subsequence P Z (fun n => weightMeasure_le (hg n))
  obtain ⟨w,hw,wint⟩ := density_of_submeasure sub
  have sz (n) : (Z n).real univ =u := weightMeasure_mass (hg n)
  have m := lim (fun _ => (1:ℝ)) (integrable_const _)
  simp only [integral_const,smul_eq_mul,mul_one,sz] at m
  have eu : η.real univ = u := tendsto_nhds_unique m tendsto_const_nhds
  refine ⟨weightedMoment _ w F,⟨w,eu ▸ hw,rfl⟩,φ,mono,?_⟩
  apply tendsto_pi_nhds.mpr; intro i; apply tendsto_pi_nhds.mpr; intro j
  have v := lim (fun x => F i x*F j x) ((hF i).integrable_mul (hF j))
  rw [←wint] at v
  simpa only [Function.comp_apply,e,weightedMoment, Z,weightMeasure_integral (hg _)] using v

end
end Residual
