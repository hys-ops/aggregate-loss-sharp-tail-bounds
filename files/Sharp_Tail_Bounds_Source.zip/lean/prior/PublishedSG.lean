import PatchTheorem
import DiskRearrangement

open MeasureTheory Set
open scoped ENNReal
namespace Vortex
noncomputable section

def circular (E0 : Set Space) : Set Space :=
  {y | areaCoord y.1 ≤ volume.real (slice E0 y.2)}
theorem circular_slice (E0 : Set Space) (z : ℝ) :
    slice (circular E0) z = disk (volume.real (slice E0 z)) := rfl

private theorem disk_finite (a : ℝ) : volume (disk a) ≠ ∞ := by
  rw [disk,disk_area]; exact ENNReal.ofReal_ne_top

private theorem disk_real (a : ℝ) (ha : 0 ≤ a) : volume.real (disk a) = a := by
  simp [Measure.real,disk,disk_area,ENNReal.toReal_ofReal ha]

private theorem disk_integrable (a : ℝ) : IntegrableOn areaCoord (disk a) := by
  have hc : IntegrableOn (fun _ : H => |a|) (disk a) := integrableOn_const (disk_finite a)
  apply hc.mono' areaCoord_meas.aestronglyMeasurable
  filter_upwards [ae_restrict_mem (areaCoord_meas measurableSet_Iic : MeasurableSet (disk a))] with x hx
  have hp : 0 ≤ areaCoord x := by unfold areaCoord; positivity
  simpa [Real.norm_eq_abs,abs_of_nonneg hp] using (show areaCoord x ≤ |a| from
    (show areaCoord x ≤ a from hx).trans (le_abs_self a))

/-- The PDE and optimal-transport interface. The disk rearrangement, Fubini,
Cauchy-Schwarz, patch identities, and final inequalities are not fields. -/
structure PatchInputs (E0 E : Set Space) (ρ a b : ℝ) (U V : Space → H) : Prop where
  measurableE : MeasurableSet E
  measurableInitial : MeasurableSet E0
  l1 : Integrable (fun y => |patch E ρ y-patch (circular E0) ρ y|)
  sliceLaw : ∀ᵐ z : ℝ, volume (slice E z) ≠ ∞ ∧
    volume (slice E z) = volume (slice E0 z) ∧ IntegrableOn areaCoord (slice E z)
  initialSlab : ∀ᵐ z : ℝ, z ∉ Icc a b → volume (slice E0 z) = 0
  impulseInt : Integrable (fun y : Space => (y.1.1^2+y.1.2^2)*(patch E ρ y-patch (circular E0) ρ y))
  conservedImpulse : impulse E (circular E0) ρ = impulse E0 (circular E0) ρ
  ovInt : Integrable (overlap E (circular E0) ρ Prod.fst U V)
  fluxInt : Integrable (fun y => flux (patch E ρ y) (patch (circular E0) ρ y) (U y) (V y))

structure PhysicalInputs (E0 E : Set Space) (ρ R a b : ℝ) (U V : Space → H) : Prop
    extends PatchInputs E0 E ρ a b U V where
  endpoint : (∫ y, flux (patch E ρ y) (patch (circular E0) ρ y) (U y) (V y)) ≤
    R^2*∫ y, (patch E ρ y-patch (circular E0) ρ y)^2/(patch E ρ y+patch (circular E0) ρ y)

theorem physical_to_time {E0 E : Set Space} {ρ R a b : ℝ} {U V : Space → H}
    (hρ : 0 < ρ) (p : PhysicalInputs E0 E ρ R a b U V) :
    TimeInputs E0 E (circular E0) ρ R a b U V := by
  have ms (A : Set Space) (hA : MeasurableSet A) :
      Measurable (fun z => volume.real (slice A z)) :=
    ENNReal.measurable_toReal.comp (measurable_measure_prodMk_right hA)
  have mB : MeasurableSet (circular E0) :=
    measurableSet_le (areaCoord_meas.comp measurable_fst) ((ms E0 p.measurableInitial).comp measurable_snd)
  have md : Measurable (exchanged E (circular E0)) := ms _ (p.measurableE.diff mB)
  have sliceeq (z : ℝ) : volume.real (slice (circular E0) z) = volume.real (slice E0 z) := by
    rw [circular_slice]
    exact disk_real (volume.real (slice E0 z)) ENNReal.toReal_nonneg
  have sb (z : ℝ) : volume (slice (circular E0) z) ≠ ∞ := by rw [circular_slice]; exact disk_finite _
  have nulls : ∀ᵐ z : ℝ, z ∉ Icc a b → volume (slice E z) = 0 ∧
      volume (slice (circular E0) z) = 0 := by
    filter_upwards [p.sliceLaw,p.initialSlab] with z hz hz0
    intro hout
    have ze : volume.real (slice E z) = 0 := by simp [Measure.real,hz.2.1,hz0 hout]
    have zb : volume.real (slice (circular E0) z) = 0 := by rw [sliceeq z]; simp [Measure.real,hz0 hout]
    exact ⟨(ENNReal.toReal_eq_zero_iff _).mp ze |>.resolve_right hz.1,
      (ENNReal.toReal_eq_zero_iff _).mp zb |>.resolve_right (sb z)⟩
  have rearr : ∀ᵐ z ∂volume.restrict (Icc a b),
      (ρ/Real.pi)*(exchanged E (circular E0) z)^2 ≤ sliceImpulse ρ E (circular E0) z := by
    filter_upwards [ae_restrict_of_ae p.sliceLaw] with z hz
    apply disk_rearrange ρ (volume.real (slice E0 z)) hρ (slice E z)
      (p.measurableE.preimage (measurable_id.prodMk measurable_const))
      hz.1 hz.2.2 (disk_integrable _)
    rw [← circular_slice,sliceeq]
    exact congrArg ENNReal.toReal hz.2.1
  have hi : Integrable (sliceImpulse ρ E (circular E0)) volume :=
    p.impulseInt.integral_prod_right
  have hc : 0 < ρ/Real.pi := div_pos hρ Real.pi_pos
  have d2 : IntegrableOn (fun z => (exchanged E (circular E0) z)^2) (Icc a b) := by
    apply (hi.integrableOn.div_const (ρ/Real.pi)).mono' (md.pow_const 2).aestronglyMeasurable
    filter_upwards [rearr] with z hz
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    exact (le_div_iff₀ hc).mpr (by simpa only [mul_comm] using hz)
  have d1 : IntegrableOn (exchanged E (circular E0)) (Icc a b) := by
    have c1 : IntegrableOn (fun _ : ℝ => (1:ℝ)) (Icc a b) :=
      integrableOn_const (by simp)
    apply (c1.add d2).mono' md.aestronglyMeasurable
    filter_upwards with z
    rw [Real.norm_eq_abs,abs_of_nonneg (show 0 ≤ exchanged E (circular E0) z from ENNReal.toReal_nonneg)]
    change exchanged E (circular E0) z ≤ 1+(exchanged E (circular E0) z)^2
    nlinarith only [sq_nonneg (exchanged E (circular E0) z-1/2)]
  refine ⟨p.measurableE,mB,p.l1,?_,?_,?_,p.impulseInt,p.conservedImpulse,
    d1,d2,rearr,p.ovInt,p.fluxInt,p.endpoint⟩
  · filter_upwards [p.sliceLaw] with z hz
    exact ⟨hz.1,sb z,(congrArg ENNReal.toReal hz.2.1).trans (sliceeq z).symm⟩
  · filter_upwards [nulls] with z hz
    intro hout
    unfold exchanged Measure.real
    rw [measure_mono_null sdiff_subset (hz hout).1,ENNReal.toReal_zero]
  · filter_upwards [nulls] with z hz
    intro hout
    have ke := (ae_iff.mpr (by simpa using (hz hout).1) : ∀ᵐ x : H, x ∉ slice E z)
    have kb := (ae_iff.mpr (by simpa using (hz hout).2) : ∀ᵐ x : H, x ∉ slice (circular E0) z)
    unfold sliceImpulse
    apply integral_eq_zero_of_ae
    filter_upwards [ke,kb] with x he hb
    change (x.1^2+x.2^2)*(patch (slice E z) ρ x-patch (slice (circular E0) z) ρ x) = 0
    simp [patch,he,hb]
/-- Direct transcription of the published inequality, conditional on the
explicit conservation, map estimate and integrability interface above. -/
theorem published_overlap (times : Set ℝ) (E0 : Set Space)
    (E : ℝ → Set Space) (U : ℝ → Space → H) (V : Space → H) (ρ R a b : ℝ)
    (hρ : 0 < ρ) (hab : a ≤ b)
    (h : ∀ᵐ t ∂volume.restrict times, PhysicalInputs E0 (E t) ρ R a b (U t) V) :
    ∀ᵐ t ∂volume.restrict times,
      ρ*(∫ y in E t ∩ circular E0, distSq (vel y.1 (U t y)) (vel y.1 (V y))) ≤
      4*R^2*Real.sqrt (Real.pi*ρ*(b-a)*impulse E0 (circular E0) ρ) :=
  almost_every_time times E0 (circular E0) E U V ρ R a b hρ hab
    (h.mono fun _ ht => physical_to_time hρ ht)

/-- A horizontal rotation produces A cos θ + B sin θ up to an additive
constant. A maximizing angle zero forces the torque coefficient to vanish. -/
theorem zero_torque (A B : ℝ)
    (optimal : ∀ t : ℝ, A*Real.cos t+B*Real.sin t ≤ A) : B = 0 := by
  have hm : IsLocalMax (fun t : ℝ => A*Real.cos t+B*Real.sin t) 0 :=
    Filter.Eventually.of_forall (fun t => by simpa using optimal t)
  have hd := ((Real.hasDerivAt_cos (0:ℝ)).const_mul A).add ((Real.hasDerivAt_sin 0).const_mul B)
  simpa using hm.hasDerivAt_eq_zero hd
end
end Vortex
