import FinanceReduced
open MeasureTheory Set Finset
open scoped NNReal ENNReal BigOperators
noncomputable section
namespace Finance
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

private theorem subsum {α M : Type*} [Fintype α] [AddCommMonoid M] (P : α → Prop) [DecidablePred P]
    (f : α → M) : ∑ a : Subtype P,f a.val = ∑ a, if P a then f a else 0 := by
  classical
  rw [← Finset.sum_filter]
  exact (Finset.sum_subtype _ (fun a => by simp) f).symm

private theorem singleton_sum {M : Type*} [AddCommMonoid M] (v : Finset ι → M) :
    (∑ i : ι, v {i}) = ∑ A : Finset ι, if A.card = 1 then v A else 0 := by
  classical
  have inner (A : Finset ι) : (∑ i : ι, if ({i}:Finset ι) = A then v A else 0) =
      if A.card = 1 then v A else 0 := by
    by_cases h : A.card = 1
    · obtain ⟨i,rfl⟩ := card_eq_one.mp h
      simp
    · have n (i : ι) : ({i}:Finset ι) ≠ A := fun he => h (he ▸ Finset.card_singleton i)
      simp [h,n]
  simp_rw [← inner]
  rw [sum_comm]; simp

private theorem marked_part {P : Finset ι → Prop} [DecidablePred P]
    (m : Finset ι → FiniteMeasure (Losses ι)) (i : ι) (s : Set ℝ≥0) :
    used (fun g : Subtype P => g.val) (fun g => m g.val) i s =
    ∑ A : Finset ι, if P A ∧ i ∈ A then ((m A : Measure (Losses ι)).map (Function.eval i)) s else 0 := by
  classical
  rw [used,Measure.finsetSum_apply]
  trans ∑ g : Subtype P, (if i ∈ g.val then ((m g.val : Measure (Losses ι)).map (Function.eval i)) s else 0)
  · apply sum_congr rfl; intro g _; by_cases h : i ∈ g.val <;> simp [h]
  rw [subsum P (fun A => if i ∈ A then ((m A : Measure (Losses ι)).map (Function.eval i)) s else 0)]
  apply sum_congr rfl; intro A _; by_cases hp : P A <;> by_cases hi : i ∈ A <;> simp [hp,hi]

/-- Disjoint successful configurations of size at least two share one subthreshold budget. -/
private theorem common_budget (μ : ι → Measure ℝ≥0) (d : ℝ≥0) {k : ℕ} (hk : 2 ≤ k)
    (m : Finset ι → FiniteMeasure (Losses ι)) (res : Reserved μ d k m) (i : ι) :
    used (fun g : SmallGroup ι k => g.val) (fun g => m g.val) i +
    used (fun g : {A : Finset ι // A.card = k} => g.val) (fun g => m g.val) i ≤ subLoss μ d i := by
  classical
  apply Measure.le_iff.mpr
  intro s hs
  let U := Ioo 0 d
  let val (A : Finset ι) (t : Set ℝ≥0) := (m A : Measure (Losses ι)).map (Function.eval i) t
  have inU (A : Finset ι) (hi : i ∈ A) (hA : 2 ≤ A.card) :
      val A s = val A (s ∩ U) := by
    have h : ∀ᵐ x ∂(m A : Measure (Losses ι)), x i ∈ U := (res.1 A).mono fun x hw => by
      obtain ⟨hp,hl⟩ := hw.2.2.1 i hi
      exact ⟨by exact_mod_cast hp,by exact_mod_cast hl hA⟩
    have h' : ∀ᵐ t ∂(m A : Measure (Losses ι)).map (Function.eval i),t ∈ U :=
      (ae_map_iff (measurable_pi_apply i).aemeasurable measurableSet_Ioo).mpr h
    exact (congrArg (fun q : Measure ℝ≥0 => q s) (Measure.restrict_eq_self_of_ae_mem h')).symm.trans
      (Measure.restrict_apply hs)
  rw [Measure.add_apply,marked_part,marked_part,← sum_add_distrib]
  have r := (res.2 i) (s ∩ U)
  rw [Measure.finsetSum_apply] at r
  change _ ≤ (μ i).restrict U s
  rw [Measure.restrict_apply hs]
  apply le_trans _ r
  apply sum_le_sum
  intro A _
  by_cases hi : i ∈ A
  · by_cases sm : 2 ≤ A.card ∧ A.card < k
    · have neq := sm.2.ne
      simp only [sm,hi,neq,and_true,↓reduceIte,add_zero]
      exact (inU A hi sm.1).le
    · by_cases eq : A.card = k
      · simp [eq,hi]
        exact (inU A hi (eq ▸ hk)).le
      · simp [sm,eq,hi]
  · simp [hi]

private theorem one_bound (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)] (d : ℝ≥0) {k : ℕ}
    (m : Finset ι → FiniteMeasure (Losses ι)) (res : Reserved μ d k m) (i : ι) :
    (m {i}).mass ≤ ((μ i) (Ici d)).toNNReal := by
  classical
  have hu := (res.2 i) (Ici d)
  rw [Measure.finsetSum_apply] at hu
  have one : (m {i} : Measure (Losses ι)).map (Function.eval i) (Ici d) ≤ (μ i) (Ici d) := by
    apply le_trans _ hu
    have h := single_le_sum (s:=univ) (f:=fun A : Finset ι => (if i ∈ A then (m A : Measure (Losses ι)).map (Function.eval i) else 0) (Ici d))
      (fun _ _ => zero_le) (mem_univ {i})
    simpa only [mem_singleton_self,↓reduceIte] using h
  have h : ∀ᵐ x ∂(m {i} : Measure (Losses ι)), d ≤ x i := (res.1 {i}).mono fun x hw => by
    have h' := hw.2.2.2
    simpa using h'
  have eq := measure_congr (show (Function.eval i ⁻¹' Ici d : Set (Losses ι)) =ᵐ[(m {i} : Measure (Losses ι))] Set.univ from
    h.mono fun x hx => propext ⟨fun _ => trivial,fun _ => hx⟩)
  rw [Measure.map_apply (measurable_pi_apply i) measurableSet_Ici,eq] at one
  exact_mod_cast (show ((m {i}).mass:ℝ≥0∞) ≤ ((((μ i) (Ici d)).toNNReal:ℝ≥0):ℝ≥0∞) by
    rw [FiniteMeasure.ennreal_mass,ENNReal.coe_toNNReal (measure_ne_top _ _)]; exact one)

theorem reduced_upper (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)] (d : ℝ≥0)
    (hd : 0 < d) (k : ℕ) (hk : 2 ≤ k) (ck : Covers μ d k)
    (γ : ProbabilityMeasure (Losses ι)) (marg : Marginals μ γ) :
    ∃ b : Marked ι k, admissible μ d b ∧
      (γ : Measure (Losses ι)) (Tail d) ≤ ((min 1 (reducedMass μ d (by omega : 0<k) b):ℝ≥0):ℝ≥0∞) := by
  classical
  obtain ⟨m,hit,use,eq⟩ := extract_reserves μ γ marg d hd k (by omega) ck
  have res : Reserved μ d k m := ⟨hit,use⟩
  let b : Marked ι k := fun g => m g.val
  let K := {A : Finset ι // A.card = k}
  let uK (i : ι) := used (fun g : K => g.val) (fun g => m g.val) i
  let δ := residual μ d b
  have budget (i) : used Subtype.val b i + uK i ≤ subLoss μ d i := common_budget μ d hk m res i
  have hb : admissible μ d b := ⟨fun g => (hit g.val).mono (fun x h => by
    exact_mod_cast (show (d:ℝ) ≤ ∑ i ∈ g.val,(x i:ℝ) from h.2.2.2)),
    fun i => (Measure.le_add_right le_rfl).trans (budget i)⟩
  have cap (i : ι) : (∑ g : K, if i ∈ g.val then ((m g.val).mass:ℝ) else 0) ≤ ((δ i).mass:ℝ) := by
    let u := used Subtype.val b i
    have : IsFiniteMeasure u := by
      have : IsFiniteMeasure (subLoss μ d i) := by unfold subLoss; infer_instance
      exact isFiniteMeasure_of_le _ (hb.2 i)
    have plus : u + (δ i : Measure ℝ≥0) = subLoss μ d i := by rw [add_comm]; exact Measure.sub_add_cancel_of_le (hb.2 i)
    have h := budget i univ
    rw [← plus,Measure.add_apply,Measure.add_apply] at h
    have ufin := measure_ne_top u univ
    have hkLe : uK i univ ≤ ((δ i).mass:ℝ≥0∞) := by
      rw [FiniteMeasure.ennreal_mass]
      exact (ENNReal.add_le_add_iff_left ufin).mp h
    have kt : ∑ g : K, ((if i ∈ g.val then (m g.val).mass else 0 : ℝ≥0):ℝ≥0∞) = uK i univ := by
      rw [show uK i = used (fun g : K => g.val) (fun g => m g.val) i from rfl,used,Measure.finsetSum_apply]
      apply sum_congr rfl; intro g _
      by_cases hi : i ∈ g.val
      · simp [hi,Measure.map_apply (measurable_pi_apply i),FiniteMeasure.ennreal_mass]
      · simp [hi]
    rw [← kt,← ENNReal.ofNNReal_finsetSum] at hkLe
    have nn : (∑ g : K, if i ∈ g.val then (m g.val).mass else 0) ≤ (δ i).mass := by exact_mod_cast hkLe
    have real := NNReal.coe_le_coe.mpr nn
    push_cast at real
    have cast (g : K) : ((if i ∈ g.val then (m g.val).mass else 0 : ℝ≥0):ℝ) = if i ∈ g.val then ((m g.val).mass:ℝ) else 0 := by split_ifs <;> rfl
    simpa only [cast] using real
  have count := group_upper (fun g : K => g.val) k (by omega) (fun g => g.property)
    (fun g => ((m g.val).mass:ℝ)) (fun g => (m g.val).mass.property)
    (fun i => ((δ i).mass:ℝ)) (fun i => (δ i).mass.property) cap
  have kn : (∑ g : K,(m g.val).mass) ≤ (jointCapacity (fun i => ((δ i).mass:ℝ)) k (by omega)).toNNReal := by
    apply NNReal.coe_le_coe.mp
    rw [NNReal.coe_sum,Real.coe_toNNReal _ (capacity_nonneg (fun i => ((δ i).mass:ℝ)) (by omega : 0 < k) fun i => (δ i).mass.property)]
    exact count
  have tot : ∑ A,(m A).mass ≤ (∑ i,(m {i}).mass) + (∑ g : SmallGroup ι k,(m g.val).mass) +
      ∑ g : K,(m g.val).mass := by
    rw [singleton_sum (fun A => (m A).mass),subsum (fun A : Finset ι => 2 ≤ A.card ∧ A.card < k) (fun A => (m A).mass),
      subsum (fun A : Finset ι => A.card=k) (fun A => (m A).mass),← sum_add_distrib,← sum_add_distrib]
    apply sum_le_sum; intro A _
    by_cases h1 : A.card = 1
    · simp [h1,show 1 ≠ k by omega]
    by_cases h2 : 2 ≤ A.card ∧ A.card < k
    · simp [h1,h2,h2.2.ne]
    by_cases h3 : A.card = k
    · simp [h3]
    have z : (m A : Measure (Losses ι)) univ = 0 := by
      have hfalse : ∀ᵐ x ∂(m A : Measure (Losses ι)), False := (hit A).mono fun x h => by
        have p := card_pos.mpr h.1; have u := h.2.1; omega
      simpa [ae_iff] using hfalse
    have zm : (m A).mass = 0 := by
      apply ENNReal.coe_injective; rw [FiniteMeasure.ennreal_mass,z]; rfl
    simp [zm]
  have le : ∑ A,(m A).mass ≤ reducedMass μ d (by omega) b :=
    tot.trans (add_le_add (add_le_add (sum_le_sum fun i _ => one_bound μ d m res i) le_rfl) kn)
  refine ⟨b,hb,?_⟩
  have eq' : ((∑ A,(m A).mass : ℝ≥0):ℝ≥0∞) = (γ : Measure (Losses ι)) (Tail d) := by rw [ENNReal.ofNNReal_finsetSum]; exact eq
  rcases le_total (reducedMass μ d (by omega) b) 1 with h|h
  · rw [min_eq_right h,← eq']; exact_mod_cast le
  · rw [min_eq_left h]; exact prob_le_one
end Finance
