import FinanceUpper
import FinanceCoordinates
open MeasureTheory Set Finset
open scoped NNReal ENNReal BigOperators
noncomputable section
namespace Finance
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The printed smaller-group feasibility constraint, on the closed success carrier. -/
def feasible (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)] {d : ℝ≥0} {k : ℕ}
    (π : SmallPlan ι d k) : Prop :=
  ∀ i, (smallUse π i : Measure (Severity d)) ≤ subCube μ d i

def projectedScore (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)] {d : ℝ≥0} {k : ℕ}
    (hk : 0 < k) (π : SmallPlan ι d k) : ℝ :=
  (∑ g,((π g).mass:ℝ)) + jointCapacity
    (fun i => ((subCube μ d i).mass:ℝ) - ((smallUse π i).mass:ℝ)) k hk

def highTotal (μ : ι → Measure ℝ≥0) (d : ℝ≥0) : ℝ := ∑ i, (μ i).real (Ici d)

private theorem mass_real {X : Type*} [MeasurableSpace X] (m : FiniteMeasure X) :
    (m.mass:ℝ) = (m : Measure X).real univ := by
  rw [Measure.real,← FiniteMeasure.ennreal_mass,ENNReal.coe_toReal]

private theorem map_total {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    (m : Measure X) (f : X → Y) (hf : Measurable f) :
    (m.map f).real univ = m.real univ := by simp [Measure.real,Measure.map_apply hf]

private theorem residual_total (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)]
    {d : ℝ≥0} {k : ℕ} (b : Marked ι k) (hb : admissible μ d b) (i : ι) :
    ((residual μ d b i).mass:ℝ) = (subLoss μ d i).real univ - (used Subtype.val b i).real univ := by
  have : IsFiniteMeasure (subLoss μ d i) := by unfold subLoss; infer_instance
  have : IsFiniteMeasure (used Subtype.val b i) := isFiniteMeasure_of_le _ (hb.2 i)
  rw [mass_real,Measure.real]
  change ((subLoss μ d i - used Subtype.val b i) univ).toReal = _
  rw [Measure.sub_apply MeasurableSet.univ (hb.2 i),ENNReal.toReal_sub_of_le (hb.2 i univ) (measure_ne_top _ _)]
  rfl

private theorem score_transport (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)]
    {d : ℝ≥0} {k : ℕ} (hk : 0 < k) (π : SmallPlan ι d k) (b : Marked ι k) (hb : admissible μ d b)
    (mass : ∀ g, (b g).mass = (π g).mass)
    (usedMass : ∀ i, (used Subtype.val b i).real univ = ((smallUse π i).mass:ℝ)) :
    (reducedMass μ d hk b : ℝ) = highTotal μ d + projectedScore μ hk π := by
  have base (i : ι) : ((subCube μ d i).mass:ℝ) = (subLoss μ d i).real univ := by
    rw [mass_real]
    exact map_total _ _ (clipM d)
  have eq (i : ι) : ((residual μ d b i).mass:ℝ) =
      ((subCube μ d i).mass:ℝ) - ((smallUse π i).mass:ℝ) := by
    rw [residual_total μ b hb,usedMass,base]
  unfold reducedMass projectedScore highTotal
  push_cast
  rw [Real.coe_toNNReal _ (capacity_nonneg (fun i => ((residual μ d b i).mass:ℝ)) hk fun i => (residual μ d b i).mass.property)]
  simp_rw [eq,mass]
  simp [Measure.real,add_assoc]

private theorem lift_score (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)]
    {d : ℝ≥0} {k : ℕ} (hk : 0 < k) (π : SmallPlan ι d k) (hπ : feasible μ π) :
    (reducedMass μ d hk (liftPlan π):ℝ) = highTotal μ d + projectedScore μ hk π :=
  score_transport μ hk π _ (lift_admissible μ π hπ)
    (fun g => map_mass_eq _ _ (embedM d g.val)) (fun i => by
      rw [lift_use,map_total _ _ measurable_subtype_coe,← mass_real])

private theorem compact_score (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)]
    {d : ℝ≥0} {k : ℕ} (hk : 0 < k) (b : Marked ι k) (hb : admissible μ d b) :
    (reducedMass μ d hk b : ℝ) = highTotal μ d + projectedScore μ hk (compactPlan d b) :=
  score_transport μ hk _ b hb (fun g => (map_mass_eq _ _ (toBlockM d g)).symm) (fun i => by
    rw [mass_real,compact_use μ d b hb,map_total _ _ (clipM d)])

private theorem cap_cast (a : ℝ≥0) :
    ((min 1 a:ℝ≥0):ℝ≥0∞) = ENNReal.ofReal (min 1 (a:ℝ)) := by
  rcases le_total a 1 with h|h
  · rw [min_eq_right h,min_eq_right (by exact_mod_cast h : (a:ℝ) ≤ 1)]
    simp
  · rw [min_eq_left h,min_eq_left (by exact_mod_cast h : 1 ≤ (a:ℝ))]
    simp

/-- Theorem 1. Under (C_k), for arbitrary Borel probability marginals on [0,∞),
a maximizing smaller-group allocation and a joint law attaining W(d) exist, and
W(d) is exactly the clipped sum of H, P and the residual group capacity. -/
theorem sharp_tail (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)]
    (d : ℝ≥0) (hd : 0 < d) (k : ℕ) (hk : 2 ≤ k) (hn : k ≤ Fintype.card ι) (ck : Covers μ d k) :
    ∃ π : SmallPlan ι d k, feasible μ π ∧
      (∀ π' : SmallPlan ι d k, feasible μ π' →
        projectedScore μ (by omega : 0 < k) π' ≤ projectedScore μ (by omega : 0 < k) π) ∧
      ∃ γ : ProbabilityMeasure (Losses ι), Marginals μ γ ∧
        (γ : Measure (Losses ι)) (Tail d) = worst μ d ∧
        worst μ d = ENNReal.ofReal (min 1 (highTotal μ d + projectedScore μ (by omega : 0 < k) π)) := by
  classical
  have hk0 : 0 < k := by omega
  have hν (i : ι) : (subCube μ d i).mass ≤ 1 := by
    apply ENNReal.coe_le_coe.mp
    rw [FiniteMeasure.ennreal_mass]
    change (subLoss μ d i).map (clipScore d) univ ≤ _
    rw [Measure.map_apply (clipM d) MeasurableSet.univ]
    exact (Measure.restrict_le_self _).trans prob_le_one
  obtain ⟨π,hπ,maxπ⟩ := small_allocation_max d k hk0 (subCube μ d) hν
  change feasible μ π at hπ
  change ∀ π', feasible μ π' → projectedScore μ hk0 π' ≤ projectedScore μ hk0 π at maxπ
  obtain ⟨γ,hγ,opt⟩ := worst_attained μ d
  refine ⟨π,hπ,maxπ,γ,hγ,opt,le_antisymm ?_ ?_⟩
  · obtain ⟨b,hb,ub⟩ := reduced_upper μ d hd k hk ck γ hγ
    have hf : feasible μ (compactPlan d b) := fun i => by
      rw [compact_use μ d b hb]
      exact Measure.map_mono (hb.2 i) (clipM d)
    rw [opt,cap_cast,compact_score μ hk0 b hb] at ub
    exact ub.trans (ENNReal.ofReal_le_ofReal (min_le_min_left 1 (add_le_add_right (maxπ _ hf) _)))
  · obtain ⟨K,_,sz⟩ := exists_subset_card_eq (s:=univ) (by simpa using hn)
    obtain ⟨γ',hm,lb⟩ := reduced_attain_lower μ d K (sz ▸ hk0) (sz ▸ ck)
      (sz ▸ liftPlan π) (by subst k; exact lift_admissible μ π hπ)
    subst k
    rw [cap_cast,lift_score μ hk0 π hπ] at lb
    exact lb.trans (le_iSup_of_le γ' (le_iSup_of_le hm le_rfl))

/-- Equations (2) and (3) in a single statement. For each j < k, top j consists
of j names whose residual capacities dominate every name outside it. -/
theorem sharp_tail_sorted (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)]
    (d : ℝ≥0) (hd : 0 < d) (k : ℕ) (hk : 2 ≤ k) (hn : k ≤ Fintype.card ι) (ck : Covers μ d k) :
    ∃ (π : SmallPlan ι d k) (γ : ProbabilityMeasure (Losses ι)) (top : Fin k → Finset ι),
      let r := fun i => ((subCube μ d i).mass:ℝ) - ((smallUse π i).mass:ℝ)
      feasible μ π ∧ (∀ π' : SmallPlan ι d k, feasible μ π' → projectedScore μ (by omega : 0 < k) π' ≤
        projectedScore μ (by omega : 0 < k) π) ∧ Marginals μ γ ∧
      (γ : Measure (Losses ι)) (Tail d) = worst μ d ∧
      (∀ j, (top j).card = j.val ∧ ∀ i ∈ top j, ∀ l ∉ top j,r l ≤ r i) ∧
      worst μ d = ENNReal.ofReal (min 1 ((highTotal μ d + ∑ g, ((π g).mass:ℝ)) +
        (univ : Finset (Fin k)).inf' ⟨⟨0,by omega⟩,mem_univ _⟩
          (fun j => ((∑ i,r i) - ∑ i ∈ top j,r i)/((k:ℝ)-j.val)))) := by
  classical
  obtain ⟨π,hπ,hm,γ,hγ,opt,f⟩ := sharp_tail μ d hd k hk hn ck
  obtain ⟨top,ht,eq⟩ := sorted_capacity
    (fun i => ((subCube μ d i).mass:ℝ) - ((smallUse π i).mass:ℝ)) (by omega : 0 < k) hn
  refine ⟨π,γ,top,hπ,hm,hγ,opt,ht,?_⟩
  simpa only [projectedScore,eq,add_assoc] using f

end Finance
