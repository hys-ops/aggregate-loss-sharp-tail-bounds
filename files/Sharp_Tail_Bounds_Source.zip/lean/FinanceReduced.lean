import FinanceTail
import FinanceSeverity
import FinanceGroups
open MeasureTheory Set Finset
open scoped NNReal ENNReal BigOperators
noncomputable section
namespace Finance
variable {ι : Type*} [Fintype ι] [DecidableEq ι]
abbrev Marked (ι : Type*) [Fintype ι] (k : ℕ) := SmallGroup ι k → FiniteMeasure (Losses ι)

def used {G : Type*} [Fintype G] (I : G → Finset ι) (m : G → FiniteMeasure (Losses ι)) (i : ι) : Measure ℝ≥0 :=
  ∑ g, if i ∈ I g then (m g : Measure (Losses ι)).map (Function.eval i) else 0

def subLoss (μ : ι → Measure ℝ≥0) (d : ℝ≥0) (i : ι) := (μ i).restrict (Ioo 0 d)
def highLoss (μ : ι → Measure ℝ≥0) (d : ℝ≥0) (i : ι) := (μ i).restrict (Ici d)

def admissible (μ : ι → Measure ℝ≥0) (d : ℝ≥0) {k : ℕ} (b : Marked ι k) : Prop :=
  (∀ g, ∀ᵐ x ∂(b g : Measure (Losses ι)), d ≤ ∑ i ∈ g.val, x i) ∧
  ∀ i, used Subtype.val b i ≤ subLoss μ d i

def residual (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)] (d : ℝ≥0) {k : ℕ}
    (b : Marked ι k) (i : ι) : FiniteMeasure ℝ≥0 :=
  ⟨subLoss μ d i - used Subtype.val b i,by unfold subLoss; infer_instance⟩

def reducedMass (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)] (d : ℝ≥0)
    {k : ℕ} (hk : 0 < k) (b : Marked ι k) : ℝ≥0 :=
  (∑ i, ((μ i) (Ici d)).toNNReal) + (∑ g,(b g).mass) +
    (jointCapacity (fun i => ((residual μ d b i).mass:ℝ)) k hk).toNNReal

omit [Fintype ι] in
private theorem used_sum {G H : Type*} [Fintype G] [Fintype H] (I : G → Finset ι)
    (J : H → Finset ι) (m : G → FiniteMeasure (Losses ι)) (b : H → FiniteMeasure (Losses ι)) (i) :
    used (Sum.elim I J) (Sum.elim m b) i = used I m i + used J b i := by
  classical
  simp [used,Fintype.sum_sum_type]
  congr 1

/-- Full lower bound for the printed allocation objective, including arbitrary Borel severities,
competition for a common residual and clipping the sum of block masses at one. -/
theorem reduced_attain_lower (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)] (d : ℝ≥0)
    (K : Finset ι) (hk : 0 < K.card) (ck : Covers μ d K.card)
    (b : Marked ι K.card) (hb : admissible μ d b) :
    ∃ γ : ProbabilityMeasure (Losses ι), Marginals μ γ ∧
      ((min 1 (reducedMass μ d hk b):ℝ≥0):ℝ≥0∞) ≤ (γ : Measure (Losses ι)) (Tail d) := by
  classical
  obtain ⟨S,hS,hck⟩ := ck
  let δ := residual μ d b
  have leSub (i) : (δ i : Measure ℝ≥0) ≤ subLoss μ d i := Measure.sub_le
  have aeδ (i) : ∀ᵐ a ∂(δ i : Measure ℝ≥0), a ∈ S i ∩ Ioo 0 d := by
    have h : ∀ᵐ a ∂μ i,a ∈ S i := (mem_ae_iff_prob_eq_one (hS i).1).mpr (hS i).2
    have hs : ∀ᵐ a ∂subLoss μ d i,a ∈ S i := ae_restrict_of_ae h
    exact (ae_mono (leSub i)) (hs.and (ae_restrict_mem measurableSet_Ioo))
  obtain ⟨m,hm,hgood,huse⟩ := severity_groups K hk δ _ aeδ d
    (fun A h x hmem => hck A h x (fun i hi => hmem i hi))
  let dup (t : ℝ≥0) : Losses ι := fun _ => t
  have dupM : Measurable dup := Measurable.of_eval (fun _ => measurable_id)
  let high (i : ι) : FiniteMeasure (Losses ι) := ⟨(highLoss μ d i).map dup,by unfold highLoss; infer_instance⟩
  have proj (i j : ι) : (high i : Measure (Losses ι)).map (Function.eval j) = highLoss μ d i := by
    change ((highLoss μ d i).map dup).map _ = _
    rw [Measure.map_map (measurable_pi_apply j) dupM]; exact Measure.map_id
  have highUse (i) : used (fun j => {j}) high i = highLoss μ d i := by
    simp [used,proj]
  let I : ι ⊕ (SmallGroup ι K.card ⊕ Equiv.Perm ι) → Finset ι :=
    Sum.elim (fun i => {i}) (Sum.elim Subtype.val (groupOf K))
  let allM : ι ⊕ (SmallGroup ι K.card ⊕ Equiv.Perm ι) → FiniteMeasure (Losses ι) :=
    Sum.elim high (Sum.elim b m)
  have u (i) : used I allM i ≤ μ i := by
    have hfin : IsFiniteMeasure (used Subtype.val b i) := by
      have : IsFiniteMeasure (subLoss μ d i) := by unfold subLoss; infer_instance
      exact isFiniteMeasure_of_le _ (hb.2 i)
    dsimp only [I,allM]
    rw [used_sum,used_sum,highUse]
    calc
      _ ≤ highLoss μ d i + (used Subtype.val b i + (δ i : Measure ℝ≥0)) :=
        add_le_add le_rfl (add_le_add le_rfl (huse i))
      _ = highLoss μ d i + subLoss μ d i := by
        congr 1; rw [add_comm]; exact Measure.sub_add_cancel_of_le (hb.2 i)
      _ ≤ μ i := by
        unfold highLoss subLoss
        have hdis : Disjoint (Ici d) (Ioo 0 d) := Set.disjoint_left.mpr fun x hx hy => hy.2.not_ge hx
        rw [← Measure.restrict_union hdis measurableSet_Ioo]
        exact Measure.restrict_le_self
  have hits (g) : ∀ᵐ x ∂(allM g : Measure (Losses ι)), d ≤ ∑ i ∈ I g,x i := by
    rcases g with i|g
    · change ∀ᵐ x ∂(highLoss μ d i).map dup, d ≤ ∑ j ∈ ({i}:Finset ι),x j
      apply (ae_map_iff dupM.aemeasurable (measurableSet_le measurable_const
        (Finset.measurable_fun_sum _ fun i _ => measurable_pi_apply i))).2
      simpa [dup,highLoss] using (ae_restrict_mem (μ:=μ i) (s:=Ici d) measurableSet_Ici)
    · cases g with
      | inl a => exact hb.1 a
      | inr σ => exact hgood σ
  obtain ⟨γ,hγ,marg,t⟩ := realize_reserves I allM μ d u hits
  have highMass (i) : (high i).mass = ((μ i) (Ici d)).toNNReal := by
    apply ENNReal.coe_injective
    rw [FiniteMeasure.ennreal_mass,ENNReal.coe_toNNReal (measure_ne_top _ _)]
    change (highLoss μ d i).map dup univ = _
    simp [Measure.map_apply dupM,highLoss]
  have groupMass : (∑ σ,(m σ).mass) = (jointCapacity (fun i => ((δ i).mass:ℝ)) K.card hk).toNNReal := by
    rw [← hm, ← NNReal.coe_sum,Real.toNNReal_coe]
  refine ⟨⟨γ,hγ⟩,marg,?_⟩
  have total : ∑ g,(allM g).mass = reducedMass μ d hk b := by
    simp [allM,Fintype.sum_sum_type,highMass,reducedMass,← add_assoc,groupMass,δ]
  rwa [total] at t
end Finance
