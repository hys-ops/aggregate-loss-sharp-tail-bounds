import FinanceCompletion
import FinanceSelection
import Mathlib.MeasureTheory.Measure.Typeclasses.Finite
open MeasureTheory Set Finset
open scoped ENNReal NNReal BigOperators
noncomputable section
namespace Finance
variable {ι G : Type*} [Fintype ι] [DecidableEq ι] [Fintype G] [MeasurableSpace G]
    [MeasurableSingletonClass G]

/-- A mixture of marked scenarios, with a finite tag recording which names are assigned. -/
def tagged (w : G → ℝ≥0∞) (law : G → Measure (ι → ℝ≥0)) : Measure (G × (ι → ℝ≥0)) :=
  ∑ g, w g • (law g).map (Prod.mk g)

omit [Fintype ι] [DecidableEq ι] [MeasurableSingletonClass G] in
theorem tagged_apply (w : G → ℝ≥0∞) (law : G → Measure (ι → ℝ≥0))
    {s : Set (G × (ι → ℝ≥0))} (hs : MeasurableSet s) :
    tagged w law s = ∑ g, w g * law g (Prod.mk g ⁻¹' s) := by
  simp [tagged,Measure.finsetSum_apply,Measure.smul_apply,Measure.map_apply measurable_prodMk_left hs]

/-- Probability weights may include a dummy (nonreserved) group. This theorem produces
an actual joint law of the specified nonnegative Borel marginals. -/
theorem realize_blocks (w : G → ℝ≥0∞) (hw : ∑ g, w g = 1)
    (law : G → Measure (ι → ℝ≥0)) [∀ g, IsProbabilityMeasure (law g)]
    (I : G → Finset ι) (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)]
    (hu : ∀ i, (∑ g, if i ∈ I g then w g • (law g).map (Function.eval i) else 0) ≤ μ i)
    (good : Finset G) (d : ℝ≥0)
    (success : ∀ g ∈ good, w g ≠ 0 → ∀ᵐ x ∂law g, d ≤ ∑ i ∈ I g, x i) :
    ∃ γ : Measure (ι → ℝ≥0), IsProbabilityMeasure γ ∧
      (∀ i, γ.map (Function.eval i) = μ i) ∧
      (∑ g ∈ good, w g) ≤ γ {x | d ≤ ∑ i, x i} := by
  classical
  let p := tagged w law
  have hp : IsProbabilityMeasure p := ⟨by simpa [p,tagged_apply _ _ MeasurableSet.univ] using hw⟩
  let A (i : ι) : Set (G × (ι → ℝ≥0)) := Prod.fst ⁻¹' {g | i ∈ I g}
  have hA (i) : MeasurableSet (A i) := (Set.toFinite _).measurableSet.preimage measurable_fst
  let X (i : ι) (v : G × (ι → ℝ≥0)) := v.2 i
  have hX (i) : Measurable (X i) := (measurable_pi_apply i).comp measurable_snd
  have usage (i) : (p.restrict (A i)).map (X i) ≤ μ i := by
    apply le_trans _ (hu i)
    apply le_of_eq
    ext s hs
    rw [Measure.map_apply (hX i) hs,Measure.restrict_apply (hX i hs),
      tagged_apply w law ((hX i hs).inter (hA i)),Measure.finsetSum_apply]
    apply sum_congr rfl
    intro g _
    by_cases h : i ∈ I g
    · simp [h,Measure.smul_apply,Measure.map_apply (μ := law g) (measurable_pi_apply i) hs,
        show Prod.mk g ⁻¹' (X i ⁻¹' s ∩ A i) = Function.eval i ⁻¹' s by ext x; simp [X,A,h]]
    · simp [h,show Prod.mk g ⁻¹' (X i ⁻¹' s ∩ A i) = ∅ by ext x; simp [X,A,h]]
  obtain ⟨η,Y,hη,hY,marg,keep⟩ := complete_marginals p μ A hA X hX usage
  let γ := (p.prod η).map Y
  have hγ : IsProbabilityMeasure γ := by dsimp [γ]; infer_instance
  refine ⟨γ,hγ,fun i => ?_,?_⟩
  · rw [show γ = (p.prod η).map Y from rfl,Measure.map_map (measurable_pi_apply i) hY]
    exact marg i
  · let B : Set (G × (ι → ℝ≥0)) := {v | v.1 ∈ good ∧ d ≤ ∑ i ∈ I v.1, v.2 i}
    have Bu : B = ⋃ g : ↥good, ({g.val} ×ˢ {x : ι → ℝ≥0 | d ≤ ∑ i ∈ I g.val, x i}) := by
      ext ⟨g,x⟩
      simp only [B,Set.mem_ofPred_eq,Set.mem_iUnion,Set.mem_prod,Set.mem_singleton_iff]
      constructor
      · rintro ⟨hg,hx⟩; exact ⟨⟨g,hg⟩,rfl,hx⟩
      · rintro ⟨j,rfl,hj⟩; exact ⟨j.property,hj⟩
    have bmeas : MeasurableSet B := by
      rw [Bu]
      exact MeasurableSet.iUnion fun g => (measurableSet_singleton _).prod
        (measurableSet_le measurable_const (Finset.measurable_fun_sum _ fun i _ => measurable_pi_apply i))
    have hb : p B = ∑ g ∈ good,w g := by
      rw [tagged_apply w law bmeas]
      have each (g : G) : w g * law g (Prod.mk g ⁻¹' B) = if g ∈ good then w g else 0 := by
        by_cases hg : g ∈ good
        · by_cases hz : w g = 0
          · simp [hz]
          have ae : ∀ᵐ x ∂law g, x ∈ Prod.mk g ⁻¹' B := (success g hg hz).mono fun _ hx => ⟨hg,hx⟩
          have eq := (mem_ae_iff_prob_eq_one (μ := law g) (bmeas.preimage (show Measurable (Prod.mk g : (ι → ℝ≥0) → _) from measurable_prodMk_left))).mp ae
          simp [eq,hg]
        · simp [show Prod.mk g ⁻¹' B = ∅ by ext x; simp [B,hg],hg]
      simp_rw [each]
      simp
    have subset : B ×ˢ (univ : Set (ι → ℝ≥0)) ⊆ Y ⁻¹' {x | d ≤ ∑ i, x i} := by
      intro v hv
      have h := hv.1.2
      apply h.trans
      calc
        _ = ∑ i ∈ I v.1.1, Y v i := sum_congr rfl fun i hi => (keep v i hi).symm
        _ ≤ ∑ i, Y v i := sum_le_univ_sum_of_nonneg (fun _ => zero_le)
    rw [show γ = (p.prod η).map Y from rfl,Measure.map_apply hY
      (measurableSet_le measurable_const (Finset.measurable_fun_sum _ fun i _ => measurable_pi_apply i))]
    simpa [Measure.prod_prod,hb] using measure_mono (μ := p.prod η) subset
end Finance
