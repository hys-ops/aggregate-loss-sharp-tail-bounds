#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c prior.sha256
mapfile -t dependencies < <(sed -n 's/^import \(Mathlib\.[^ ]*\)$/\1/p' Finance*.lean prior/*.lean | sort -u)
lake exe cache get "${dependencies[@]}"
lake build PriorSelector
lake env python3 replay.py
