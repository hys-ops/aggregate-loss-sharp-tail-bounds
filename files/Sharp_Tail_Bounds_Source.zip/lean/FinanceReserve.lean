import FinanceBlocks
open MeasureTheory Set Finset
open scoped NNReal ENNReal BigOperators
noncomputable section
namespace Finance
variable {ι G : Type*} [Fintype ι] [DecidableEq ι] [Fintype G]

/-- Unnormalized reserved successful blocks may sum to more than one. The output is an
actual probability measure even in the saturation case or when every block is empty. -/
theorem realize_reserves (I : G → Finset ι) (m : G → FiniteMeasure (ι → ℝ≥0))
    (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)] (d : ℝ≥0)
    (use : ∀ i, (∑ g, if i ∈ I g then (m g : Measure (ι → ℝ≥0)).map (Function.eval i) else 0) ≤ μ i)
    (hits : ∀ g, ∀ᵐ x ∂(m g : Measure (ι → ℝ≥0)), d ≤ ∑ i ∈ I g, x i) :
    ∃ γ : Measure (ι → ℝ≥0), IsProbabilityMeasure γ ∧
      (∀ i, γ.map (Function.eval i) = μ i) ∧
      ((min 1 (∑ g,(m g).mass) : ℝ≥0) : ℝ≥0∞) ≤ γ {x | d ≤ ∑ i, x i} := by
  classical
  let Q : ℝ≥0 := ∑ g,(m g).mass
  let c : ℝ≥0 := (max 1 Q)⁻¹
  have hc : c ≤ 1 := by
    dsimp [c]; exact inv_le_one_of_one_le₀ (le_max_left _ _)
  have scaled : c*Q = min 1 Q := by
    by_cases h : Q ≤ 1
    · simp [c,max_eq_left h,min_eq_right h]
    · have hp : 0 < Q := lt_trans zero_lt_one (lt_of_not_ge h)
      simp [c,max_eq_right (le_of_not_ge h),min_eq_left (le_of_not_ge h),hp.ne']
  have bound : c*Q ≤ 1 := scaled ▸ min_le_left _ _
  let W : Option G → ℝ≥0 := fun tag => tag.elim (1-c*Q) (fun g => c*(m g).mass)
  let L : Option G → Measure (ι → ℝ≥0) := fun tag =>
    tag.elim (Measure.dirac 0) (fun g => ((m g).normalize : Measure _))
  let J : Option G → Finset ι := fun tag => tag.elim ∅ I
  let good : Finset (Option G) := univ.map (Function.Embedding.some)
  let _ : MeasurableSpace (Option G) := ⊤
  have (tag : Option G) : IsProbabilityMeasure (L tag) := by
    cases tag with
    | none => exact Measure.dirac.isProbabilityMeasure
    | some g => exact (m g).normalize.property
  have hw : ∑ a, (W a : ℝ≥0∞) = 1 := by
    norm_cast
    rw [Fintype.sum_option]
    change (1-c*Q) + ∑ g, c*(m g).mass = 1
    rw [← mul_sum]; exact tsub_add_cancel_of_le bound
  have orig (g : G) : ((m g).mass:ℝ≥0∞) • L (some g) = (m g : Measure (ι → ℝ≥0)) :=
    (congrArg (fun m : FiniteMeasure (ι → ℝ≥0) => (m : Measure (ι → ℝ≥0)))
      (m g).self_eq_mass_smul_normalize).symm
  have hu (i) : (∑ a, if i ∈ J a then (W a : ℝ≥0∞) • (L a).map (Function.eval i) else 0) ≤ μ i := by
    apply le_trans _ (use i)
    rw [Fintype.sum_option]
    simp only [J, Option.elim_none, Finset.notMem_empty, ↓reduceIte, zero_add,Option.elim_some]
    apply sum_le_sum
    intro g _
    change (if i ∈ I g then (W (.some g):ℝ≥0∞) • (L (.some g)).map (Function.eval i) else 0) ≤ _
    by_cases hi : i ∈ I g
    · simp only [hi,↓reduceIte]
      have eq : ((W (some g):ℝ≥0∞) • (L (some g)).map (Function.eval i)) =
          (c:ℝ≥0∞) • (m g : Measure (ι → ℝ≥0)).map (Function.eval i) := by
        rw [← orig g,Measure.map_smul _ (measurable_pi_apply i).aemeasurable,smul_smul]
        rfl
      rw [eq]
      exact Measure.le_iff.mpr fun s _ => by
        rw [Measure.smul_apply,smul_eq_mul]
        exact mul_le_of_le_one_left (zero_le) (by exact_mod_cast hc)
    · simp [hi]
  have hs (a) (ha : a ∈ good) (hn : (W a : ℝ≥0∞) ≠ 0) :
      ∀ᵐ x ∂L a, d ≤ ∑ i ∈ J a,x i := by
    obtain ⟨g,_,rfl⟩ := mem_map.mp ha
    have hmass : ((m g).mass:ℝ≥0∞) ≠ 0 := by
      intro h; apply hn; simp [W,ENNReal.coe_mul,h,Function.Embedding.some]
    apply (Measure.ae_ennreal_smul_measure_iff hmass).mp
    change ∀ᵐ x ∂((m g).mass:ℝ≥0∞) • L (some g), d ≤ ∑ i ∈ I g,x i
    rw [orig]; exact hits g
  obtain ⟨γ,hγ,hm,ht⟩ := realize_blocks (fun a => (W a : ℝ≥0∞)) hw L J μ hu good d hs
  refine ⟨γ,hγ,hm,?_⟩
  have eq : (∑ a ∈ good, (W a:ℝ≥0∞)) = (min 1 Q : ℝ≥0) := by
    rw [← scaled,ENNReal.coe_mul]
    simp [good,W,Finset.sum_map,Q,Finset.mul_sum,Function.Embedding.some]
  rwa [eq] at ht
end Finance
