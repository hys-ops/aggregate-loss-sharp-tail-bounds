import FinanceMaximum
open Set Finset MeasureTheory
open scoped NNReal ENNReal BigOperators
noncomputable section
namespace Finance
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

abbrev SmallGroup (ι : Type*) [Fintype ι] (k : ℕ) := {A : Finset ι // 2 ≤ A.card ∧ A.card < k}
abbrev Severity (d : ℝ≥0) := Set.Icc 0 d
abbrev SmallBlock (d : ℝ≥0) (A : Finset ι) :=
  {x : A → Severity d // d ≤ ∑ i, (x i : ℝ≥0)}

instance smallBlockCompact (d : ℝ≥0) (A : Finset ι) : CompactSpace (SmallBlock d A) := by
  have h : IsClosed {x : A → Severity d | d ≤ ∑ i, (x i : ℝ≥0)} :=
    isClosed_le continuous_const (continuous_finsetSum _ fun i _ => continuous_subtype_val.comp (continuous_apply i))
  exact isCompact_iff_compactSpace.mp h.isCompact

/-- The outside-group default is ignored by `usage`. -/
def severityProjection (d : ℝ≥0) (A : Finset ι) (i : ι) (x : SmallBlock d A) : Severity d :=
  if hi : i ∈ A then x.val ⟨i,hi⟩ else ⟨0,by simp⟩

omit [Fintype ι] in
theorem severityProjection_continuous (d : ℝ≥0) (A : Finset ι) (i : ι) :
    Continuous (severityProjection d A i) := by
  unfold severityProjection
  by_cases hi : i ∈ A
  · simp only [dite_eq_left hi]
    exact (continuous_apply (A := fun _ : A => Severity d) (⟨i,hi⟩ : A)).comp
      (continuous_subtype_val : Continuous (Subtype.val : SmallBlock d A → A → Severity d))
  · simp only [dite_eq_right hi]; exact continuous_const

abbrev SmallPlan (ι : Type*) [Fintype ι] (d : ℝ≥0) (k : ℕ) :=
  (g : SmallGroup ι k) → FiniteMeasure (SmallBlock d g.val)

def smallUse {d : ℝ≥0} {k : ℕ} (π : SmallPlan ι d k) (i : ι) :=
  usage (fun g : SmallGroup ι k => g.val) (fun g i => severityProjection d g.val i) π i

/-- Attainment of the manuscript's inner maximum, for Borel subthreshold laws.
Using the successful closed subset as the carrier encodes the support condition. -/
theorem small_allocation_max (d : ℝ≥0) (k : ℕ) (hk : 0 < k)
    (ν : ι → FiniteMeasure (Severity d)) (hν : ∀ i, (ν i).mass ≤ 1) :
    let feasible (π : SmallPlan ι d k) := ∀ i, (smallUse π i : Measure (Severity d)) ≤ ν i
    let obj (π : SmallPlan ι d k) := (∑ g, ((π g).mass:ℝ)) + jointCapacity
      (fun i => ((ν i).mass:ℝ) - ((smallUse π i).mass:ℝ)) k hk
    ∃ π, feasible π ∧ ∀ π', feasible π' → obj π' ≤ obj π :=
  allocation_max (fun g : SmallGroup ι k => g.val)
    (fun g => Finset.card_pos.mp (by have := g.property.1; omega))
    (fun g i => severityProjection d g.val i) (fun g i => severityProjection_continuous d g.val i)
    ν hν k hk
end Finance
