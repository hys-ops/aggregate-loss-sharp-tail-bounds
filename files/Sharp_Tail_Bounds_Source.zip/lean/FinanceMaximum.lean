import FinanceCuts
import Mathlib.MeasureTheory.Measure.Prokhorov
import Mathlib.MeasureTheory.Measure.Sub
import Mathlib.Topology.Order.Lattice
open Set Finset MeasureTheory
open scoped BigOperators ENNReal NNReal Topology
noncomputable section
namespace Finance
variable {ι G : Type*} [Fintype ι] [DecidableEq ι] [Fintype G]
variable {S : Type*} [MetricSpace S] [MeasurableSpace S] [BorelSpace S] [CompactSpace S]
variable {E : G → Type*} [∀ g, MetricSpace (E g)] [∀ g, MeasurableSpace (E g)]
    [∀ g, BorelSpace (E g)] [∀ g, CompactSpace (E g)]

/-- Incidence-dependent projections (only active coordinates are used). -/
def usage (I : G → Finset ι) (f : (g : G) → ι → E g → S)
    (π : (g : G) → FiniteMeasure (E g)) (i : ι) : FiniteMeasure S :=
  ∑ g ∈ univ.filter (fun g => i ∈ I g), (π g).map (f g i)

theorem continuous_capacity (k : ℕ) (hk : 0 < k) :
    Continuous (fun r : ι → ℝ => jointCapacity r k hk) := by
  let F := cutFamily ι k
  have ne : F.Nonempty := ⟨∅, by simp [F,cutFamily,hk]⟩
  have eq (r : ι → ℝ) : jointCapacity r k hk = F.inf' ne (cutRatio r k) := by
    simp [jointCapacity, F, Finset.min'_eq_inf']
  simp_rw [eq]
  apply Continuous.finset_inf'_apply ne
  intro A _
  exact (continuous_finsetSum _ fun i _ => continuous_apply i).div_const _

/-- A continuous projected use with these caps describes a compact allocation problem.
The component spaces can themselves be the closed successful subsets of severity cubes. -/
theorem allocation_max (I : G → Finset ι) (hI : ∀ g, (I g).Nonempty)
    (f : (g : G) → ι → E g → S) (hf : ∀ g i, Continuous (f g i))
    (ν : ι → FiniteMeasure S) (hν : ∀ i, (ν i).mass ≤ 1)
    (k : ℕ) (hk : 0 < k) :
    let feasible := fun π : (g : G) → FiniteMeasure (E g) =>
      ∀ i, (usage I f π i : Measure S) ≤ (ν i : Measure S)
    let obj := fun π : (g : G) → FiniteMeasure (E g) =>
      (∑ g, ((π g).mass : ℝ)) + jointCapacity
        (fun i => ((ν i).mass:ℝ) - ((usage I f π i).mass:ℝ)) k hk
    ∃ π, feasible π ∧ ∀ π', feasible π' → obj π' ≤ obj π := by
  classical
  dsimp only
  let P := (g : G) → FiniteMeasure (E g)
  let D := ι → FiniteMeasure S
  let box : Set P := {π | ∀ g, (π g).mass ≤ 1}
  let remBox : Set D := {δ | ∀ i, (δ i).mass ≤ 1}
  have compactBox : IsCompact box := isCompact_pi_infinite
    (fun g => isCompact_setOfPred_finiteMeasure_le_of_compactSpace (E g) 1)
  have compactRem : IsCompact remBox := isCompact_pi_infinite
    (fun _ => isCompact_setOfPred_finiteMeasure_le_of_compactSpace S 1)
  have contUse (i : ι) : Continuous (fun π : P => usage I f π i) :=
    continuous_finsetSum _ (fun g _ => (FiniteMeasure.continuous_map (hf g i)).comp (continuous_apply g))
  let eqs : Set (P × D) := {v | ∀ i, usage I f v.1 i + v.2 i = ν i}
  have cls : IsClosed eqs := by
    simp only [eqs,Set.ofPred_forall]
    exact isClosed_iInter fun i => isClosed_eq
      (((contUse i).comp continuous_fst).add ((continuous_apply i).comp continuous_snd)) continuous_const
  let C := (box ×ˢ remBox) ∩ eqs
  have hc : IsCompact C := (compactBox.prod compactRem).inter_right cls
  have zuse (i : ι) : usage I f (0 : P) i = 0 := by
    apply Finset.sum_eq_zero
    intro g _
    apply FiniteMeasure.toMeasure_injective
    change (0 : Measure (E g)).map (f g i) = 0
    simp
  have nc : C.Nonempty := by
    refine ⟨(0,ν),⟨⟨fun g => by change (0 : FiniteMeasure (E g)).mass ≤ 1; simp, hν⟩,fun i => by simp [zuse]⟩⟩
  let objective (π : P) : ℝ := (∑ g, ((π g).mass:ℝ)) +
    jointCapacity (fun i => ((ν i).mass:ℝ) - ((usage I f π i).mass:ℝ)) k hk
  have cont : Continuous objective := by
    apply Continuous.add
    · exact continuous_finsetSum _ fun g _ => NNReal.continuous_coe.comp
        (FiniteMeasure.continuous_mass.comp (continuous_apply g))
    · apply (continuous_capacity k hk).comp
      exact continuous_pi fun i => continuous_const.sub (NNReal.continuous_coe.comp
        (FiniteMeasure.continuous_mass.comp (contUse i)))
  obtain ⟨v,hv,hm⟩ := hc.exists_isMaxOn nc (cont.comp continuous_fst).continuousOn
  have use_le (w : P × D) (hw : w ∈ eqs) (i : ι) :
      (usage I f w.1 i : Measure S) ≤ (ν i : Measure S) := by
    rw [← hw i,FiniteMeasure.toMeasure_add]
    exact Measure.le_add_right le_rfl
  refine ⟨v.1,use_le v hv.2,?_⟩
  intro π hp
  let δ (i : ι) : FiniteMeasure S := ⟨(ν i : Measure S) - (usage I f π i : Measure S),inferInstance⟩
  have he : (π,δ) ∈ eqs := by
    intro i
    apply FiniteMeasure.toMeasure_injective
    rw [FiniteMeasure.toMeasure_add,add_comm]
    exact Measure.sub_add_cancel_of_le (hp i)
  have massLE {m n : FiniteMeasure S}
      (h : (m : Measure S) ≤ (n : Measure S)) : m.mass ≤ n.mass := by
    exact_mod_cast (show (m.mass:ℝ≥0∞) ≤ n.mass by simpa [FiniteMeasure.ennreal_mass] using h Set.univ)
  have hd : δ ∈ remBox := by
    intro i
    apply le_trans _ (hν i)
    apply massLE
    rw [← he i,FiniteMeasure.toMeasure_add]
    exact Measure.le_add_left le_rfl
  have hb : π ∈ box := by
    intro g
    obtain ⟨i,hi⟩ := hI g
    have m : ((π g).map (f g i)).mass = (π g).mass := by
      apply ENNReal.coe_injective
      simp [FiniteMeasure.ennreal_mass,FiniteMeasure.toMeasure_map,Measure.map_apply (hf g i).measurable]
    rw [← m]
    apply le_trans _ (hν i)
    apply massLE
    apply le_trans _ (hp i)
    unfold usage
    have sumcoe (A : Finset G) : ((∑ b ∈ A, (π b).map (f b i) : FiniteMeasure S) : Measure S) =
        ∑ b ∈ A, ((π b).map (f b i) : Measure S) := by
      induction A using Finset.induction_on with
      | empty => simp
      | insert a A ha ih => simp [ha,FiniteMeasure.toMeasure_add,ih]
    rw [sumcoe]
    exact single_le_sum (s := univ.filter fun b => i ∈ I b)
      (f := fun b => ((π b).map (f b i) : Measure S)) (fun _ _ => bot_le)
      (mem_filter.mpr ⟨mem_univ g,hi⟩)
  exact hm ⟨⟨hb,hd⟩,he⟩
end Finance
