import Mathlib.Algebra.BigOperators.Field
import Mathlib.Basic.Real.Basic
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Finset.Max
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

open Finset
open scoped BigOperators
noncomputable section
namespace Finance
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Equation (4), after computing the one-name feature pushforward. -/
theorem name_tests_iff (r z : ι → ℝ) (s : ℝ) :
    (∀ (a : ι → ℝ) (t : ℝ), (∑ i, a i * z i) - t*s ≤
      ∑ i, r i * max (a i-t) 0) ↔ (∀ i, 0 ≤ z i ∧ z i ≤ r i) ∧ ∑ i, z i = s := by
  classical
  constructor
  · intro h
    constructor
    · intro j
      have p := h (fun i => if j = i then 1 else 0) 0
      have m := h (fun i => if j = i then -1 else 0) 0
      have hm (i : ι) : max ((if j = i then -1 else 0):ℝ) 0 = 0 := by split_ifs <;> norm_num
      simp [ite_mul, apply_ite] at p
      simp [ite_mul, hm] at m
      exact ⟨by linarith, p⟩
    · have p := h (fun _ => 1) 1
      have m := h (fun _ => -1) (-1)
      simp at p m
      linarith
  · rintro ⟨hz, rfl⟩ a t
    rw [mul_sum, ← sum_sub_distrib]
    apply sum_le_sum
    intro i _
    rw [← sub_mul]
    by_cases h : a i - t ≤ 0
    · rw [max_eq_right h, mul_zero]
      exact mul_nonpos_of_nonpos_of_nonneg h (hz i).1
    · rw [max_eq_left (le_of_not_ge h), mul_comm (r i)]
      exact mul_le_mul_of_nonneg_left (hz i).2 (le_of_not_ge h)

/-- Every cut is necessary, and the names with capacity at least T form a tight cut. -/
theorem cap_iff_cuts (r : ι → ℝ) (k : ℕ) (T : ℝ)
    (hr : ∀ i, 0 ≤ r i) (hT : 0 ≤ T) :
    (k:ℝ)*T ≤ ∑ i, min (r i) T ↔
    ∀ A : Finset ι, A.card < k →
      ((k:ℝ)-A.card)*T ≤ ∑ i ∈ Aᶜ, r i := by
  classical
  have splitcap (A : Finset ι) :
      (∑ i, min (r i) T) ≤ (A.card:ℝ)*T + ∑ i ∈ Aᶜ, r i := by
    rw [← sum_add_sum_compl A (fun i => min (r i) T)]
    apply add_le_add _ (sum_le_sum fun i _ => min_le_left _ _)
    simpa using (sum_le_sum (s:=A) (fun i _ => min_le_right (r i) T))
  constructor
  · intro hc A _
    linarith [splitcap A]
  · intro h
    let A := univ.filter fun i => T ≤ r i
    have heq : (∑ i, min (r i) T) = (A.card:ℝ)*T + ∑ i ∈ Aᶜ, r i := by
      rw [← sum_add_sum_compl A (fun i => min (r i) T)]
      congr 1
      · calc
          ∑ i ∈ A, min (r i) T = ∑ _i ∈ A, T := by
            apply sum_congr rfl
            exact fun i hi => min_eq_right (by simpa [A] using hi)
          _ = _ := by simp
      · apply sum_congr rfl
        intro i hi
        exact min_eq_left (by have := mem_compl.mp hi; simp [A] at this; exact this.le)
    rw [heq]
    by_cases hk : A.card < k
    · linarith [h A hk]
    · have hcard : (k:ℝ) ≤ A.card := by exact_mod_cast Nat.le_of_not_gt hk
      exact le_trans (mul_le_mul_of_nonneg_right hcard hT)
        (le_add_of_nonneg_right (sum_nonneg fun i _ => hr i))

/-- The subset version of (2) is defined without sorting or a tie rule. -/
def cutFamily (ι : Type*) [Fintype ι] [DecidableEq ι] (k : ℕ) :=
  (univ : Finset (Finset ι)).filter fun A => A.card < k

private theorem cuts_nonempty (hk : 0 < k) : (cutFamily ι k).Nonempty :=
  ⟨∅, by simp [cutFamily,hk]⟩

def cutRatio (r : ι → ℝ) (k : ℕ) (A : Finset ι) : ℝ :=
  (∑ i ∈ Aᶜ, r i) / ((k:ℝ)-A.card)

def jointCapacity (r : ι → ℝ) (k : ℕ) (hk : 0 < k) : ℝ :=
  ((cutFamily ι k).image (cutRatio r k)).min' ((cuts_nonempty hk).image _)

theorem le_capacity_iff (r : ι → ℝ) (hk : 0 < k) (T : ℝ) :
    T ≤ jointCapacity r k hk ↔ ∀ A : Finset ι, A.card < k →
      ((k:ℝ)-A.card)*T ≤ ∑ i ∈ Aᶜ, r i := by
  classical
  simp only [jointCapacity,le_min'_iff,mem_image,mem_filter,mem_univ,true_and,
    cutFamily,forall_exists_index,and_imp,forall_apply_eq_imp_iff₂]
  constructor
  · intro h A ha
    have h' : T ≤ cutRatio r k A := by apply h; simp [ha]
    have hpos : 0 < (k:ℝ)-A.card := sub_pos.mpr (by exact_mod_cast ha)
    simpa [mul_comm] using (le_div_iff₀ hpos).mp h'
  · intro h
    intros
    rename_i A ha
    have hpos : 0 < (k:ℝ)-A.card := sub_pos.mpr (by exact_mod_cast ha)
    apply (le_div_iff₀ hpos).mpr
    simpa [mul_comm] using h A ha

theorem capacity_nonneg (r : ι → ℝ) (hk : 0 < k) (hr : ∀ i, 0 ≤ r i) :
    0 ≤ jointCapacity r k hk := by
  apply (le_capacity_iff r hk 0).2
  intro A _
  simpa using (sum_nonneg (s:=Aᶜ) fun i _ => hr i)

end Finance
