import FinancePacking
open Finset
open scoped BigOperators
noncomputable section
namespace Finance
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Pick a largest-sum set of j names; ties can be broken arbitrarily. -/
theorem top_names (r : ι → ℝ) {j : ℕ} (hj : j ≤ Fintype.card ι) :
    ∃ A : Finset ι, A.card = j ∧ (∀ B : Finset ι, B.card = j → ∑ i ∈ B,r i ≤ ∑ i ∈ A,r i)
      ∧ ∀ i ∈ A, ∀ l ∉ A, r l ≤ r i := by
  classical
  obtain ⟨B,_,hb⟩ := exists_subset_card_eq (s := univ) (by simpa using hj)
  let F := (univ : Finset ι).powersetCard j
  obtain ⟨A,ha,hm⟩ := exists_max_image F (fun A => ∑ i ∈ A,r i)
    ⟨B,mem_powersetCard.mpr ⟨subset_univ _,hb⟩⟩
  have sz := (mem_powersetCard.mp ha).2
  have mx (C : Finset ι) (hC : C.card = j) := hm C (mem_powersetCard.mpr ⟨subset_univ _,hC⟩)
  refine ⟨A,sz,mx,?_⟩
  intro i hi l hl
  have he : l ∉ A.erase i := fun h => hl (mem_of_mem_erase h)
  have p := mx (insert l (A.erase i)) (by rw [card_insert_of_notMem he,card_erase_of_mem hi]; have := card_pos.mpr ⟨i,hi⟩; omega)
  rw [sum_insert he] at p
  linarith [sum_erase_add A r hi]

/-- Formula (2) as a finite minimum indexed by j. The numerator removes the
largest j capacities, independently of ties. -/
theorem sorted_capacity (r : ι → ℝ) (hk : 0 < k) (hn : k ≤ Fintype.card ι) :
    ∃ top : Fin k → Finset ι, (∀ j, (top j).card = j.val ∧
      (∀ i ∈ top j, ∀ l ∉ top j, r l ≤ r i)) ∧
    jointCapacity r k hk = (univ : Finset (Fin k)).inf' ⟨⟨0,hk⟩,mem_univ _⟩
      (fun j => ((∑ i,r i) - ∑ i ∈ top j,r i) / ((k:ℝ)-j.val)) := by
  classical
  choose top ht hm hs using (fun j : Fin k => top_names r (j.isLt.le.trans hn))
  refine ⟨top,fun j => ⟨ht j,hs j⟩,?_⟩
  have dif (A : Finset ι) : (∑ i ∈ Aᶜ,r i) = (∑ i,r i) - ∑ i ∈ A,r i := by
    linarith [sum_add_sum_compl A r]
  apply le_antisymm
  · apply le_inf'
    intro j _
    have h : top j ∈ cutFamily ι k := by simp [cutFamily,ht,j.isLt]
    have c := Finset.min'_le _ (cutRatio r k (top j)) (mem_image_of_mem _ h)
    simpa [jointCapacity,cutRatio,dif,ht] using c
  · unfold jointCapacity
    apply Finset.le_min'
    intro x hx
    obtain ⟨A,ha,rfl⟩ := mem_image.mp hx
    have hA : A.card < k := by simpa [cutFamily] using ha
    let j : Fin k := ⟨A.card,hA⟩
    apply le_trans (Finset.inf'_le _ (mem_univ j))
    apply div_le_div_of_nonneg_right _ (by exact sub_nonneg.mpr (by exact_mod_cast hA.le))
    rw [dif]
    exact sub_le_sub_left (hm j A rfl) _
end Finance
