import FinanceTheorem
import FinanceSelector

#check @Finance.sharp_tail
#check @Finance.sharp_tail_sorted

#print axioms JointResidual.fixedMass_iff
#print axioms Finance.name_tests_iff
#print axioms Finance.cap_iff_cuts
#print axioms Finance.le_capacity_iff
#print axioms Finance.capacity_nonneg
#print axioms Finance.splice_marginal
#print axioms Finance.complete_marginals
#print axioms Finance.successful_iff_witness
#print axioms Finance.measurable_witness
#print axioms Finance.select_success_blocks
#print axioms Finance.slot_mixture
#print axioms Finance.packs_iff_cap
#print axioms Finance.packs_iff_le_capacity
#print axioms Finance.maximum_packing
#print axioms Finance.continuous_capacity
#print axioms Finance.allocation_max
#print axioms Finance.top_names
#print axioms Finance.sorted_capacity
#print axioms Finance.labelled_selector
#print axioms Finance.tagged_apply
#print axioms Finance.realize_blocks
#print axioms Finance.severityProjection_continuous
#print axioms Finance.small_allocation_max
#print axioms Finance.measurable_tail
#print axioms Finance.extract_reserves
#print axioms Finance.realize_reserves
#print axioms Finance.group_upper
#print axioms Finance.mem_groupOf
#print axioms Finance.card_groupOf
#print axioms Finance.severity_groups
#print axioms Finance.worst_eq_reserved
#print axioms Finance.worst_attained
#print axioms Finance.reduced_attain_lower
#print axioms Finance.reduced_upper
#print axioms Finance.clipM
#print axioms Finance.cube_back
#print axioms Finance.map_mass_eq
#print axioms Finance.embedM
#print axioms Finance.embed_active
#print axioms Finance.lift_use
#print axioms Finance.lift_admissible
#print axioms Finance.toBlockM
#print axioms Finance.compact_use
#print axioms Finance.sharp_tail
#print axioms Finance.sharp_tail_sorted
