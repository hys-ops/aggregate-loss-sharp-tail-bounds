import JointTests
import FinanceCuts
open MeasureTheory Set Finset JointResidual
open scoped BigOperators
noncomputable section
namespace Finance
/-- Substitution of name indicators in the earlier fixed-mass theorem. The underlying
sample can carry arbitrary continuously distributed severities as well as a name. -/
theorem labelled_selector {Ω : Type*} [MeasurableSpace Ω] {n : ℕ}
    (p : Measure Ω) [IsProbabilityMeasure p] (name : Ω → Fin n) (hm : Measurable name)
    (u : ℝ) (v : Fin n → ℝ) :
    let F := fun x i => if name x = i then (1:ℝ) else 0
    (∃ g, Residual.admissibleWeight p u g ∧ v = value p F g) ↔
      (∀ i, 0 ≤ v i ∧ v i ≤ p.real {x | name x = i}) ∧ ∑ i,v i = u := by
  classical
  intro F
  let A (i : Fin n) := {x | name x = i}
  have ha i : MeasurableSet (A i) := hm (measurableSet_singleton i)
  have hF (i) : Integrable (fun x => F x i) p := by
    have he : (fun x => F x i) = (A i).indicator (fun _ => (1:ℝ)) := by
      funext x; by_cases h : name x = i <;> simp [F,A,Set.indicator,h]
    rw [he]
    exact (integrable_const (μ := p) (1:ℝ)).indicator (ha i)
  have sumlaw (c : Fin n → ℝ) : (∫ x,c (name x) ∂p) = ∑ i,p.real (A i) * c i := by
    have h (x : Ω) : c (name x) = ∑ i, (A i).indicator (fun _ => c i) x := by
      simp [A,Set.indicator,eq_comm]
    simp_rw [h]
    rw [integral_finsetSum _ (fun i _ => (integrable_const (μ := p) _).indicator (ha i))]
    simp [integral_indicator (ha _),Measure.real,Measure.restrict_apply,smul_eq_mul]
  have th (a : Vec n) (x : Ω) : test a (F x) = a (name x) := by simp [test,F,mul_ite,eq_comm]
  rw [fixedMass_iff p F hF]
  simp_rw [th]
  change (∀ (a : Vec n) (t : ℝ), (∑ i,a i*v i) - t*u ≤ ∫ x,max (a (name x)-t) 0 ∂p) ↔ _
  simp_rw [show ∀ (a : Vec n) (t : ℝ), (∫ x,max (a (name x)-t) 0 ∂p) =
    ∑ i, p.real (A i) * max (a i-t) 0 from fun a t => sumlaw (fun i => max (a i-t) 0)]
  exact name_tests_iff _ v u
end Finance
