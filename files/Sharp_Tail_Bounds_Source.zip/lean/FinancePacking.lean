import FinanceCuts
import Mathlib.Analysis.Convex.Birkhoff
open Finset Matrix
open scoped BigOperators
noncomputable section
namespace Finance
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- A permutation assigns distinct names to designated slots K. Every subset of size
`K.card` occurs in this model. Multiple labels for the same group can be merged. -/
def Packs (K : Finset ι) (r : ι → ℝ) (T : ℝ) : Prop :=
  ∃ w : Equiv.Perm ι → ℝ, (∀ σ, 0 ≤ w σ) ∧ ∑ σ, w σ = T ∧
    ∀ i, (∑ σ, if σ i ∈ K then w σ else 0) ≤ r i

/-- The hypersimplex realization, including the all-names case. -/
theorem slot_mixture (K : Finset ι) (hK : 0 < K.card) (x : ι → ℝ)
    (hx : ∀ i, 0 ≤ x i ∧ x i ≤ 1) (hs : ∑ i, x i = K.card) :
    ∃ w : Equiv.Perm ι → ℝ, (∀ σ, 0 ≤ w σ) ∧ ∑ σ, w σ = 1 ∧
      ∀ i, (∑ σ, if σ i ∈ K then w σ else 0) = x i := by
  classical
  have ha : (K.card:ℝ) ≠ 0 := by exact_mod_cast hK.ne'
  have hb : (∑ i, (1-x i)) = (Kᶜ.card:ℝ) := by
    have h := Finset.card_add_card_compl K
    rw [sum_sub_distrib, hs]
    simp only [sum_const, card_univ, nsmul_eq_mul, mul_one]
    have h' : (K.card:ℝ) + Kᶜ.card = Fintype.card ι := by exact_mod_cast h
    linarith
  let M : Matrix ι ι ℝ := fun i j => if j ∈ K then x i / K.card else (1-x i)/Kᶜ.card
  have leftRow (i : ι) : (∑ j ∈ K, M i j) = x i := by
    calc
      _ = ∑ _j ∈ K, (x i / (K.card:ℝ)) := sum_congr rfl fun j hj => by simp [M,hj]
      _ = _ := by simp; field_simp
  have rightRow (i : ι) : (∑ j ∈ Kᶜ, M i j) = 1-x i := by
    have rewriteRight : (∑ j ∈ Kᶜ, M i j) = Kᶜ.card * ((1-x i)/(Kᶜ.card:ℝ)) := by
      calc
        _ = ∑ _j ∈ Kᶜ, ((1-x i)/(Kᶜ.card:ℝ)) := by
          apply sum_congr rfl
          exact fun j hj => by simp [M, mem_compl.mp hj]
        _ = _ := by simp
    rw [rewriteRight]
    by_cases hc : (Kᶜ.card:ℝ) = 0
    · have hzero : ∑ i, (1-x i) = 0 := hb.trans hc
      have hi := (Finset.sum_eq_zero_iff_of_nonneg (s:=univ)
        (fun j _ => sub_nonneg.mpr (hx j).2)).mp hzero i (mem_univ _)
      simp [hi]
    · field_simp
  have bistoch : M ∈ doublyStochastic ℝ ι := by
    apply mem_doublyStochastic_iff_sum.mpr
    refine ⟨fun i j => ?_, fun i => ?_, fun j => ?_⟩
    · dsimp [M]; split
      · exact div_nonneg (hx i).1 (Nat.cast_nonneg _)
      · exact div_nonneg (sub_nonneg.mpr (hx i).2) (Nat.cast_nonneg _)
    · rw [← sum_add_sum_compl K, leftRow, rightRow]; ring
    · by_cases hj : j ∈ K
      · simp [M,hj, ← sum_div, hs, ha]
      · have hc : (Kᶜ.card:ℝ) ≠ 0 := by
          exact_mod_cast (Finset.card_pos.mpr ⟨j,mem_compl.mpr hj⟩).ne'
        simp [M,hj, ← sum_div, hb, hc]
  obtain ⟨w,hw,h1,hm⟩ := exists_eq_sum_perm_of_mem_doublyStochastic bistoch
  refine ⟨w,hw,h1,fun i => ?_⟩
  calc
    _ = ∑ σ : Equiv.Perm ι, ∑ j ∈ K, (w σ • σ.permMatrix ℝ) i j := by
      apply sum_congr rfl
      intro σ _
      simp [Equiv.Perm.permMatrix, PEquiv.toMatrix_apply, Equiv.toPEquiv_apply,
        smul_eq_mul, mul_ite, eq_comm]
    _ = ∑ j ∈ K, (∑ σ : Equiv.Perm ι, w σ • σ.permMatrix ℝ) i j := by
      rw [sum_comm]
      simp only [Matrix.sum_apply]
    _ = _ := by rw [hm, leftRow]

/-- A feasible total iff it can actually be assigned to groups of distinct names. -/
theorem packs_iff_cap (K : Finset ι) (hK : 0 < K.card) (r : ι → ℝ)
    (hr : ∀ i, 0 ≤ r i) (T : ℝ) (hT : 0 ≤ T) :
    Packs K r T ↔ (K.card:ℝ)*T ≤ ∑ i, min (r i) T := by
  classical
  constructor
  · rintro ⟨w,hw,ht,hr'⟩
    calc
      _ = ∑ i, ∑ σ : Equiv.Perm ι, if σ i ∈ K then w σ else 0 := by
        rw [sum_comm, ← ht, mul_sum]
        apply sum_congr rfl
        intro σ _
        rw [Equiv.sum_comp σ (fun i => if i ∈ K then w σ else 0)]
        simp [Finset.sum_ite_mem]
      _ ≤ _ := by
        apply sum_le_sum
        intro i _
        refine le_min (hr' i) ?_
        rw [← ht]
        exact sum_le_sum fun σ _ => by split_ifs <;> simp [hw]
  · intro h
    by_cases ht : T = 0
    · subst T; exact ⟨0,by simp,by simp,by simpa using hr⟩
    have ht' : 0 < T := lt_of_le_of_ne hT (Ne.symm ht)
    let C := ∑ i, min (r i) T
    have hc : 0 < C := lt_of_lt_of_le (mul_pos (by exact_mod_cast hK) ht') h
    let x (i : ι) := min (r i) T / C * K.card
    have hx (i : ι) : x i * T ≤ min (r i) T := by
      calc
        _ = (min (r i) T / C) * ((K.card:ℝ)*T) := by ring
        _ ≤ (min (r i) T / C) * C := mul_le_mul_of_nonneg_left h
          (div_nonneg (le_min (hr i) hT) hc.le)
        _ = _ := div_mul_cancel₀ _ hc.ne'
    obtain ⟨w,hw,h1,hm⟩ := slot_mixture K hK x (fun i => ⟨by
      exact mul_nonneg (div_nonneg (le_min (hr i) hT) hc.le) (Nat.cast_nonneg _),
      (le_of_mul_le_mul_right (by simpa using (hx i).trans (min_le_right _ T)) ht')⟩) (by
        simp [x, ← sum_mul, ← sum_div, ← show (∑ i, min (r i) T) = C from rfl, C, hc.ne'])
    refine ⟨fun σ => T * w σ,fun σ => mul_nonneg hT (hw σ),by rw [← mul_sum,h1,mul_one],?_⟩
    intro i
    calc
      _ = T * (∑ σ : Equiv.Perm ι, if σ i ∈ K then w σ else 0) := by simp [mul_sum,mul_ite]
      _ = x i * T := by rw [hm,mul_comm]
      _ ≤ _ := (hx i).trans (min_le_left _ _)

theorem packs_iff_le_capacity (K : Finset ι) (hK : 0 < K.card) (r : ι → ℝ)
    (hr : ∀ i, 0 ≤ r i) (T : ℝ) (hT : 0 ≤ T) :
    Packs K r T ↔ T ≤ jointCapacity r K.card hK :=
  (packs_iff_cap K hK r hr T hT).trans
    ((cap_iff_cuts r K.card T hr hT).trans (le_capacity_iff r hK T).symm)

theorem maximum_packing (K : Finset ι) (hK : 0 < K.card) (r : ι → ℝ)
    (hr : ∀ i, 0 ≤ r i) :
    IsGreatest {T | 0 ≤ T ∧ Packs K r T} (jointCapacity r K.card hK) := by
  have hn := capacity_nonneg r hK hr
  exact ⟨⟨hn,(packs_iff_le_capacity K hK r hr _ hn).2 le_rfl⟩,
    fun _ h => (packs_iff_le_capacity K hK r hr _ h.1).1 h.2⟩

end Finance
