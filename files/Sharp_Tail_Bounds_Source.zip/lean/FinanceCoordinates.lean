import FinanceReduced
open MeasureTheory Set Finset
open scoped NNReal ENNReal BigOperators
noncomputable section
namespace Finance
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

def clipScore (d x : ℝ≥0) : Severity d := ⟨min x d,by simp⟩
theorem clipM (d : ℝ≥0) : Measurable (clipScore d) :=
  (continuous_id.min continuous_const).subtype_mk _ |>.measurable

def subCube (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)] (d : ℝ≥0) (i : ι) :
    FiniteMeasure (Severity d) := ⟨(subLoss μ d i).map (clipScore d),by unfold subLoss; infer_instance⟩

omit [Fintype ι] [DecidableEq ι] in
theorem cube_back (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)] (d : ℝ≥0) (i : ι) :
    ((subCube μ d i : Measure (Severity d)).map Subtype.val) = subLoss μ d i := by
  change ((subLoss μ d i).map _).map _ = _
  rw [Measure.map_map measurable_subtype_coe (clipM d)]
  apply Eq.trans (Measure.map_congr (g:=id) ?_) Measure.map_id
  exact (ae_restrict_mem (μ:=μ i) (s:=Ioo 0 d) measurableSet_Ioo).mono
    fun x hx => min_eq_left hx.2.le

/-- Mass preservation for finite measurable pushforwards. -/
theorem map_mass_eq {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    (m : FiniteMeasure X) (f : X → Y) (hf : Measurable f) : (m.map f).mass = m.mass := by
  apply ENNReal.coe_injective
  rw [FiniteMeasure.ennreal_mass,FiniteMeasure.ennreal_mass,FiniteMeasure.toMeasure_map,Measure.map_apply hf MeasurableSet.univ]
  rfl

private theorem linmap_sum {X Y G : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    (s : Finset G) (m : G → Measure X) (f : X → Y) (hf : Measurable f) :
    (∑ g ∈ s,m g).map f = ∑ g ∈ s, (m g).map f := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | insert a s ha ih => simp [ha,Measure.map_add _ _ hf,ih]

def embedBlock {d : ℝ≥0} {A : Finset ι} (y : SmallBlock d A) : Losses ι :=
  fun i => (severityProjection d A i y : ℝ≥0)

theorem embedM (d : ℝ≥0) (A : Finset ι) : Measurable (embedBlock (d:=d) (A:=A)) :=
  Measurable.of_eval fun i => measurable_subtype_coe.comp (severityProjection_continuous d A i).measurable

omit [Fintype ι] in
theorem embed_active (d : ℝ≥0) (A : Finset ι) (y : SmallBlock d A) :
    ∑ i ∈ A, embedBlock y i = ∑ j : A,(y.val j : ℝ≥0) := by
  classical
  rw [Finset.sum_subtype A (fun _ => Iff.rfl) (embedBlock y)]
  apply sum_congr rfl; intro j _
  simp [embedBlock,severityProjection,j.property]

def liftPlan {d : ℝ≥0} {k : ℕ} (π : SmallPlan ι d k) : Marked ι k :=
  fun g => (π g).map embedBlock

private theorem coe_usage {d : ℝ≥0} {k : ℕ} (π : SmallPlan ι d k) (i : ι) :
    (smallUse π i : Measure (Severity d)) =
    ∑ g : SmallGroup ι k, if i ∈ g.val then (π g : Measure (SmallBlock d g.val)).map (severityProjection d g.val i) else 0 := by
  classical
  unfold smallUse usage
  let m (g : SmallGroup ι k) := (π g).map (severityProjection d g.val i)
  have sumcoe (H : Finset (SmallGroup ι k)) : ((∑ g ∈ H,m g : FiniteMeasure (Severity d)) : Measure (Severity d)) =
      ∑ g ∈ H,(m g : Measure (Severity d)) := by
    induction H using Finset.induction_on with
    | empty => simp
    | insert a H ha ih => simp [ha,FiniteMeasure.toMeasure_add,ih]
  rw [sumcoe,Finset.sum_filter]; rfl

theorem lift_use {d : ℝ≥0} {k : ℕ} (π : SmallPlan ι d k) (i : ι) :
    used Subtype.val (liftPlan π) i = (smallUse π i : Measure (Severity d)).map Subtype.val := by
  classical
  rw [coe_usage,linmap_sum _ _ _ measurable_subtype_coe]
  apply sum_congr rfl; intro g _
  by_cases hi : i ∈ g.val
  · simp only [hi,↓reduceIte,liftPlan,FiniteMeasure.toMeasure_map]
    rw [Measure.map_map (measurable_pi_apply i) (embedM d g.val),Measure.map_map measurable_subtype_coe (severityProjection_continuous d g.val i).measurable]
    rfl
  · simp [hi]

/-- Zero measure on the endpoints of [0,d] comes from the original open subthreshold restriction. -/
theorem lift_admissible (μ : ι → Measure ℝ≥0) [∀ i, IsProbabilityMeasure (μ i)] {d : ℝ≥0} {k : ℕ}
    (π : SmallPlan ι d k) (hf : ∀ i, (smallUse π i : Measure (Severity d)) ≤ subCube μ d i) :
    admissible μ d (liftPlan π) := by
  refine ⟨fun g => ?_,fun i => ?_⟩
  · change ∀ᵐ x ∂(π g : Measure (SmallBlock d g.val)).map embedBlock, d ≤ ∑ i ∈ g.val,x i
    apply (ae_map_iff (embedM d g.val).aemeasurable
      (measurableSet_le measurable_const (Finset.measurable_fun_sum _ fun i _ => measurable_pi_apply i))).2
    exact Filter.Eventually.of_forall fun y => (embed_active d g.val y).symm ▸ y.property
  · rw [lift_use,← cube_back μ d i]
    exact Measure.map_mono (hf i) measurable_subtype_coe

/-- Encode an ambient configuration in the compact carrier. An arbitrary fallback is used
only on configurations with insufficient clipped severity. -/
def toBlock (d : ℝ≥0) {k : ℕ} (g : SmallGroup ι k) (x : Losses ι) : SmallBlock d g.val := by
  classical
  let y (i : g.val) := clipScore d (x i.val)
  by_cases h : d ≤ ∑ i : g.val,(y i : ℝ≥0)
  · exact ⟨y,h⟩
  · refine ⟨fun _ => ⟨d,by simp⟩,?_⟩
    obtain ⟨i,hi⟩ := Finset.card_pos.mp (by have := g.property.1; omega : 0 < g.val.card)
    exact single_le_sum (f:=fun _ : g.val => d) (fun _ _ => zero_le) (mem_univ ⟨i,hi⟩)

omit [DecidableEq ι] in
theorem toBlockM (d : ℝ≥0) {k : ℕ} (g : SmallGroup ι k) : Measurable (toBlock d g) := by
  classical
  apply Measurable.subtype_mk
  apply Measurable.of_eval
  intro j
  let s := {x : Losses ι | d ≤ ∑ i : g.val,(clipScore d (x i.val) : ℝ≥0)}
  have hs : MeasurableSet s := measurableSet_le measurable_const (Finset.measurable_fun_sum _
    fun i _ => measurable_subtype_coe.comp ((clipM d).comp (measurable_pi_apply i.val)))
  have he : (fun x => (toBlock d g x).val j) =
      s.piecewise (fun x => clipScore d (x j.val)) (fun _ => (⟨d,by simp⟩ : Severity d)) := by
    funext x; by_cases h : x ∈ s
    · simp [toBlock, Set.piecewise, s] at h ⊢; simp [h]
    · simp [toBlock, Set.piecewise, s] at h ⊢; simp [h.not_ge]
  change Measurable (fun x => (toBlock d g x).val j)
  rw [he]; exact Measurable.piecewise hs ((clipM d).comp (measurable_pi_apply j.val)) measurable_const

def compactPlan {k : ℕ} (d : ℝ≥0) (b : Marked ι k) : SmallPlan ι d k :=
  fun g => (b g).map (toBlock d g)

private theorem coord_usage_le {k : ℕ} (b : Marked ι k) (g : SmallGroup ι k) (i : ι) (hi : i ∈ g.val) :
    (b g : Measure (Losses ι)).map (Function.eval i) ≤ used Subtype.val b i := by
  classical
  unfold used
  have h := single_le_sum (s:=univ) (f:=fun h : SmallGroup ι k =>
    if i ∈ h.val then (b h : Measure (Losses ι)).map (Function.eval i) else 0)
    (fun _ _ => bot_le) (mem_univ g)
  simpa only [hi,↓reduceIte] using h

theorem compact_use (μ : ι → Measure ℝ≥0) (d : ℝ≥0) {k : ℕ} (b : Marked ι k)
    (hb : admissible μ d b) (i : ι) :
    (smallUse (compactPlan d b) i : Measure (Severity d)) = (used Subtype.val b i).map (clipScore d) := by
  classical
  rw [coe_usage,used,linmap_sum _ _ _ (clipM d)]
  apply sum_congr rfl
  intro g _
  by_cases hi : i ∈ g.val
  · simp only [hi,↓reduceIte,compactPlan,FiniteMeasure.toMeasure_map]
    rw [Measure.map_map (severityProjection_continuous d g.val i).measurable (toBlockM d g),
      Measure.map_map (clipM d) (measurable_pi_apply i)]
    apply Measure.map_congr
    have good (j : g.val) : ∀ᵐ x ∂(b g : Measure (Losses ι)), x j.val ∈ Ioo 0 d := by
      have le := (coord_usage_le b g j.val j.property).trans (hb.2 j.val)
      have good' := (ae_mono le) (ae_restrict_mem (μ:=μ j.val) (s:=Ioo 0 d) measurableSet_Ioo)
      exact (ae_map_iff (measurable_pi_apply j.val).aemeasurable measurableSet_Ioo).mp good'
    filter_upwards [ae_all_iff.mpr good,hb.1 g] with x h hg
    have eq : (∑ j : g.val, (clipScore d (x j.val) : ℝ≥0)) = ∑ j ∈ g.val,x j := by
      rw [Finset.sum_subtype g.val (fun _ => Iff.rfl)]
      exact sum_congr rfl fun j _ => min_eq_left (h j).2.le
    have hit : d ≤ ∑ j : g.val,(clipScore d (x j.val) : ℝ≥0) := eq ▸ hg
    change severityProjection d g.val i (toBlock d g x) = clipScore d (x i)
    simp only [severityProjection,dite_eq_left hi,toBlock,dite_eq_left hit]
  · simp [hi]

end Finance
