# 보렐 손실 주변분포에서 합계 손실의 날카로운 꼬리 상한

금융 원고의 **정리 1, 식 (2)와 (3), 두 최대값의 달성**을 Lean으로 검증했다. 최종 정리 이름은 `Finance.sharp_tail_sorted`다.

## 무엇이 증명됐나

채무자 수를 $N$, 손실 기준을 $d>0$이라 하고 $2\le k\le N$을 고정한다. 각 채무자의 비음수 손실 $X_i$에는 보렐 확률분포 $\mu_i$가 주어져 있다. 원고의 조건 $(C_k)$는 각 채무자에 대해 $\mu_i$-확률이 1인 보렐 집합을 정할 수 있고, 서로 다른 $k$명의 집합에서 $0<x_i<d$인 손실을 어떻게 하나씩 골라도 합이 $d$ 이상이라는 뜻이다. 각 손실분포는 연속형과 이산형, 그 혼합을 모두 허용한다.

$H=\sum_i\mu_i([d,\infty))$라 하자. 서로 다른 채무자 $2\le |I|<k$명으로 이루어진 작은 그룹마다 각 손실이 $(0,d)$에 속하고 합이 $d$ 이상인 조합에 질량을 배정한다. 이 배분을 $\pi$라 쓴다. 각 채무자에 대해 모든 작은 그룹에서 사용한 손실분포의 합은 그 채무자의 $(0,d)$ 구간 주변분포에 지배되어야 한다. $P(\pi)$는 작은 그룹에 배정한 총질량이고, $r_i(\pi)$는 채무자 $i$에게 남은 구간 질량이다. $R=\sum_i r_i$라 하고 잔여 질량을 $r_{(1)}\ge\cdots\ge r_{(N)}$ 순서로 정렬한다. 그러면

$$
J_k(r)=\min_{0\le j<k}\frac{R-\sum_{\ell=1}^j r_{(\ell)}}{k-j},
\qquad
\sup_{X_i\sim\mu_i}\Pr\!\left(\sum_i X_i\ge d\right)
=\min\!\left(1,\ H+\max_\pi\{P(\pi)+J_k(r(\pi))\}\right).
$$

Lean 정리는 오른쪽 최대값을 달성하는 $\pi$와 왼쪽 확률을 달성하는 결합분포 $\gamma$의 존재를 함께 증명한다. 각 $j$마다 잔여질량이 가장 큰 채무자 $j$명의 집합도 명시한다. 동률이면 여러 집합을 고를 수 있고 식의 값은 같다. $k=2$, $k=N$, 빈 잔여분포와 총 예약 질량이 1을 넘는 경우까지 같은 정리에 들어 있다.

## 원고와 Lean의 대응

| 수학적 단계 | 재현 묶음의 소스와 정리 |
|---|---|
| 원고의 확률이 1인 보렐 집합에 대한 조건, 결합분포의 주변분포, 합계 손실 사건 | `FinanceExtraction.lean`의 `Covers`, `Marginals`, `Tail` |
| 잔여법칙에 채무자 표시함수를 대입한 식 (4) | `FinanceSelector.lean`의 `labelled_selector`가 기존 `JointResidual.fixedMass_iff`를 직접 호출한다. 정규화한 법칙에서 성립하며, 식 (4)는 양변에 총 잔여질량을 곱한 형태다. 잔여질량이 0인 경우는 다음 행의 그룹 구성 정리에서 직접 처리한다. |
| 서로 다른 $k$명에게 만들 수 있는 최대량과 큰 순서대로 쓴 식 (2) | `FinancePacking.lean`의 `maximum_packing`. `FinanceOrder.lean`의 `sorted_capacity`가 상위 $j$명의 합과 연결한다. |
| 상계에서 성공한 표본을 정확히 한 번씩 분류 | `FinanceSelection.lean`의 `select_success_blocks`, `FinanceExtraction.lean`의 `extract_reserves`, `FinanceUpper.lean`의 `reduced_upper` |
| 잔여 주변분포에서 실제 손실 금액을 뽑아 $k$명 그룹 구성 | `FinanceGroups.lean`의 `severity_groups`. 질량 0인 채무자는 양의 질량을 가진 그룹에 배정되지 않는다. |
| 남은 자리를 동시에 채워 주변분포를 정확히 복구하고 상한을 달성 | `FinanceCompletion.lean`의 `complete_marginals`, `FinanceReserve.lean`의 `realize_reserves`, `FinanceReduced.lean`의 `reduced_attain_lower` |
| 작은 그룹 배분과 결합분포의 최대값 존재 | `FinanceSeverity.lean`의 `small_allocation_max`, `FinanceTail.lean`의 `worst_attained` |
| 보렐 손실값과 콤팩트한 성공 조합 공간 사이의 변환, 최종 결합 | `FinanceCoordinates.lean`의 `cube_back`, `compact_use`, `lift_use`. `FinanceTheorem.lean`의 `sharp_tail`과 `sharp_tail_sorted` |

원고처럼 작은 그룹의 측도는 닫힌 성공 집합에 지지된다. Lean에서는 그 집합을 측도의 정의역으로 삼았다. 원래 손실분포에서 자른 구간은 열린 $(0,d)$다. 이를 닫힌 구간 $[0,d]$ 위의 측도로 표현한 뒤 되돌리면 정확히 원래 제한측도를 얻는다는 것도 증명했다. 따라서 0이나 $d$에 있는 원자가 두 번 들어가지 않는다.

## 재사용과 검증 범위

확장 도구의 일반 공동선택 정리와 그 선행 소스는 기존 판본을 그대로 사용했다. 그 정리의 금융 적용은 `labelled_selector`에서 검증했다. 원고의 보조정리 1에는 표시함수의 경우를 직접 증명하는 방법도 있다. 최종 금융 정리는 직접적인 용량 계산과 mathlib의 Birkhoff 정리를 사용한다. 원고에서 꼭짓점을 움직이는 초등 논증 대신, 이중확률행렬을 순열행렬들의 볼록결합으로 분해해 실제로 서로 다른 채무자를 묶는다. 최대값 존재에는 mathlib의 Prokhorov 정리와 닫힌 사건에 대한 Portmanteau 부등식을 사용했다.

Lean 4.34.1, mathlib `d13f23b723b8a846827a245b89c10fc7d3f11612`. 재현에 필요한 기존 소스의 SHA-256을 확인했다. 새 금융 모듈 17개를 빈 객체 디렉터리에서 경고를 오류로 처리해 빌드했다. 최종 식을 포함한 새 공개 정리 44개와 재사용한 판정식 1개의 공리 출력을 검사했다. 출력에 나타난 공리는 `propext`, `Classical.choice`, `Quot.sound` 세 가지 범위 안에 있다. 새 금융 모듈은 `leanchecker`로도 다시 확인했다.

이번 검증의 대상은 정리 1과 그 증명이다. 원고 후반의 VaR 수치, 선형계획 인증서와 실험표는 기존 Python 검산 범위다. 재현 명령은 묶음의 `README.md`, 실제 출력은 `logs/`에 있다.
