import Mathlib.MeasureTheory.Constructions.Pi
import Mathlib.MeasureTheory.Measure.ProbabilityMeasure
import Mathlib.MeasureTheory.Measure.Sub
open MeasureTheory Set
open scoped ENNReal
noncomputable section
namespace Finance
variable {ι Ω L : Type*} [Fintype ι] [MeasurableSpace Ω] [MeasurableSpace L] [Nonempty L]

omit [Fintype ι] [Nonempty L] in
/-- The marginal law of a slot filled from an independent reserve on the complement
of its assigned event. The assigned severities may be arbitrarily dependent. -/
theorem splice_marginal (p : Measure Ω) [IsProbabilityMeasure p]
    (q : Measure L) [IsProbabilityMeasure q] (A : Set Ω) (hA : MeasurableSet A)
    (X : Ω → L) (hX : Measurable X)
    (η : Measure (ι → L)) [IsProbabilityMeasure η] (i : ι)
    (heval : Measure.map (Function.eval i) η = q) [DecidablePred (· ∈ A)] :
    (p.prod η).map (fun u => if u.1 ∈ A then X u.1 else u.2 i) =
      (p.restrict A).map X + p Aᶜ • q := by
  classical
  have hm : Measurable (fun u : Ω × (ι → L) => if u.1 ∈ A then X u.1 else u.2 i) :=
    (hX.comp measurable_fst).ite (hA.preimage measurable_fst) ((measurable_pi_apply i).comp measurable_snd)
  ext s hs
  rw [Measure.map_apply hm hs, Measure.add_apply, Measure.map_apply hX hs,
    Measure.restrict_apply (hX hs), Measure.smul_apply, smul_eq_mul]
  have pre : (fun u : Ω × (ι → L) => if u.1 ∈ A then X u.1 else u.2 i) ⁻¹' s =
      ((X ⁻¹' s ∩ A) ×ˢ univ) ∪ (Aᶜ ×ˢ (Function.eval i ⁻¹' s)) := by
    ext u
    by_cases h : u.1 ∈ A <;> simp [h]
  rw [pre, measure_union _ (hA.compl.prod ((measurable_pi_apply i) hs)),
    Measure.prod_prod,Measure.prod_prod,measure_univ,mul_one,← Measure.map_apply (measurable_pi_apply i) hs,heval]
  exact Set.disjoint_left.mpr fun u h₁ h₂ => h₂.1 h₁.1.2

/-- Simultaneously fill all slots, including zero-mass remainders. Coordinates on
their assigned events are preserved pointwise. All target marginals are exact. -/
theorem complete_marginals (p : Measure Ω) [IsProbabilityMeasure p]
    (μ : ι → Measure L) [∀ i, IsProbabilityMeasure (μ i)] (A : ι → Set Ω)
    (hA : ∀ i, MeasurableSet (A i)) (X : ι → Ω → L) (hX : ∀ i, Measurable (X i))
    (hu : ∀ i, (p.restrict (A i)).map (X i) ≤ μ i) :
    ∃ (η : Measure (ι → L)) (Y : Ω × (ι → L) → ι → L),
      IsProbabilityMeasure η ∧ Measurable Y ∧
      (∀ i, (p.prod η).map (fun u => Y u i) = μ i) ∧
      ∀ u i, u.1 ∈ A i → Y u i = X i u.1 := by
  classical
  let ν (i : ι) := (p.restrict (A i)).map (X i)
  let δ (i : ι) : FiniteMeasure L := ⟨μ i - ν i, inferInstance⟩
  let q (i : ι) : Measure L := ((δ i).normalize : Measure L)
  let η := Measure.pi q
  let Y (u : Ω × (ι → L)) (i : ι) := if u.1 ∈ A i then X i u.1 else u.2 i
  have (i : ι) : IsProbabilityMeasure (q i) := (δ i).normalize.property
  have hmass (i : ι) : ((δ i).mass : ℝ≥0∞) = p (A i)ᶜ := by
    rw [FiniteMeasure.ennreal_mass]
    change (μ i - ν i) univ = _
    rw [Measure.sub_apply MeasurableSet.univ (hu i),measure_univ,
      show ν i univ = p (A i) by simp [ν,Measure.map_apply (hX i)]]
    simpa using (measure_compl (μ := p) (hA i) (measure_ne_top p _)).symm
  have hfill (i : ι) : p (A i)ᶜ • q i = μ i - ν i := by
    rw [← hmass]
    have h := congrArg (fun m : FiniteMeasure L => (m : Measure L)) (δ i).self_eq_mass_smul_normalize
    exact h.symm
  refine ⟨η,Y,inferInstance,Measurable.of_eval (fun i =>
    ((hX i).comp measurable_fst).ite ((hA i).preimage measurable_fst)
      ((measurable_pi_apply i).comp measurable_snd)),?_,?_⟩
  · intro i
    rw [show (p.prod η).map (fun u => Y u i) = ν i + p (A i)ᶜ • q i from
      splice_marginal p (q i) _ (hA i) (X i) (hX i) η i (measurePreserving_eval q i).map_eq,
      hfill, add_comm,Measure.sub_add_cancel_of_le (hu i)]
  · intro u i hi
    simp [Y,hi]

end Finance
